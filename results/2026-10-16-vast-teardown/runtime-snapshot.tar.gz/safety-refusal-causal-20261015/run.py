"""Fixed causal contribution-removal tests, with native and exact no-op controls."""
import argparse
import hashlib
import json
import platform
import time
from datetime import datetime, timezone
from pathlib import Path

import torch
import torch.nn.functional as F
import transformers
from safetensors.torch import load_file
from transformers import AutoModelForCausalLM, AutoTokenizer

ROOT = Path(__file__).resolve().parent


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def save(path, data):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
    tmp.replace(path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model-dir', type=Path, required=True)
    ap.add_argument('--weights', type=Path, required=True)
    a = ap.parse_args()
    dest = ROOT/'results.json'
    assert not dest.exists(), 'Refusing to overwrite results'
    start = time.monotonic()
    p = json.loads((ROOT/'protocol.json').read_text())
    case = json.loads((ROOT/'case.json').read_text())
    base = json.loads((ROOT/'expected-base-verification.json').read_text())
    assert base['repo'] == p['base_repo'] and base['revision'] == p['base_revision']
    for f in base['files']:
        path = a.model_dir/f['file']
        assert path.stat().st_size == f['bytes'] and sha(path) == f['sha256'], f['file']
    assert sha(a.weights) == p['asset_sha256']
    assert torch.__version__ == p['runtime']['torch']
    assert transformers.__version__ == p['runtime']['transformers']
    torch.manual_seed(p['seed'])
    torch.set_num_threads(6)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    assert torch.cuda.mem_get_info()[0] > 11*1024**3, 'Insufficient free GPU memory'
    tok = AutoTokenizer.from_pretrained(a.model_dir, local_files_only=True)
    model = AutoModelForCausalLM.from_pretrained(
        a.model_dir, local_files_only=True, dtype=torch.bfloat16,
        attn_implementation='eager').cuda().eval().requires_grad_(False)
    weights = {k: v.cuda() for k, v in load_file(a.weights).items()}
    layer, feature = p['layer'], p['transform']
    assert weights['e.weight'].shape == (2480, 2560)
    assert weights[f'V_{feature}'].shape == (2560, p['rank'])
    theta = weights['nonlinearity.theta'].reshape(-1)[feature]
    chat = tok.apply_chat_template([{'role':'user','content':case['prompt']}],
        tokenize=False, add_generation_prompt=True, enable_thinking=False)
    enc = tok(chat, add_special_tokens=False, return_offsets_mapping=True)
    encoded, offsets = enc['input_ids'], enc['offset_mapping']
    assert chat == case['chat'] and encoded == case['prompt_token_ids']
    assert chat.count(case['prompt']) == 1
    begin = chat.index(case['prompt'])
    end = begin+len(case['prompt'])
    user = [i for i, (lo, hi) in enumerate(offsets) if hi > begin and lo < end]
    assert user == list(range(user[0], user[-1]+1))
    assert tok.decode([encoded[i] for i in user]) == case['prompt']
    first, last = user[0], user[-1]
    eos = model.generation_config.eos_token_id
    eos = set(eos if isinstance(eos, list) else [eos])
    special = set(tok.all_special_ids)
    attention = [b.self_attn.forward for b in model.model.layers]
    bounds = {'first_user_content_token':first,'last_user_content_token':last,
              'prompt_tokens':len(encoded),'user_char_span':[begin,end],
              'tokens':[{'position':i,'token_id':t,'token':tok.decode([t]),
                        'char_span':offsets[i], 'segment':'before_user' if i<first
                        else 'user' if i<=last else 'post_user_prompt'}
                       for i,t in enumerate(encoded)]}
    result = {'status':'running','protocol':p,'case':case,'boundaries':bounds,
        'base_files_hash_verified':True,'selected_asset_hash_verified':True,
        'threshold':float(theta),'started_at_utc':datetime.now(timezone.utc).isoformat(),
        'source_sha256':{n:sha(ROOT/n) for n in
                        ['run.py','protocol.json','case.json','expected-base-verification.json']},
        'runtime':{'torch':torch.__version__,'transformers':transformers.__version__,
                   'python':platform.python_version(),'cuda':torch.version.cuda,
                   'gpu':torch.cuda.get_device_name()},'rows':[]}

    def deadline():
        assert time.monotonic()-start < 60*p['max_runtime_minutes'], 'Runtime limit reached'

    @torch.inference_mode()
    def generate(condition):
        operation, scope = condition['operation'], condition['scope']
        ids = torch.tensor([encoded], device='cuda')
        mask = torch.ones_like(ids)
        cache, output, traces, handles, state = None, [], [], [], {}
        stop, step = 'token_limit', 0

        def capture(_module, inputs):
            z = (inputs[0].detach().float()-weights['input_standardizer.mean'][layer])
            z = z/weights['input_standardizer.std'][layer]
            raw = F.linear(z, weights['e.weight'][feature:feature+1],
                           weights['e.bias'][feature:feature+1]).squeeze(-1)
            full = F.linear(z, weights['e.weight'], weights['e.bias'])[...,feature]
            assert torch.allclose(raw, full, atol=2e-5, rtol=2e-5)
            gate = torch.where((raw>theta)&(raw>0), raw, torch.zeros_like(raw))
            lowrank = (z@weights[f'V_{feature}']@weights[f'U_{feature}'])
            lowrank = lowrank*weights['output_standardizer.std'][layer]
            state.update(raw=raw, gate=gate, lowrank=lowrank)

        def edit(_module, _inputs, native):
            n = native.shape[1]
            selected = ([True]*n if step>0 else
                        [scope=='user_to_end' and j>=first for j in range(n)])
            sel = torch.tensor(selected, device='cuda').reshape(1,n)
            gate, lowrank = state['gate'], state['lowrank']
            if operation == 'zero':
                dg = torch.where(sel, -gate, torch.zeros_like(gate))
            elif operation == 'subtract_constant':
                dg = torch.where(sel, torch.full_like(gate, -p['negative_coefficient']),
                                 torch.zeros_like(gate))
            else:
                assert operation == 'noop'
                dg = torch.zeros_like(gate)
            delta = dg.unsqueeze(-1)*lowrank
            changed = (native.float()+delta).to(native.dtype)
            assert torch.isfinite(changed).all()
            assert torch.equal(changed[~sel],native[~sel]), 'Unselected positions changed'
            if operation == 'noop':
                assert torch.equal(changed,native), 'No-op changed native output'
            actual = (changed.float()-native.float()).norm(dim=-1)[0].cpu().tolist()
            natural = gate[0].cpu().tolist()
            raw = state['raw'][0].cpu().tolist()
            dd = dg[0].cpu().tolist()
            intended = delta.norm(dim=-1)[0].cpu().tolist()
            low = lowrank.norm(dim=-1)[0].cpu().tolist()
            native_norm = native.float().norm(dim=-1)[0].cpu().tolist()
            for j in range(n):
                full_position = j if step==0 else len(encoded)+step-1
                token = int(ids[0,j])
                tr = {'segment':'response' if step>0 else bounds['tokens'][j]['segment'],
                    'full_chat_position':full_position,'answer_position':step-1 if step>0 else None,
                    'token_id':token,'token':tok.decode([token]),'special':token in special,
                    'selected':selected[j],'natural_raw':raw[j],'natural_gate':natural[j],
                    'gate_delta':dd[j],'effective_estimated_coefficient':natural[j]+dd[j],
                    'lowrank_norm':low[j],'intended_delta_norm':intended[j],
                    'actual_bf16_delta_norm':actual[j],'native_mlp_norm':native_norm[j],
                    'actual_delta_over_native_mlp_norm':actual[j]/native_norm[j]}
                if not selected[j] or dd[j] == 0:
                    assert actual[j] == 0
                if operation == 'zero' and selected[j]:
                    assert tr['effective_estimated_coefficient'] == 0
                if intended[j]>0:
                    assert actual[j]>0, 'Intended edit disappeared in BF16'
                traces.append(tr)
            return changed

        if operation != 'native':
            block = model.model.layers[layer]
            handles = [block.post_attention_layernorm.register_forward_pre_hook(capture),
                       block.mlp.register_forward_hook(edit)]
        try:
            for step in range(p['max_new_tokens']):
                deadline()
                pred = model(input_ids=ids, attention_mask=mask,
                             past_key_values=cache, use_cache=True)
                cache = pred.past_key_values
                token = int(pred.logits[0,-1].argmax())
                output.append(token)
                if token in eos:
                    stop = 'eos'
                    break
                ids = torch.tensor([[token]],device='cuda')
                mask = torch.cat([mask,torch.ones_like(ids)],dim=1)
        finally:
            for h in handles:
                h.remove()
        assert all(b.self_attn.forward==f for b,f in zip(model.model.layers,attention))
        if operation in ['native','noop']:
            assert output == case['output_token_ids'], 'Control failed to reproduce saved baseline'
        if scope == 'response_only':
            assert output[0] == case['output_token_ids'][0], 'First output token changed'
            assert all(t['actual_bf16_delta_norm']==0 for t in traces if t['segment']!='response')
        if operation != 'native':
            assert len(traces) == len(encoded)+len(output)-1
        answer = tok.decode(output,skip_special_tokens=True)
        summaries = {}
        for segment in ['before_user','user','post_user_prompt','response']:
            ts = [t for t in traces if t['segment']==segment]
            edits = [t for t in ts if t['actual_bf16_delta_norm']>0]
            summaries[segment] = {'processed_positions':len(ts),
                'selected_positions':sum(t['selected'] for t in ts),
                'active_natural_gates':sum(t['natural_gate']>0 for t in ts),
                'actual_nonzero_edits':len(edits),
                'first_actual_edit_position':edits[0]['full_chat_position'] if edits else None,
                'max_actual_edit_norm':max((t['actual_bf16_delta_norm'] for t in ts),default=0),
                'max_actual_edit_over_native_mlp_norm':max((t['actual_delta_over_native_mlp_norm'] for t in ts),default=0)}
        first_change = next((i for i in range(max(len(output),len(case['output_token_ids'])))
            if i>=len(output) or i>=len(case['output_token_ids']) or output[i]!=case['output_token_ids'][i]),None)
        return {**condition,'answer':answer,'answer_sha256':hashlib.sha256(answer.encode()).hexdigest(),
            'output_token_ids':output,'stop_reason':stop,'token_identical_to_baseline':output==case['output_token_ids'],
            'first_changed_answer_position':first_change,'summary':summaries,'traces':traces}

    for condition in p['conditions']:
        row = generate(condition)
        result['rows'].append(row)
        save(dest,result)
        print(condition['id'],json.dumps({'stop':row['stop_reason'],
            'baseline_identical':row['token_identical_to_baseline'],
            'first_changed_answer_position':row['first_changed_answer_position'],
            'actual_edits':{k:v['actual_nonzero_edits'] for k,v in row['summary'].items()}}),flush=True)
    result.update(status='complete',elapsed_seconds=time.monotonic()-start,
                  attention_unmodified=True,finished_at_utc=datetime.now(timezone.utc).isoformat())
    save(dest,result)
    print('COMPLETE: six fixed conditions; native/no-op controls reproduced baseline.',flush=True)


if __name__ == '__main__':
    main()
