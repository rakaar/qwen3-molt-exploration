# Vampire-bat intermediate-strength search — 15 October 2026

All four original made-up-answer cases are preserved. Three fixed prior successful settings are replayed on a new SPAR RTX 3090: P1-U2 +24, P1-U5 +16, P2-U1 +4. P2-U5 (vampire bats) is searched at every positive integer coefficient 1–64, including exact earlier anchors. Each case also gets a native and zero-addition control. Further fractional follow-ups, if needed, are recorded separately.

The baseline and prior anchors are fixed before execution. No prompt, passage, decoding, intervention timing, model/MOLT checkpoint, feature, precision, or attention change is allowed. The model is Qwen3-4B with L19–T368, labeled Onset of Refusal or Ignorance Statements. Native MLP computation remains; add a times the current complete low-rank output at every processed output-token position. The effective estimated gate is natural_gate + a. This is not a multiplication of the natural gate and uses no donor.

The first output token is predicted normally. Editing begins while processing that emitted token, so it affects later predictions. Prompt positions and attention are unchanged. EOS and the last token of a capped output are not processed further. Strength is a positive additive coefficient, not an absolute gate clamp.

Success requires a coherent, grounded statement that the requested answer cannot be determined from the passage, without a fabricated answer or contradictory explanation. Mixed false answers plus uncertainty fail. Stronger is not assumed to be better; binary search alone is not used. An integer grid cannot prove that no fractional successful interval exists or establish a continuous minimum.

User terminology: four baseline cases are “model made up an answer”; six already say “I do not know / it is not in the passage.” The strict passage-only criterion counts a plausible crystallization inference as unsupported. One baseline abstention has an explanation error; withholding and fully grounded explanations are distinct outcomes.

SPAR-only billing, $1 setup/test cap, working GPU retained after tests at the user's explicit request. No automatic stop or deletion. Code, complete outputs, token IDs, per-position gate/output norms, source/weight hashes and report are backed up to the established GitHub research repository.
