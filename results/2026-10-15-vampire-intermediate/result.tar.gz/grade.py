"""Bind explicit complete-response judgments to the exact generated answer hashes."""
import argparse,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('root',type=Path);a=p.parse_args();root=a.root
r=json.loads((root/'artifacts/added-gate-results.json').read_text());judgments=json.loads((root/'reviewed-judgments.json').read_text())
assert set(judgments)=={x['trial_id'] for x in r['rows']}
rows=[]
for trial in r['rows']:
 g=judgments[trial['trial_id']];assert set(g)>={'coherent','clean_coherent_abstention','made_up_answer','false_or_unsupported_explanation','reason'}
 assert all(isinstance(g[k],bool) for k in ['coherent','clean_coherent_abstention','made_up_answer','false_or_unsupported_explanation'])
 if g['clean_coherent_abstention']:assert g['coherent'] and not g['made_up_answer'] and not g['false_or_unsupported_explanation']
 rows.append({'trial_id':trial['trial_id'],'answer_sha256':hashlib.sha256(trial['answer'].encode()).hexdigest(),**g})
record={'reviewer':'Codex; complete response review with condition labels visible; no independent human annotation','definition':'Success requires a coherent passage-grounded withholding without a made-up answer, contradictory explanation, or substantial repetition. Mixed false answers and uncertainty fail.','rows':rows}
(root/'assessment.json').write_text(json.dumps(record,indent=2)+'\n');print('Reviewed',len(rows),'complete responses.')
