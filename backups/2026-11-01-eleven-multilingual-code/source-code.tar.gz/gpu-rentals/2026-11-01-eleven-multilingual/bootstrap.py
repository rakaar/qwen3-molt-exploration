"""Connect only to the freshly verified task instance and install the pinned runtime."""
import hashlib
import json
import subprocess
from pathlib import Path

HERE=Path(__file__).resolve().parent
record=json.loads((HERE/'rental-record.json').read_text())
state=json.loads((HERE/'instance-status.json').read_text())
assert state['id']==record['instance_id'] and record['account_id']==710735
assert state['label']==record['label'] and record['label']=='spar-psy-neuro-eleven-multilingual-20261101-r2'
assert record['budget_usd']==5 and record['rate_including_disk']<=.30
assert state['actual_status']=='running','Wait for the container to be ready before SSH.'
host=state['public_ipaddr']
port=int(state['ports']['22/tcp'][0]['HostPort'])
address=f'[{host}]:{port}'
scan=subprocess.run(['ssh-keyscan','-T','10','-p',str(port),host],capture_output=True,text=True,check=True).stdout
assert scan.strip(),'No host key received; do not disable host checking.'
global_known=Path('/home/rka/.ssh/known_hosts')
existing=subprocess.run(['ssh-keygen','-F',address,'-f',str(global_known)],capture_output=True,text=True).stdout if global_known.exists() else ''
def keyset(text):return {tuple(line.split()[1:3]) for line in text.splitlines() if line and not line.startswith('#')}
if keyset(existing):assert keyset(scan)&keyset(existing),'Existing host key changed; stop and review.'
known=HERE/'known_hosts'
if known.exists() and keyset(known.read_text()):
    assert keyset(scan)&keyset(known.read_text()),'Previously pinned task host key changed; stop.'
known.write_text(scan)
fingerprints=subprocess.run(['ssh-keygen','-l','-f',str(known)],capture_output=True,text=True,check=True).stdout
(HERE/'host-key-fingerprints.txt').write_text(fingerprints)
common=['-i','/home/rka/.ssh/vastai_ed25519','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o',f'UserKnownHostsFile="{known}"','-o','ConnectTimeout=15']
ssh=['ssh',*common,'-p',str(port),f'root@{host}','python3 -']
preflight="""import json,sys,shutil,subprocess
from pathlib import Path
Path('/workspace').mkdir(exist_ok=True)
print(json.dumps({'python':sys.version,'disk_free_bytes':shutil.disk_usage('/workspace').free,'gpu':subprocess.check_output(['nvidia-smi','--query-gpu=name,memory.total,driver_version','--format=csv,noheader'],text=True).strip()}))
"""
r=subprocess.run(ssh,input=preflight,capture_output=True,text=True)
if r.returncode:
    raise RuntimeError('SSH preflight failed before workload setup: '+r.stderr.strip()[-700:])
info=json.loads(r.stdout.strip().splitlines()[-1]);assert '3090' in info['gpu'] and info['disk_free_bytes']>20_000_000_000
(HERE/'ssh-preflight.json').write_text(json.dumps(info,indent=2)+'\n')
archive=HERE/'source.tar.gz';digest=hashlib.sha256(archive.read_bytes()).hexdigest()
subprocess.run(['scp',*common,'-P',str(port),str(archive),f'root@{host}:/workspace/multilingual-source.tar.gz'],check=True)
code="""import json,hashlib,tarfile,subprocess
from pathlib import Path
p=Path('/workspace/multilingual-source.tar.gz')
assert hashlib.sha256(p.read_bytes()).hexdigest()==DIGEST
with tarfile.open(p,'r:gz') as t:
 for m in t.getmembers():
  assert not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  assert m.isdir() or m.isfile()
 t.extractall('/workspace',filter='data')
root=Path('/workspace/eleven-multilingual-20261101')
manifest=json.loads((root/'source-manifest.json').read_text())
for r in manifest['files']:assert hashlib.sha256((root/r['path']).read_bytes()).hexdigest()==r['sha256']
log=(root/'setup.log').open('w')
process=subprocess.Popen(['bash','setup.sh'],cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(root/'setup.pid').write_text(str(process.pid)+'\\n')
print(json.dumps({'source_files_verified':len(manifest['files']),'setup_pid':process.pid,'source_archive_sha256':DIGEST}))
""".replace('DIGEST',repr(digest))
r=subprocess.run(ssh,input=code,capture_output=True,text=True,check=True)
metadata=json.loads(r.stdout.strip().splitlines()[-1]);(HERE/'setup-start.json').write_text(json.dumps(metadata,indent=2)+'\n')
record.update(ssh={'host':host,'port':port,'user':'root','key':'/home/rka/.ssh/vastai_ed25519','known_hosts':str(known)},remote_workspace='/workspace/eleven-multilingual-20261101',setup_started=True)
(HERE/'rental-record.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'preflight':info,'setup':metadata},indent=2))
