"""Build derived tables and a plot from hash-bound manual response reviews."""
import csv
import hashlib
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch

ROOT=Path(__file__).resolve().parents[2]
BASE=Path(__file__).resolve().parent/'remote-export'
OUT=ROOT/'results/2026-11-01-eleven-multilingual'
OUT.mkdir(exist_ok=True)
SCOPES=['last_input_only','input_only','all_positions','output_only']
STUDIES=[('raw','eleven-multilingual-20261101'),('chat','eleven-multilingual-chat-20261101')]
language={'en':'English','es':'Spanish','zh':'Chinese'}
case_rows=[];response_rows=[];all_reviews=[];audits=[]
panels=[]
for study,name in STUDIES:
    root=BASE/name
    load=lambda p:json.loads((root/p).read_text())
    cases=load('cases.json');ctl=load('artifacts/controls.json');result=load('artifacts/results.json')
    eligibility={r['case_id']:r for r in load('eligibility.json')['cases']}
    review=load('response-review.json')
    assert review['results_sha256']==hashlib.sha256((root/'artifacts/results.json').read_bytes()).hexdigest()
    labels={(r['case_id'],r['scope']):r for r in review['primary_runs']}
    native={r['case_id']:r for r in ctl['controls']}
    audit=load('artifacts/audit.json');assert audit['status']=='passed';audits.append(audit)
    panel=[]
    for c in cases:
        cid=c['id'];n=native[cid]['ordinals']['11'];n12=native[cid]['ordinals']['12'];decision=eligibility[cid]
        traces=[t for t in n['zero_strength']['trace'] if t['phase']=='input']
        row={'study':study,'case_id':cid,'language':language[c['language']],'domain':c['domain'],'wording':c['wording'],
            'eligible':decision['eligible'],'native_11_initial_correct':decision['correct']['11'],'native_12_initial_correct':decision['correct']['12'],
            'prompt_11':c['prompts']['11'],'rendered_input_11':n['native']['chat'],'native_11_response':n['native']['answer'],'native_12_response':n12['native']['answer'],
            'last_input_natural_gate':traces[-1]['natural_gate'],'maximum_input_natural_gate':max(t['natural_gate'] for t in traces),
            'active_input_positions':json.dumps([{'position':t['position'],'token':t['token'],'gate':t['natural_gate']} for t in traces if t['natural_gate']>0],ensure_ascii=False),
            'capability_review_note':decision['review_note']}
        for scope in SCOPES:
            r=next((r for r in result['runs'] if r['case_id']==cid and r['scope']==scope),None)
            row[scope+'_answer_ordinal']=labels[(cid,scope)]['initial_answer_ordinal'] if r else None
            row[scope+'_full_response']=r['answer'] if r else None
        case_rows.append(row)
        if decision['eligible']:
            title=language[c['language']]+' / '+c['domain']+(f' ({c["wording"]})' if study=='raw' else '')
            panel.append((title,[row[s+'_answer_ordinal'] for s in SCOPES]))
        for ordinal,pair in native[cid]['ordinals'].items():
            for kind in ['native','zero_strength']:
                if kind in pair:
                    r=pair[kind]
                    response_rows.append({'study':study,'case_id':cid,'ordinal_query':ordinal,'condition':kind,'scope':'none' if kind=='native' else 'all_positions_alpha0',
                        'prompt':r['prompt'],'rendered_input':r['chat'],'response':r['answer'],'stop_reason':r['stop_reason'],
                        'initial_answer_ordinal_reviewed':int(ordinal) if decision['correct'][ordinal] else None,'shift_to_twelfth':False,'actual_nonzero_input_edits':0,'actual_nonzero_generated_edits':0})
    for kind in ['runs','specificity_controls']:
        for r in result[kind]:
            record=labels[(r['case_id'],r['scope'])] if kind=='runs' else {'initial_answer_ordinal':12,'shift_to_twelfth':False}
            response_rows.append({'study':study,'case_id':r['case_id'],'ordinal_query':r['ordinal'],'condition':'gate_off' if kind=='runs' else 'twelfth_specificity',
                'scope':r['scope'],'prompt':r['prompt'],'rendered_input':r['chat'],'response':r['answer'],'stop_reason':r['stop_reason'],
                'initial_answer_ordinal_reviewed':record['initial_answer_ordinal'],'shift_to_twelfth':record['shift_to_twelfth'],
                'actual_nonzero_input_edits':sum(t['actual_delta_norm']>0 for t in r['trace'] if t['phase']=='input'),
                'actual_nonzero_generated_edits':sum(t['actual_delta_norm']>0 for t in r['trace'] if t['phase']=='output')})
            if kind=='runs':all_reviews.append({'study':study,**record})
    panels.append(panel)

def csvout(name,rows):
    with (OUT/name).open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
csvout('cases.csv',case_rows);csvout('responses.csv',response_rows)
assert len(case_rows)==27 and len(response_rows)==171 and len(all_reviews)==72
summary={'feature':'L29-T2375','model':'Qwen3-4B','stages':{'raw':{'pairs':18,'eligible':9,'excluded':9,'runs':99},'chat_followup':{'pairs':9,'eligible':9,'excluded':0,'runs':72}},
    'primary_ablation_conditions':72,'target_twelfth_conditions':sum(r['initial_answer_ordinal']==12 for r in all_reviews),
    'other_fourteenth_conditions':sum(r['initial_answer_ordinal']==14 for r in all_reviews),'twelfth_specificity_initial_answers_unchanged':18,
    'native_zero_exact_pairs':sum(a['native_zero_pairs'] for a in audits),'audited_runs':sum(a['runs'] for a in audits),
    'audited_vector_files':sum(a['vector_files'] for a in audits),'audited_sampled_positions':sum(a['sampled_positions'] for a in audits),
    'findings':['Original English raw-prefix November→December, K→L and XI→XII reproduced exactly.','Spanish raw qualifying cases retained their11th answers under all four masks, despite active gates in several cases.','Spanish no-thinking chat: Noviembre→Diciembre under final-input-only, input-only and all-position edits; XI→XII under input-only and all-position edits.','Spanish chat alphabet K→N under final-input-only, input-only and all-position edits; English chat alphabet K→N under input-only and all-position edits. These are11→14, not target11→12 successes.','Chinese one eligible raw month case and all three clean chat cases retained11th answers under all four masks despite active input gates.','English chat month stayed November; Roman XI→XII occurred only with all input+generated positions edited together.','All18 twelfth-query input-off controls retained their correct initial12th answer.'],
    'interpretation':'Some cross-language and cross-domain causal transfer exists in Spanish, but it is strongly prompt/format-dependent and is not a reliable abstract add-one operation. Natural gate activation across languages does not guarantee the same effect of its input-dependent operator.',
    'limits':['Chat followup was added adaptively after raw-format failures; it is reported separately.','Conditions and domains are exploratory, not independent statistical samples or a language-general success rate.','Raw initial-answer scoring does not establish full-continuation coherence.','Only this model/checkpoint, feature and small prompt set were tested; no conclusion of Chinese impossibility.','No active unrelated norm-matched feature controls or exhaustive paraphrase search.','CPU vector reconstruction starts from saved standardized residuals; it is not a full independent model forward pass.'],
    'cases':case_rows,'reviews':all_reviews}
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')

fig,axes=plt.subplots(1,2,figsize=(13.7,6.6));fig.subplots_adjust(left=.14,right=.98,top=.79,bottom=.21,wspace=.68)
colors=['#e5eaf1','#21917b','#e8a23b'];cmap=ListedColormap(colors)
for ax,panel,title in zip(axes,panels,['Raw prefixes: 9 / 18 pairs eligible','Chat followup: 9 / 9 pairs eligible']):
    matrix=[[{11:0,12:1,14:2}[x] for x in row] for _,row in panel]
    ax.imshow(matrix,cmap=cmap,vmin=-.5,vmax=2.5,aspect='auto')
    ax.set_yticks(range(len(panel)),[label for label,_ in panel],fontsize=9)
    ax.set_xticks(range(4),['Final input','All input','Input + output','Output only'],rotation=26,ha='right',fontsize=9)
    ax.set_title(title,fontsize=12,pad=12)
    ax.set_xticks([x-.5 for x in range(5)],minor=True);ax.set_yticks([x-.5 for x in range(len(panel)+1)],minor=True)
    ax.grid(which='minor',color='white',linewidth=2);ax.tick_params(which='minor',bottom=False,left=False)
    for i,(_,values) in enumerate(panel):
        for j,value in enumerate(values):ax.text(j,i,str(value),ha='center',va='center',fontsize=12,color='white' if value==12 else '#233345',weight='bold')
    for spine in ax.spines.values():spine.set_visible(False)
fig.suptitle('Turning off L29–T2375: the answer’s ordinal',fontsize=17,y=.97)
fig.text(.5,.90,'11 = original answer; 12 = next ordinal; 14 = K→N. These numbers are labels, not literal model text.',ha='center',fontsize=10)
fig.legend(handles=[Patch(color=colors[i],label=t) for i,t in enumerate(['Retained 11th answer','Shifted to 12th answer','Other shift: K→N (14th)'])],loc='lower center',ncol=3,bbox_to_anchor=(.5,.075),frameon=False,fontsize=10)
fig.text(.5,.025,'Native 11th/12th answers checked first. Some raw masks were inactive; measured gates and exact prompts are in cases.csv.\n171 runs include controls. The chat followup was adaptive; conditions are not independent trials.',ha='center',fontsize=9,color='#51606d')
fig.savefig(OUT/'outcome-matrix.png',dpi=180,facecolor='white');fig.savefig(OUT/'outcome-matrix.svg',facecolor='white');plt.close(fig)
print(json.dumps({k:v for k,v in summary.items() if k not in ['cases','reviews']},ensure_ascii=False,indent=2))
