"""Capture native MLP and MOLT input states without replacing downstream MLPs."""
import hashlib
import json
import os
import time
from pathlib import Path

for key in ['HF_TOKEN', 'HUGGING_FACE_HUB_TOKEN', 'OPENAI_API_KEY', 'VAST_API_KEY', 'VAST_AI_KEY']:
    os.environ.pop(key, None)

import numpy as np
import torch
import torch.nn.functional as F
import transformers
from transformers import AutoModelForCausalLM, AutoTokenizer

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'artifacts'
OUT.mkdir(exist_ok=True)
assert not (OUT / 'results.json').exists(), 'Never overwrite a previous experiment'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    temporary.replace(path)


assert torch.__version__ == '2.14.0+cu126'
assert transformers.__version__ == '4.57.6'
assert torch.cuda.is_available() and torch.cuda.is_bf16_supported()
torch.set_num_threads(4)
torch.manual_seed(0)
torch.backends.cuda.matmul.allow_tf32 = False
torch.backends.cudnn.allow_tf32 = False
protocol = json.loads((ROOT / 'protocol.json').read_text())
expected = json.loads((ROOT / 'expected-base-verification.json').read_text())
for row in expected['files']:
    path = ROOT / 'model' / row['file']
    assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], row['file']
manifest = json.loads((ROOT / 'weights/manifest.json').read_text())
feature = manifest['features'][0]
assert manifest['revision'] == protocol['molt_revision']
assert (feature['layer'], feature['transform']) == (29, 2375)
feature_path = ROOT / 'weights' / feature['file']
assert sha(feature_path) == feature['sha256']
with np.load(feature_path, allow_pickle=False) as data:
    weights = {k: torch.from_numpy(data[k].copy()).float().cuda() for k in data.files}
references = json.loads((ROOT / 'references.json').read_text())
assert sha(ROOT / 'references.npz') == references['arrays_sha256']
with np.load(ROOT / 'references.npz', allow_pickle=False) as data:
    reference_arrays = {k: data[k].copy() for k in data.files}
tokenizer = AutoTokenizer.from_pretrained(ROOT / 'model', local_files_only=True)
model = AutoModelForCausalLM.from_pretrained(ROOT / 'model', local_files_only=True,
    dtype=torch.bfloat16, attn_implementation='eager').to('cuda').eval().requires_grad_(False)
assert len(model.model.layers) == 36 and model.config.hidden_size == 2560
observed_layers = protocol['observed_block_outputs']
started = time.monotonic()


def hook_count():
    return sum(len(m._forward_hooks) + len(m._forward_pre_hooks) for m in model.modules())


@torch.inference_mode()
def run(case, condition, observe=False, strength=None):
    assert hook_count() == 0
    assert time.monotonic() - started < 60 * protocol['maximum_runtime_minutes']
    name, position = case['name'], case['position']
    token_ids = tokenizer.encode(case['prompt'], add_special_tokens=False)
    assert token_ids == case['prompt_token_ids']
    assert position == len(token_ids) - 1 and tokenizer.decode([token_ids[position]]) == ' is'
    state = {'edit_calls': 0, 'blocks': {}, 'later_molt_inputs': {}, 'later_mlp_inputs': {}}
    handles = []

    def capture_gate_input(_module, inputs):
        x = inputs[0].detach().float()
        z = (x - weights['input_mean']) / weights['input_std']
        raw = F.linear(z, weights['e'].reshape(1, -1), weights['bias']).squeeze(-1)
        gate = torch.where((raw > weights['theta'][0]) & (raw > 0), raw, 0.)
        operator = (z @ weights['V'] @ weights['U']) * weights['output_std']
        state.update(gate_input=x, z=z, raw=raw, gate=gate, operator=operator,
                     contribution=gate[..., None] * operator)

    def edit_mlp(_module, _inputs, output):
        state['edit_calls'] += 1
        delta = -float(strength) * state['contribution'][:, position]
        edited = output.clone()
        edited[:, position] = (output[:, position].float() + delta).to(output.dtype)
        assert torch.equal(edited[:, :position], output[:, :position])
        assert torch.isfinite(edited).all()
        state.update(native_mlp=output.detach().float().clone(),
                     edited_mlp=edited.detach().float().clone(), intended_delta=delta.clone(),
                     actual_delta=(edited[:, position].float() - output[:, position].float()).clone())
        return edited

    def capture_block(layer):
        def capture(_module, _inputs, output):
            value = output[0] if isinstance(output, tuple) else output
            assert value.shape == (1, len(token_ids), 2560)
            state['blocks'][layer] = value.detach().float().clone()
        return capture

    def capture_later_input(layer, key):
        def capture(_module, inputs):
            state[key][layer] = inputs[0].detach().float().clone()
        return capture

    def capture_final_norm_input(_module, inputs):
        state['final_norm_input'] = inputs[0].detach().float().clone()

    if observe or strength is not None:
        handles.append(model.model.layers[29].post_attention_layernorm.register_forward_pre_hook(capture_gate_input))
        for layer in observed_layers:
            handles.append(model.model.layers[layer].register_forward_hook(capture_block(layer)))
        handles.append(model.model.norm.register_forward_pre_hook(capture_final_norm_input))
        for layer in protocol['gate_layers']:
            handles.append(model.model.layers[layer].post_attention_layernorm.register_forward_pre_hook(capture_later_input(layer, 'later_molt_inputs')))
            handles.append(model.model.layers[layer].mlp.register_forward_pre_hook(capture_later_input(layer, 'later_mlp_inputs')))
    if strength is not None:
        handles.append(model.model.layers[29].mlp.register_forward_hook(edit_mlp))
    ids = torch.tensor([token_ids], device='cuda')
    try:
        prediction = model(input_ids=ids, attention_mask=torch.ones_like(ids), use_cache=True)
        logits = prediction.logits[0, -1].float()
        probabilities = logits.softmax(-1)
        chosen = int(logits.argmax())
        values, indices = probabilities.topk(8)
        arrays = {'first_logits': logits.cpu().numpy()}
        if observe or strength is not None:
            assert sorted(state['blocks']) == observed_layers
            assert torch.equal(state['blocks'][35], state['final_norm_input'])
            arrays['residuals'] = torch.stack([state['blocks'][layer][0] for layer in observed_layers]).cpu().numpy()
            arrays['final_norm_input'] = state['final_norm_input'][0].cpu().numpy()
            for key in ['later_molt_inputs', 'later_mlp_inputs']:
                assert sorted(state[key]) == protocol['gate_layers']
                arrays[key] = torch.stack([state[key][layer][0] for layer in protocol['gate_layers']]).cpu().numpy()
            reference_condition = 'off' if strength == 1 else 'native'
            assert np.array_equal(arrays['residuals'], reference_arrays[name + '_' + reference_condition + '_residuals'])
            for key in ['gate_input', 'z', 'raw', 'gate', 'operator', 'contribution', 'native_mlp', 'edited_mlp']:
                if key in state:
                    arrays[key] = state[key][0].cpu().numpy()
            for key in ['intended_delta', 'actual_delta']:
                if key in state:
                    arrays[key] = state[key][0].cpu().numpy()
            assert np.array_equal(arrays['gate'][0:position], np.zeros(position))
            assert float(arrays['gate'][position]) > 0
            assert np.allclose(arrays['contribution'][position], reference_arrays[name + '_contribution'], atol=1e-5, rtol=1e-5)
        if strength is not None:
            assert state['edit_calls'] == 1
            assert np.array_equal(arrays['native_mlp'][position], reference_arrays[name + '_native_mlp'])
            if strength == 1:
                assert np.array_equal(arrays['edited_mlp'][position], reference_arrays[name + '_edited_mlp'])
        else:
            assert state['edit_calls'] == 0
        # Prior native full logits must reproduce exactly; prior off probes must agree.
        if strength in [None, 0]:
            assert np.array_equal(arrays['first_logits'], reference_arrays[name + '_native_logits'])
            if 'residuals' in arrays:
                assert np.array_equal(arrays['residuals'][-1, position], reference_arrays[name + '_native_final_residual'])
        step = case['off_step'] if strength == 1 else case['native_step']
        assert chosen == step['token_id'] and float(logits[chosen]) == step['selected_logit']
        for token_id, probability in step['probe_probabilities'].items():
            assert abs(float(probabilities[int(token_id)]) - probability) < 1e-6
        row = {'case': name, 'condition': condition, 'prompt': case['prompt'], 'position': position,
               'token': ' is', 'prompt_token_ids': token_ids, 'alpha': strength,
               'edited_positions': [position] if strength is not None else [], 'edit_calls': state['edit_calls'],
               'greedy_first_token_id': chosen, 'greedy_first_token': tokenizer.decode([chosen]),
               'top_tokens': [{'token_id': int(i), 'token': tokenizer.decode([int(i)]), 'probability': float(p)}
                              for p, i in zip(values, indices)],
               'prior_reference_verified': True,
               'logits_sha256': hashlib.sha256(arrays['first_logits'].tobytes()).hexdigest()}
        if 'gate' in arrays:
            row['natural_gate'] = float(arrays['gate'][position])
            row['contribution_l2'] = float(np.linalg.norm(arrays['contribution'][position].astype(np.float64)))
        path = OUT / f'{name}--{condition}.npz'
        np.savez_compressed(path, **arrays)
        row['arrays'] = {'file': path.name, 'sha256': sha(path)}
        return row, arrays
    finally:
        for handle in handles:
            handle.remove()
        assert hook_count() == 0


result = {'status': 'running', 'protocol': protocol, 'cases': [],
          'runtime': {'torch': torch.__version__, 'transformers': transformers.__version__,
                      'gpu': torch.cuda.get_device_name(), 'dtype': 'BF16 model; FP32 MOLT edit with one BF16 cast',
                      'attention': 'eager', 'tf32': False, 'base_revision': expected['revision'],
                      'molt_revision': manifest['revision'], 'num_hidden_layers': len(model.model.layers),
                      'source_sha256': {p.name: sha(p) for p in ROOT.iterdir() if p.is_file() and p.suffix in ['.py', '.json']}}}
save(OUT / 'results.json', result)
for case in references['cases']:
    records = {}
    base, base_arrays = run(case, 'native-unhooked')
    native, native_arrays = run(case, 'native-observed', observe=True)
    assert np.array_equal(base_arrays['first_logits'], native_arrays['first_logits'])
    records['native-unhooked'], records['native-observed'] = base, native
    zero, zero_arrays = run(case, 'zero-strength', strength=0.)
    for key in ['first_logits', 'residuals', 'gate', 'contribution', 'later_molt_inputs', 'later_mlp_inputs']:
        assert np.array_equal(native_arrays[key], zero_arrays[key]), ('zero control', key)
    assert np.count_nonzero(zero_arrays['actual_delta']) == 0
    records['zero-strength'] = zero
    off, off_arrays = run(case, 'gate-off', strength=1.)
    repeat, repeat_arrays = run(case, 'gate-off-repeat', strength=1.)
    assert set(off_arrays) == set(repeat_arrays)
    assert all(np.array_equal(off_arrays[key], repeat_arrays[key]) for key in off_arrays)
    assert np.array_equal(native_arrays['residuals'][0], off_arrays['residuals'][0]), 'L28 must remain identical'
    assert np.array_equal(native_arrays['residuals'][:, :case['position']],
                          off_arrays['residuals'][:, :case['position']]), 'Earlier prompt positions must remain identical'
    for key in ['later_molt_inputs', 'later_mlp_inputs']:
        assert np.array_equal(native_arrays[key][:, :case['position']], off_arrays[key][:, :case['position']])
    records['gate-off'], records['gate-off-repeat'] = off, repeat
    result['cases'].append({'case': case['name'], 'prompt': case['prompt'], 'position': case['position'],
                            'runs': records, 'zero_strength_residuals_and_logits_exact': True,
                            'observer_logits_exact': True, 'ablation_repeat_all_arrays_exact': True,
                            'earlier_positions_unchanged_all_observed_layers': True, 'L28_unchanged': True})
    save(OUT / 'results.json', result)
    print(json.dumps({'completed_case': case['name'], 'native_first_token': native['greedy_first_token'],
                      'off_first_token': off['greedy_first_token'], 'natural_gate': native['natural_gate'],
                      'controls': 'pass'}), flush=True)
result.update(status='complete', hooks_remaining=hook_count(), runtime_seconds=time.monotonic() - started)
save(OUT / 'results.json', result)
print('DOWNSTREAM_GATE_INPUTS_COMPLETE', flush=True)
