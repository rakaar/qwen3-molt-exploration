"""Independently audit and plot the collected final-input residual comparison."""
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / 'comparisons/2026-11-03-eleven-residual-trace/remote-export/eleven-residual-20261103'
OUT = ROOT / 'results/2026-11-03-eleven-residual-trace'
OUT.mkdir(exist_ok=True)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bf16(values):
    """Round finite FP32 numbers to BF16, ties to even, returning FP32 values."""
    values = np.asarray(values, dtype=np.float32)
    assert np.isfinite(values).all()
    bits = values.view(np.uint32)
    return ((bits + np.uint32(0x7fff) + ((bits >> 16) & 1)) & np.uint32(0xffff0000)).view(np.float32)


data = json.loads((SOURCE / 'artifacts/results.json').read_text())
assert data['status'] == 'complete' and data['hooks_remaining'] == 0
protocol = data['protocol']
assert protocol['reported_block_outputs'] == list(range(29, 36))
assert protocol['layer'] == 29 and protocol['transform'] == 2375
manifest = json.loads((SOURCE / 'weights/manifest.json').read_text())
feature = manifest['features'][0]
weight_path = SOURCE / 'weights' / feature['file']
assert sha(weight_path) == feature['sha256']
with np.load(weight_path, allow_pickle=False) as archive:
    weights = {k: archive[k].copy().astype(np.float64) for k in archive.files}
references = json.loads((SOURCE / 'references.json').read_text())
assert sha(SOURCE / 'references.npz') == references['arrays_sha256']
with np.load(SOURCE / 'references.npz', allow_pickle=False) as archive:
    reference_arrays = {k: archive[k].copy() for k in archive.files}
summary = {'protocol': protocol, 'runtime': data['runtime'], 'cases': [],
           'source_results_sha256': sha(SOURCE / 'artifacts/results.json'),
           'analysis_sha256': sha(Path(__file__)),
           'metric_definition': 'FP64 Euclidean norms and cosine on saved FP32 copies of BF16 decoder-block outputs, at the same final input is position. No vector RMSNorm, vocabulary projection or later-branch freezing.',
           'interpretation_limit': 'Vector-change magnitude localizes amplification or contraction. It does not identify which attention/MLP computation causes the answer change or establish a general ordinal increment.'}
all_rows = []
audited_arrays = 0
for case in data['cases']:
    name, position = case['case'], case['position']
    runs = case['runs']
    arrays = {}
    for condition, row in runs.items():
        path = SOURCE / 'artifacts' / row['arrays']['file']
        assert sha(path) == row['arrays']['sha256']
        with np.load(path, allow_pickle=False) as archive:
            arrays[condition] = {k: archive[k].copy() for k in archive.files}
        assert all(np.isfinite(a).all() for a in arrays[condition].values())
        audited_arrays += 1
    native, off = arrays['native-observed'], arrays['gate-off']
    assert np.array_equal(arrays['native-unhooked']['first_logits'], native['first_logits'])
    for key in ['first_logits', 'residuals', 'gate', 'contribution']:
        assert np.array_equal(native[key], arrays['zero-strength'][key])
    assert set(off) == set(arrays['gate-off-repeat'])
    assert all(np.array_equal(off[key], arrays['gate-off-repeat'][key]) for key in off)
    assert np.array_equal(native['first_logits'], reference_arrays[name + '_native_logits'])
    assert native['residuals'].shape == off['residuals'].shape == (8, position + 1, 2560)
    assert np.array_equal(native['residuals'][:, :position], off['residuals'][:, :position])
    assert np.array_equal(native['residuals'][0], off['residuals'][0])
    assert np.array_equal(native['residuals'][-1], native['final_norm_input'])
    assert np.array_equal(off['residuals'][-1], off['final_norm_input'])
    assert np.array_equal(native['residuals'][-1, position], reference_arrays[name + '_native_final_residual'])
    # Reconstruct both the selected MLP edit and the following residual addition.
    expected_mlp = bf16(off['native_mlp'][position] - off['contribution'][position])
    assert np.array_equal(expected_mlp, off['edited_mlp'][position])
    assert np.array_equal(off['edited_mlp'][:position], off['native_mlp'][:position])
    assert np.array_equal(bf16(off['gate_input'] + off['edited_mlp']), off['residuals'][1])
    assert np.array_equal(bf16(off['gate_input'] + off['native_mlp']), native['residuals'][1])
    # Independent FP64 MOLT reconstruction from checkpoint standardizers.
    x = off['gate_input'].astype(np.float64)
    z = (x - weights['input_mean']) / weights['input_std']
    raw = z @ weights['e'].reshape(-1) + float(weights['bias'].reshape(-1)[0])
    gate = np.where((raw > float(weights['theta'].reshape(-1)[0])) & (raw > 0), raw, 0.)
    operator = ((z @ weights['V']) @ weights['U']) * weights['output_std']
    contribution = gate[:, None] * operator
    gate_error = float(np.max(np.abs(gate - off['gate'])))
    contribution_error = float(np.max(np.abs(contribution - off['contribution'])))
    assert gate_error < 2e-5 and contribution_error < 1e-4
    assert np.count_nonzero(off['gate'][:position]) == 0 and off['gate'][position] > 0
    rows = []
    for j, layer in enumerate(protocol['observed_block_outputs']):
        a = native['residuals'][j, position].astype(np.float64)
        b = off['residuals'][j, position].astype(np.float64)
        native_l2, off_l2, delta_l2 = float(np.linalg.norm(a)), float(np.linalg.norm(b)), float(np.linalg.norm(b - a))
        row = {'case': name, 'layer': layer, 'position': position, 'token': ' is',
               'native_l2': native_l2, 'off_l2': off_l2, 'norm_difference': off_l2 - native_l2,
               'difference_l2': delta_l2, 'relative_difference_l2': delta_l2 / native_l2,
               'cosine': float(np.clip(np.dot(a, b) / (native_l2 * off_l2), -1, 1)),
               'norm_ratio': off_l2 / native_l2, 'pre_edit_control': layer == 28}
        rows.append(row)
        all_rows.append(row)
    token_ids = {'month': [84223, 6702, 89011, 6652], 'alphabet': [595, 730, 326, 444], 'roman': [37590, 53243, 856, 1599]}[name]
    probabilities = {}
    for condition, state in [('native', native), ('off', off)]:
        logits = state['first_logits'].astype(np.float64)
        p = np.exp(logits - logits.max()); p /= p.sum()
        probabilities[condition] = {str(t): float(p[t]) for t in token_ids}
    summary['cases'].append({'case': name, 'prompt': case['prompt'], 'position': position,
                             'natural_gate': runs['gate-off']['natural_gate'],
                             'contribution_l2': runs['gate-off']['contribution_l2'],
                             'native_first_token': runs['native-observed']['greedy_first_token'],
                             'off_first_token': runs['gate-off']['greedy_first_token'],
                             'first_token_probabilities': probabilities,
                             'rows': rows, 'final_to_L29_difference_growth': rows[-1]['difference_l2'] / rows[1]['difference_l2'],
                             'cpu_gate_max_absolute_error': gate_error,
                             'cpu_contribution_max_absolute_error': contribution_error})
summary['validation'] = {'status': 'pass', 'audited_array_files': audited_arrays,
                          'native_observer_and_zero_controls_exact': True,
                          'prior_native_full_logits_and_final_residuals_exact': True,
                          'prior_off_first_token_logits_and_probe_probabilities_match': True,
                          'off_repeat_all_arrays_exact': True,
                          'L28_control_unchanged': True, 'earlier_positions_unchanged': True,
                          'final_block_output_equals_pre_RMSNorm_residual': True,
                          'BF16_MLP_edit_and_L29_residual_addition_reconstructed': True,
                          'independent_CPU_MOLT_reconstruction': True}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False) + '\n')
with (OUT / 'residual-comparison.csv').open('w', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(all_rows[0]))
    writer.writeheader(); writer.writerows(all_rows)
(OUT / 'validation.json').write_text(json.dumps(summary['validation'], indent=2) + '\n')

plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})
fig, axes = plt.subplots(3, 2, figsize=(11.5, 10), constrained_layout=True)
labels = {'month': 'Eleventh month', 'alphabet': 'Eleventh letter', 'roman': 'Eleventh integer in Roman numerals'}
for i, case in enumerate(summary['cases']):
    rows = case['rows']; layers = [r['layer'] for r in rows]
    left, right = axes[i]
    left.plot(layers, [r['native_l2'] for r in rows], 'o-', color='#247252', label='Native')
    left.plot(layers, [r['off_l2'] for r in rows], 's--', color='#bc5829', label='T2375 off at final is')
    right.plot(layers, [r['difference_l2'] for r in rows], 'o-', color='#315d8a')
    left.set_title(labels[case['case']] + ': residual lengths', loc='left')
    right.set_title('Length of the vector difference: ||off - native||', loc='left')
    left.set_ylabel('Residual L2 norm'); right.set_ylabel('Difference L2 norm')
    final = rows[-1]
    right.text(.03, .95, f"L35 relative difference: {100 * final['relative_difference_l2']:.2f}%\nL35 cosine: {final['cosine']:.6f}",
               transform=right.transAxes, va='top', fontsize=9)
    for ax in [left, right]:
        ax.axvline(29, color='#999', linestyle=':', linewidth=1)
        ax.set_xticks(layers, ['28\ncontrol', '29\nedit', '30', '31', '32', '33', '34', '35'])
        ax.set_xlabel('Decoder block output, before final RMSNorm')
        ax.grid(axis='y', alpha=.2)
    left.legend(fontsize=9)
fig.suptitle('L29-T2375 removed only at the final input " is"\nSame prompt and position; all later blocks compute normally', fontsize=14)
fig.savefig(OUT / 'residual-comparison.png', dpi=180)
fig.savefig(OUT / 'residual-comparison.svg')
plt.close(fig)

lines = ['# Residual propagation after final-input L29-T2375 removal', '',
         'Three exact raw completion prefixes, without a chat wrapper. Only the selected natural contribution at the last input ` is` is removed. Later layers compute normally. No generated tokens are processed in this comparison.', '',
         'Each residual is captured after a complete decoder block. L28 is a pre-edit control. L35 is the final block output, before final RMSNorm and unembedding. These vectors receive no extra normalization.', '',
         '![Residual norms and differences](residual-comparison.png)', '']
for case in summary['cases']:
    lines += [f"## {labels[case['case']]}", '', f"Prompt: `{case['prompt']}`. Edited input position: {case['position']}. Natural gate: {case['natural_gate']:.6f}.", '',
              f"First token: `{case['native_first_token']}` -> `{case['off_first_token']}`. The Roman ` x` token is only a prefix; this experiment does not generate or score the complete XII answer.", '',
              '| Block | Native norm | Gate-off norm | Difference norm | Relative difference | Cosine |', '|---|---:|---:|---:|---:|---:|']
    for row in case['rows']:
        label = str(row['layer']) + (' (control)' if row['pre_edit_control'] else '')
        lines.append(f"| {label} | {row['native_l2']:.4f} | {row['off_l2']:.4f} | {row['difference_l2']:.4f} | {100 * row['relative_difference_l2']:.3f}% | {row['cosine']:.6f} |")
    lines += ['', f"Difference norm at L35 / difference norm at L29: {case['final_to_L29_difference_growth']:.4f}.", '']
lines += ['## Interpretation and verification', '', summary['interpretation_limit'], '',
          'Earlier prompt positions stay exactly unchanged across all observed layers. L28 is unchanged. Unhooked/observed/zero-strength native logits agree exactly, ablation repeats agree on every saved array, and the prior native full logits and pre-final-norm residual reproduce exactly. The natural MOLT contribution, BF16 MLP edit, and subsequent L29 residual addition were independently reconstructed locally.', '',
          'The full native/ablated vectors for every input position are in the hash-verified remote export; the CSV includes L28 and all requested L29-L35 measurements. Metrics are recomputed in FP64 from the saved FP32 copies of BF16 vectors.', '',
          'Reproduce: `python3 experiments/eleven-residual-trace-20261103/analyze.py`.', '',
          'Sources: `comparisons/2026-11-03-eleven-residual-trace/remote-export/eleven-residual-20261103/`. Pinned model/runtime versions, source hashes, exact prompts and numerical audit errors are in `summary.json`.']
(OUT / 'README.md').write_text('\n'.join(lines) + '\n')
print(json.dumps({'validation': summary['validation'], 'cases': [
    {'case': c['case'], 'L29': c['rows'][1], 'L35': c['rows'][-1], 'growth': c['final_to_L29_difference_growth']}
    for c in summary['cases']]}, indent=2))
