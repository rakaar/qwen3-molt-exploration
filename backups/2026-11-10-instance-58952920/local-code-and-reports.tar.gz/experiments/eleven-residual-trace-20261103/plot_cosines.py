"""Plot same-token native-versus-ablated residual cosine from saved vectors."""
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / 'comparisons/2026-11-03-eleven-residual-trace/remote-export/eleven-residual-20261103'
OUT = ROOT / 'results/2026-11-03-eleven-residual-trace'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


source_path = SOURCE / 'artifacts/results.json'
source = json.loads(source_path.read_text())
prior_path = OUT / 'summary.json'
prior = json.loads(prior_path.read_text())
assert source['status'] == 'complete' and prior['validation']['status'] == 'pass'
assert sha(source_path) == prior['source_results_sha256']
tokenizer_path = ROOT / 'comparisons/2026-11-02-eleven-contribution-readout/tokenizer.json'
expected = json.loads((SOURCE / 'expected-base-verification.json').read_text())
assert sha(tokenizer_path) == next(r['sha256'] for r in expected['files'] if r['file'] == 'tokenizer.json')
vocabulary = json.loads(tokenizer_path.read_text())['model']['vocab']
decoded = {i: text for text, i in vocabulary.items()}
layers = source['protocol']['observed_block_outputs']
assert layers == list(range(28, 36))
records, csv_rows, provenance = [], [], {str(source_path.relative_to(ROOT)): sha(source_path),
                                       str(prior_path.relative_to(ROOT)): sha(prior_path),
                                       str(tokenizer_path.relative_to(ROOT)): sha(tokenizer_path)}
for case in source['cases']:
    name, position = case['case'], case['position']
    pair = {}
    for condition in ['native-observed', 'gate-off']:
        row = case['runs'][condition]
        path = SOURCE / 'artifacts' / row['arrays']['file']
        assert sha(path) == row['arrays']['sha256']
        provenance[str(path.relative_to(ROOT))] = sha(path)
        with np.load(path, allow_pickle=False) as arrays:
            pair[condition] = arrays['residuals'].copy().astype(np.float64)
    native, off = pair['native-observed'], pair['gate-off']
    assert native.shape == off.shape == (8, position + 1, 2560)
    assert np.array_equal(native[:, :position], off[:, :position])
    native_norms = np.linalg.norm(native, axis=-1)
    off_norms = np.linalg.norm(off, axis=-1)
    assert np.all(native_norms > 0) and np.all(off_norms > 0)
    cosine = np.clip(np.sum(native * off, axis=-1) / (native_norms * off_norms), -1., 1.)
    # Identical vectors have exactly cosine 1 and angle 0, avoiding FP64 noise.
    identical = np.all(native == off, axis=-1)
    cosine[identical] = 1.
    degrees = np.degrees(np.arccos(cosine))
    previous = next(c for c in prior['cases'] if c['case'] == name)
    assert np.allclose(cosine[:, position], [r['cosine'] for r in previous['rows']], atol=1e-12, rtol=0)
    assert np.all(cosine[:, :position] == 1.) and np.all(degrees[:, :position] == 0.)
    assert np.all(cosine[0] == 1.)
    token_ids = case['runs']['native-observed']['prompt_token_ids']
    tokens = [decoded[i].replace('Ġ', ' ') for i in token_ids]
    assert all(t.isascii() for t in tokens) and ''.join(tokens) == case['prompt']
    for j, layer in enumerate(layers):
        for i, (token_id, token) in enumerate(zip(token_ids, tokens)):
            csv_rows.append({'case': name, 'prompt': case['prompt'], 'layer': layer, 'position': i,
                             'token_id': token_id, 'token': token, 'edited_position': i == position,
                             'pre_edit_control': layer == 28, 'cosine': float(cosine[j, i]),
                             'angle_degrees': float(degrees[j, i]), 'vectors_exactly_equal': bool(identical[j, i])})
    worst_index = int(np.argmin(cosine[1:, position])) + 1
    records.append({'case': name, 'prompt': case['prompt'], 'edited_position': position,
                    'input_token_ids': token_ids, 'input_tokens': tokens,
                    'cosines_layer_by_position': cosine.tolist(),
                    'angles_degrees_layer_by_position': degrees.tolist(),
                    'edited_position_cosines': cosine[:, position].tolist(),
                    'edited_position_angles_degrees': degrees[:, position].tolist(),
                    'minimum_post_edit_cosine': float(cosine[worst_index, position]),
                    'minimum_cosine_layer': layers[worst_index],
                    'maximum_angle_degrees': float(degrees[worst_index, position]),
                    'earlier_positions_exactly_unchanged': True})

result = {'layers': layers, 'cases': records, 'source_sha256': provenance,
          'analysis_sha256': sha(Path(__file__)), 'new_inference': False,
          'comparison': 'Native versus T2375-off full residual vectors at the same input position after the same decoder block. All later layers compute normally.',
          'intervention': 'Only L29-T2375 at the final input is. L28 is a pre-edit control. L35 is before final RMSNorm and unembedding.',
          'method': 'FP64 cosine and arccos in degrees on saved FP32 copies of BF16 residuals. No extra RMSNorm. Exact equality is recorded as cosine 1 and angle 0.',
          'plot_scale': {'cosine_min': .97, 'cosine_max': 1.},
          'limits': 'Only input positions were saved; no generated-token residuals are inferred. High whole-residual cosine can coexist with an answer change.'}
(OUT / 'residual-cosines.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
with (OUT / 'residual-cosines-all-input-tokens.csv').open('w', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(csv_rows[0]))
    writer.writeheader(); writer.writerows(csv_rows)

plt.rcParams.update({'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False})
fig, axes = plt.subplots(3, 2, figsize=(12, 10.8), constrained_layout=True,
                         gridspec_kw={'width_ratios': [1.1, 1.]})
labels = {'month': 'Month', 'alphabet': 'Alphabet', 'roman': 'Roman numerals'}
heatmaps = []
for j, record in enumerate(records):
    line, heatmap = axes[j]
    position = record['edited_position']
    line.plot(layers, record['edited_position_cosines'], 'o-', color='#315d8a', linewidth=2, markersize=5)
    line.axhline(1., linestyle='--', color='#888', linewidth=1)
    line.axvline(29, linestyle=':', color='#aaa', linewidth=1)
    line.set_ylim(.97, 1.0015)
    line.set_yticks([.97, .98, .99, 1.])
    line.set_xticks(layers, ['28\ncontrol', '29\nedit', '30', '31', '32', '33', '34', '35'])
    line.set_xlabel('Decoder block output')
    line.set_ylabel('Cosine: native vs ablated')
    line.set_title(f"{labels[record['case']]}: final input token {position} ( is)", loc='left', fontsize=12)
    line.grid(axis='y', alpha=.2)
    line.text(.03, .06, f"L35: {record['edited_position_cosines'][-1]:.6f}  |  {record['edited_position_angles_degrees'][-1]:.2f} degrees",
              transform=line.transAxes, fontsize=10,
              bbox={'facecolor': 'white', 'alpha': .9, 'edgecolor': 'none', 'pad': 3})
    matrix = np.array(record['cosines_layer_by_position']).T
    hm = heatmap.imshow(matrix, aspect='auto', interpolation='nearest', cmap='Blues_r', vmin=.97, vmax=1.)
    heatmaps.append(hm)
    heatmap.set_title('Every input position: native vs ablated', loc='left', fontsize=12)
    heatmap.set_xticks(range(8), layers)
    heatmap.set_xlabel('Decoder block output')
    heatmap.set_yticks(range(position + 1), [str(i) + ': ' + t.replace(' ', '·') for i, t in enumerate(record['input_tokens'])], fontsize=9)
    heatmap.get_yticklabels()[-1].set_color('#a8431b')
    heatmap.add_patch(Rectangle((-.5, position - .5), 8, 1, fill=False, edgecolor='#b95327', linewidth=1.8))
    heatmap.set_xticks(np.arange(-.5, 8), minor=True)
    heatmap.set_yticks(np.arange(-.5, position + 1), minor=True)
    heatmap.grid(which='minor', color='#d7dfe4', linewidth=.4)
    heatmap.tick_params(which='minor', bottom=False, left=False)
    for k, value in enumerate(matrix[position]):
        heatmap.text(k, position, f'{value:.4f}', ha='center', va='center', fontsize=7.5,
                     color='white' if value < .987 else '#172b39')
bar = fig.colorbar(heatmaps[0], ax=axes[:, 1], shrink=.85, pad=.025, ticks=[.97, .98, .99, 1.])
bar.set_label('Cosine similarity (zoomed scale)')
fig.suptitle('Residual direction after L29-T2375 removal at the final input " is"\nSame token and layer in both runs; all earlier input vectors remain exactly equal', fontsize=14)
fig.supxlabel('Cosine axes and colors zoom to 0.97–1.00. Raw block outputs, before final RMSNorm; no new inference.', fontsize=10)
fig.savefig(OUT / 'residual-cosine-comparison.png', dpi=180)
fig.savefig(OUT / 'residual-cosine-comparison.svg')
plt.close(fig)

lines = ['# Native versus ablated residual cosine at each input token', '',
         result['comparison'], '', result['intervention'], '',
         '![Residual cosine across layers and input positions](residual-cosine-comparison.png)', '',
         'The left panels show the edited final input ` is`. The right panels compare every input token at every saved layer, with the edited row outlined in orange. All earlier positions are exactly unchanged: cosine 1, angle 0 degrees. Both axes and colors are zoomed to 0.97–1.00.', '',
         '| Block | Month | Alphabet | Roman numerals |', '|---|---:|---:|---:|']
for j, layer in enumerate(layers):
    lines.append('| ' + str(layer) + (' (control)' if layer == 28 else '') + ' | ' + ' | '.join(f"{r['edited_position_cosines'][j]:.6f}" for r in records) + ' |')
lines += ['', '| Prompt | L29 angle | L35 angle | Largest angle after edit |', '|---|---:|---:|---:|']
for r in records:
    lines.append(f"| {labels[r['case']]} | {r['edited_position_angles_degrees'][1]:.3f} degrees | {r['edited_position_angles_degrees'][-1]:.3f} degrees | {r['maximum_angle_degrees']:.3f} degrees at L{r['minimum_cosine_layer']} |")
lines += ['', '## Exact prompts', '']
for r in records:
    lines += [f"- {labels[r['case']]}: `{r['prompt']}`. Edited position {r['edited_position']}."]
lines += ['', 'Cosine does not decrease monotonically. Alphabet and Roman cases become more aligned again at L35. The comparison concerns whole residual vectors, not isolated MOLT contributions and not vectors from different prompts.', '',
          result['method'], '', result['limits'], '',
          'Raw file hashes and all per-token cosine/angle values are in `residual-cosines.json` and `residual-cosines-all-input-tokens.csv`.', '',
          'Reproduce: `python3 experiments/eleven-residual-trace-20261103/plot_cosines.py`.']
(OUT / 'COSINES.md').write_text('\n'.join(lines) + '\n')
print(json.dumps({'new_inference': False, 'compared_vectors': len(csv_rows), 'cases': [
    {k: r[k] for k in ['case', 'edited_position_cosines', 'edited_position_angles_degrees', 'minimum_post_edit_cosine', 'minimum_cosine_layer', 'maximum_angle_degrees']}
    for r in records]}, indent=2))
