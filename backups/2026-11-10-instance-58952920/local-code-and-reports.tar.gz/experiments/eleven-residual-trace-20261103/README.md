# Native versus T2375-off residual propagation

Compare the exact raw prefixes already used for November/December, K/L and XI/XII. At each prompt's final input token ` is`, remove only the natural L29-T2375 contribution from the native Qwen3-4B MLP output. All subsequent layers compute normally.

Capture the complete decoder-block outputs for L28-L35, including all input positions. L28 is an unchanged pre-edit control; the requested measurements are L29-L35 at the edited position. L35 is verified to equal the input of the model's final RMSNorm, before normalization or unembedding. No generated tokens are processed, and no logit-lens projection or branch-output freezing is used.

For each prompt run an unhooked native prefill, observed native prefill, zero-strength edit, natural contribution removal, and an exact removal repeat. Preserve full first-answer logits, all captured residual vectors, MOLT inputs/gates/operators/contributions, and intended/rounded MLP edits. Reproduce the previous native full logits and final residual, and the previous off first-token logit and probe probabilities. A Roman first-token ` x` is a prefix, not a complete XII answer.

Use the pinned model, MOLT and runtime versions in `protocol.json` and `expected-base-verification.json`. `setup.sh` downloads and verifies the public model but does not launch the experiment. Run `run.py` only in the prepared GPU environment. Never overwrite an existing `artifacts/results.json`.

After hash-verified collection, run from the project root:

```sh
python3 experiments/eleven-residual-trace-20261103/analyze.py
```

The analysis reconstructs the MOLT contribution independently on CPU, checks BF16 rounding of the MLP edit and following residual addition, verifies controls, and calculates native norm, ablated norm, vector-difference norm, relative difference and cosine. Norms and cosines use FP64 arithmetic on the recorded vectors. It produces the exact CSV, summary, verification record and paired plots under `results/2026-11-03-eleven-residual-trace/`.

Vector-change magnitude describes propagation and amplification. It does not identify a causal downstream component or establish an abstract plus-one mechanism.

For native-versus-ablated residual cosine at every saved input token and layer, run `python3 experiments/eleven-residual-trace-20261103/plot_cosines.py`. It reads the hash-verified vectors without model inference, checks agreement with the existing final-token cosines, and exports cosine plus angle in degrees. `COSINES.md` explains the final-token curves and all-input-token heatmaps. All earlier input vectors remain exactly identical. The plot uses a clearly marked 0.97-1.00 zoom on both axes and heatmap colors.
