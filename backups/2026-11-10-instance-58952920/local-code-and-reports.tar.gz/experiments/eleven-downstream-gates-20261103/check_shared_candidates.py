"""Recheck L31-T797/T949 across the three saved, paired prompt captures."""
import csv
import hashlib
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OUT = ROOT / 'results/2026-11-03-eleven-downstream-gates'
SOURCE = ROOT / 'comparisons/2026-11-03-eleven-downstream-gates/remote-export/eleven-downstream-gates-20261103'
TARGETS = [797, 949]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


source_path = SOURCE / 'artifacts/results.json'
source = json.loads(source_path.read_text())
summary_path = OUT / 'summary.json'
summary = json.loads(summary_path.read_text())
assert source['status'] == 'complete' and source['hooks_remaining'] == 0
assert summary['source_sha256'][str(source_path.relative_to(ROOT))] == digest(source_path)
assert source['protocol']['layer'] == 29 and source['protocol']['transform'] == 2375
assert source['protocol']['later_MLPs_replaced'] is False
assert source['protocol']['gate_layers'] == list(range(30, 36))
manifest_path = HERE / 'gate-cache-manifest.json'
manifest = json.loads(manifest_path.read_text())
assert manifest['revision'] == source['protocol']['molt_revision']
assert manifest['NPZ_and_original_tensor_hashes_verified']
asset = next(a for a in manifest['layers'] if a['layer'] == 31)
weight_path = ROOT / asset['project_path']
assert digest(weight_path) == asset['sha256']
with np.load(weight_path, allow_pickle=False) as archive:
    weights = {k: archive[k].copy() for k in ['encoder', 'bias', 'mean', 'std', 'threshold']}
weights['encoder'] = weights['encoder'][TARGETS]
weights['bias'] = weights['bias'][TARGETS]
threshold = weights['threshold'].reshape(-1)[TARGETS].astype(np.float64)
old = {}
csv_path = OUT / 'all-gate-values.csv'
with csv_path.open() as stream:
    for row in csv.DictReader(stream):
        if int(row['layer']) == 31 and int(row['transform']) in TARGETS:
            old[(row['case'], int(row['transform']))] = row

provenance = {str(p.relative_to(ROOT)): digest(p) for p in
              [source_path, summary_path, manifest_path, weight_path, csv_path, Path(__file__)]}
all_rows, final_rows, cases = [], [], []
membership_checks, max_error = 0, 0.
for case in source['cases']:
    name, position = case['case'], case['position']
    captures, raws, gates = {}, {}, {}
    for condition, run in [('native', 'native-observed'), ('off', 'gate-off')]:
        info = case['runs'][run]['arrays']
        path = SOURCE / 'artifacts' / info['file']
        assert digest(path) == info['sha256']
        provenance[str(path.relative_to(ROOT))] = info['sha256']
        with np.load(path, allow_pickle=False) as archive:
            # The MOLT was trained on the pre-normalization post-attention residual.
            x = archive['later_molt_inputs'][1].copy()
        assert x.shape == (position + 1, 2560)
        captures[condition] = x
        z64 = (x.astype(np.float64) - weights['mean'].astype(np.float64)) / weights['std'].astype(np.float64)
        raw64 = z64 @ weights['encoder'].astype(np.float64).T + weights['bias'].astype(np.float64)
        raw32 = ((x - weights['mean']) / weights['std']) @ weights['encoder'].T + weights['bias']
        active64 = (raw64 > threshold) & (raw64 > 0)
        active32 = (raw32 > threshold.astype(np.float32)) & (raw32 > 0)
        assert np.array_equal(active64, active32)
        membership_checks += active64.size
        max_error = max(max_error, float(np.max(np.abs(raw64 - raw32))))
        raws[condition], gates[condition] = raw64, np.where(active64, raw64, 0.)
    assert np.array_equal(captures['native'][:position], captures['off'][:position])
    for pos in range(position + 1):
        for j, transform in enumerate(TARGETS):
            row = {'case': name, 'position': pos, 'is_final_input_is': pos == position,
                   'layer': 31, 'transform': transform, 'threshold': float(threshold[j]),
                   'native_raw': float(raws['native'][pos, j]), 'off_raw': float(raws['off'][pos, j]),
                   'native_gate': float(gates['native'][pos, j]), 'off_gate': float(gates['off'][pos, j])}
            all_rows.append(row)
            if pos == position:
                reference = old[(name, transform)]
                for key in ['threshold', 'native_raw', 'off_raw', 'native_gate', 'off_gate']:
                    assert abs(row[key] - float(reference[key])) < 1e-12, (name, transform, key)
                final_rows.append(row)
    cases.append({'case': name, 'prompt': case['prompt'], 'edited_position': position,
                  'native_greedy_first_token': case['runs']['native-observed']['greedy_first_token'],
                  'off_greedy_first_token': case['runs']['gate-off']['greedy_first_token'],
                  'active_input_positions': {
                      str(t): {c: np.flatnonzero(gates[c][:, j] > 0).tolist() for c in ['native', 'off']}
                      for j, t in enumerate(TARGETS)}})

result = {
    'question': 'Do the two month candidates also switch on in the alphabet and Roman-numeral cases?',
    'protocol': source['protocol'],
    'scope': 'L29-T2375 contribution subtracted only at final input is; later native layers run normally. L31-T797/T949 are observed offline, not ablated.',
    'new_model_inference': False,
    'gate_rule': 'raw = encoder @ ((post-attention residual - mean) / std) + bias; gate = raw if raw > threshold and raw > 0, otherwise 0.',
    'cases': cases, 'final_is_rows': final_rows, 'all_input_rows': all_rows,
    'validation': {'status': 'pass', 'source_capture_hashes_verified': 6,
                   'L31_gate_cache_hash_verified': True,
                   'matches_existing_final_is_values_to_absolute_tolerance': 1e-12,
                   'FP32_FP64_membership_checks': membership_checks,
                   'FP32_FP64_membership_disagreements': 0,
                   'FP32_FP64_max_raw_error': max_error,
                   'earlier_input_captures_identical': True},
    'source_sha256': provenance,
    'interpretation': 'Both candidates switch on only in the month case among these three prompts. They are not a shared gate-activation explanation at final is across these cases. A month-specific causal role remains untested; the later native MLPs were not replaced with MOLTs.',
    'roman_caveat': 'The saved off first token is x, a prefix compatible with XII; this prefill-only check does not regenerate or score the full XII sequence.'}
(OUT / 'shared-candidate-check.json').write_text(json.dumps(result, indent=2) + '\n')
with (OUT / 'shared-candidate-check.csv').open('w', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(all_rows[0]))
    writer.writeheader()
    writer.writerows(all_rows)

lines = ['# Do the month candidates generalize to alphabet and Roman prompts?', '',
         result['scope'], '', 'This is an independent CPU re-evaluation of previously captured paired native-model inputs. No new generation or GPU inference was needed.', '',
         '## Final input ` is`', '', '| Prompt | L31-T797 native -> off | L31-T949 native -> off |', '|---|---|---|']
for case in cases:
    rows = {r['transform']: r for r in final_rows if r['case'] == case['case']}
    cells = [f"{rows[t]['native_gate']:.6f} -> {rows[t]['off_gate']:.6f}" for t in TARGETS]
    lines.append(f"| `{case['prompt']}` | {' | '.join(cells)} |")
lines += ['', 'A zero gate means the raw encoder score did not pass its learned threshold. It is not a rounded small positive activation.', '',
          '| Case | Transform | Threshold | Native raw score | Ablated raw score |', '|---|---|---:|---:|---:|']
for r in final_rows:
    lines.append(f"| {r['case']} | L31-T{r['transform']} | {r['threshold']:.6f} | {r['native_raw']:.6f} | {r['off_raw']:.6f} |")
lines += ['', '## All input positions', '']
for case in cases:
    lines += [f"- {case['case']}: " + '; '.join(
        f"L31-T{t}: native {v['native']}, after ablation {v['off']}"
        for t, v in case['active_input_positions'].items()) + '.']
lines += ['', 'Positions are zero-based. Earlier input captures were identical between conditions. No generated tokens were evaluated.', '',
          '## Conclusion', '', result['interpretation'], '',
          'In particular, both gates stay off throughout the alphabet and Roman input sequences, including final ` is`. Their raw scores increase after ablation but remain negative and below threshold.', '',
          result['roman_caveat'], '', '## Verification', '',
          'All six capture files and the L31 gate-weight archive passed SHA-256 checks. Independent FP64/FP32 evaluation agreed on every active/inactive decision. Final-token values match the original all-gate table within 1e-12.', '',
          'Reproduce: `python3 experiments/eleven-downstream-gates-20261103/check_shared_candidates.py`.']
(OUT / 'SHARED_CANDIDATES.md').write_text('\n'.join(lines) + '\n')
print(json.dumps({'validation': result['validation'], 'final_is_rows': final_rows,
                  'active_input_positions': {c['case']: c['active_input_positions'] for c in cases}}, indent=2))
