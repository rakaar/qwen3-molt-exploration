"""Render a compact local research table from the verified gate comparison."""
import html
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'results/2026-11-03-eleven-downstream-gates'
data = json.loads((OUT / 'summary.json').read_text())
assert data['validation']['status'] == 'pass'
E = lambda value: html.escape(str(value), quote=True)
labels = {'month': 'Month', 'alphabet': 'Alphabet', 'roman': 'Roman numerals'}


def gate_pills(row, condition):
    key = condition + '_gate'
    features = [r for r in row['features'] if r[key] > 0]
    content = []
    for feature in features:
        status = 'on' if condition == 'off' and feature['change'] == 'newly_on' else 'off' if condition == 'native' and feature['change'] == 'newly_off' else 'shared'
        content.append(f'<span class="pill {status}" title="{E(feature["label"])}">T{feature["transform"]}<small>{feature[key]:.3f}</small></span>')
    return f'<div class="count">{len(features)} active</div><div class="gates">' + (''.join(content) or '<span class="muted">None</span>') + '</div>'


def ids(values):
    return ', '.join('T' + str(v) for v in values) or 'None'


def change_cell(row):
    lookup = {r['transform']: r for r in row['features']}
    changes = ''.join(
        f'<div class="change"><b class="{"increase" if lookup[tid]["gate_delta"] > 0 else "decrease"}">T{tid}: {lookup[tid]["native_gate"]:.3f} → {lookup[tid]["off_gate"]:.3f} <span>({lookup[tid]["gate_delta"]:+.3f})</span></b><small>{E(lookup[tid]["label"])}</small></div>'
        for tid in row['largest_changes'][:3])
    return f'<p class="switches"><b class="increase">Newly on:</b> {ids(row["newly_on"])}<br><b class="decrease">Newly off:</b> {ids(row["newly_off"])}</p>{changes}'


def detail(row):
    records = ''.join(f'<tr><td><b>T{f["transform"]}</b><small>{E(f["label"])}</small><details class="explanation"><summary>Cached description</summary><p>{E(f["explanation"])}</p></details></td><td>{f["native_gate"]:.6f}</td><td>{f["off_gate"]:.6f}</td><td class="{"increase" if f["gate_delta"] > 0 else "decrease" if f["gate_delta"] < 0 else ""}">{f["gate_delta"]:+.6f}</td><td>{f["native_raw"]:.6f} → {f["off_raw"]:.6f}<small>Threshold {f["threshold"]:.6g} · {E(f["change"].replace("_", " "))}</small></td></tr>' for f in row['features'])
    return f'<details class="layer-details"><summary>L{row["layer"]}: all {len(row["features"])} active-union transforms, labels and exact values</summary><div class="scroll"><table class="detail-table"><thead><tr><th>Transform / cached label</th><th>Native φ</th><th>Ablated φ</th><th>Δφ</th><th>Raw scores / threshold</th></tr></thead><tbody>{records}</tbody></table></div></details>'


def case_section(case):
    rows = ''.join(f'<tr data-layer="{r["layer"]}"><th scope="row">L{r["layer"]}</th><td>{gate_pills(r,"native")}</td><td>{gate_pills(r,"off")}</td><td>{change_cell(r)}</td></tr>' for r in case['layers'])
    return f'''<section class="case" id="{case['case']}" {'hidden' if case['case'] != 'month' else ''}>
<div class="case-head"><h2>{labels[case['case']]}</h2><span>Edited input position {case['position']} · <code> is</code></span></div>
<p class="prompt">{E(case['prompt'])}</p>
<p class="response">Native first token: <code>{E(case['native_first_token'])}</code> · after L29-T2375 removal: <code>{E(case['off_first_token'])}</code>{' · “ x” is a prefix, not a complete XII probability.' if case['case']=='roman' else ''}</p>
<div class="scroll"><table class="comparison" aria-label="{labels[case['case']]} downstream gate comparison"><colgroup><col style="width:7%"><col style="width:27%"><col style="width:27%"><col style="width:39%"></colgroup><thead><tr><th>Layer</th><th>Native input</th><th>Input after L29-T2375 off</th><th>What changed?<small>Three largest |Δφ|; all on/off switches</small></th></tr></thead><tbody>{rows}</tbody></table></div>
<h3>Full layer records</h3>{''.join(detail(r) for r in case['layers'])}</section>'''


document = '''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Downstream gates after T2375 removal</title><style>
:root{--ink:#172b39;--muted:#566674;--line:#dce2e4;--blue:#245775;--green:#256443;--red:#a53b32}*{box-sizing:border-box}body{margin:0;background:#faf9f5;color:var(--ink);font:15px/1.6 system-ui,sans-serif}main{max-width:1260px;margin:auto;padding:40px 28px}h1{font-size:38px;line-height:1.15;letter-spacing:-.03em;max-width:850px;margin:12px 0 18px}h2{font-size:24px;margin:0}h3{font-size:18px;margin:30px 0 14px}.eyebrow{font-size:12px;font-weight:750;letter-spacing:.08em;text-transform:uppercase;color:var(--blue)}.lead{max-width:900px;color:var(--muted);font-size:17px}.method-note{background:#edf3f5;border-left:3px solid #7198ad;padding:16px 20px;font-size:14px;margin:25px 0}.method-note p{margin:0}.controls{display:flex;gap:10px;margin:28px 0 16px;flex-wrap:wrap}button{font:inherit;border:1px solid #b7c7d0;border-radius:5px;padding:8px 18px;background:white;color:var(--blue);cursor:pointer}button[aria-pressed=true]{background:var(--blue);color:white}.legend{display:flex;gap:16px;flex-wrap:wrap;font-size:12px;color:var(--muted);margin:0 0 25px}.legend span{display:flex;align-items:center;gap:5px}.swatch{width:11px;height:11px;border-radius:3px;display:inline-block}.on{background:#e7f3eb!important;border-color:#a8cbb3!important;color:var(--green)}.off{background:#faece8!important;border-color:#dcb4a9!important;color:var(--red)}.shared{background:#f0f3f4}.case-head{display:flex;justify-content:space-between;gap:15px;align-items:baseline;margin-top:22px}.case-head span{font-size:13px;color:var(--muted)}.prompt{font:15px/1.7 ui-monospace,monospace;background:white;border:1px solid var(--line);padding:14px 18px;border-radius:5px;overflow-wrap:anywhere}.response{color:var(--muted);font-size:13px}code{white-space:pre-wrap;background:#eaf0ef;padding:2px 4px;border-radius:3px}.scroll{overflow-x:auto}table{border-collapse:collapse;width:100%;background:white;font-variant-numeric:tabular-nums}th,td{text-align:left;vertical-align:top;border-bottom:1px solid var(--line);padding:15px 12px}thead th{background:#eff2f1;font-size:12px;color:var(--muted)}.comparison{table-layout:fixed}.comparison tbody th{color:var(--blue)}small{display:block;font-size:11px;line-height:1.4;color:var(--muted);font-weight:400}.count{color:var(--muted);font-size:11px;margin-bottom:8px}.gates{display:flex;gap:5px;flex-wrap:wrap}.pill{display:inline-flex;align-items:center;gap:6px;border:1px solid #d8e0e3;border-radius:4px;padding:4px 6px;font:12px/1.4 ui-monospace,monospace}.pill small{font-size:10px;color:inherit}.switches{font-size:12px;margin:0 0 10px;overflow-wrap:anywhere}.change{font-size:12px;margin:10px 0}.change small{margin-top:2px}.change b{font-weight:650}.change b span{white-space:nowrap}.increase{color:var(--green)}.decrease{color:var(--red)}.layer-details{border:1px solid var(--line);border-radius:5px;margin:8px 0;background:white}.layer-details>summary{padding:12px 15px;cursor:pointer;color:var(--blue);font-size:13px}.detail-table{font-size:12px;min-width:740px}.detail-table td:nth-child(n+2):not(:last-child){white-space:nowrap}.explanation summary{font-size:11px;color:var(--blue);cursor:pointer}.explanation p{font-size:12px;max-width:450px}.method{margin-top:32px;border-top:1px solid var(--line);padding-top:24px;color:var(--muted);font-size:13px}.method li{margin:7px 0}.downloads{display:flex;gap:18px;flex-wrap:wrap;margin:25px 0;font-size:13px}a{color:var(--blue)}footer{font-size:12px;color:var(--muted);border-top:1px solid var(--line);padding-top:20px;margin-top:30px}[hidden]{display:none!important}@media(max-width:700px){main{padding:24px 16px}h1{font-size:29px}.comparison{min-width:850px}.case-head{display:block}.lead{font-size:15px}}
</style></head><body><main><div class="eyebrow">Qwen3-4B · L29–T2375 · 3 November 2026</div><h1>Which MOLT gates change downstream?</h1><p class="lead">Compare each later layer’s gates on its native input and on the input produced after removing L29–T2375 at the final <code> is</code>. The native model’s MLPs continue to run normally.</p><div class="method-note"><p><b>Observe gates; preserve native computation.</b> We capture the post-attention residual used by each layer’s MOLT encoder, before the native MLP’s RMSNorm, and apply its checkpoint input standardization. Only the L29 contribution is removed. L30–L35 gates are evaluated offline; their outputs are never substituted into the model.</p></div><div class="controls" aria-label="Choose prompt">__BUTTONS__</div><div class="legend"><span><i class="swatch on"></i>Newly active after ablation</span><span><i class="swatch off"></i>Active natively, then inactive</span><span><i class="swatch shared"></i>Active in both conditions</span><span>Pills show transform ID and scalar gate φ</span></div>__CASES__<section class="method"><h3>Read this comparison precisely</h3><ul><li>Every row uses the same final input token in both runs. Earlier input states remain exactly identical.</li><li>Gate φ equals the raw encoder score when it exceeds the learned threshold and zero; otherwise φ is zero. Expanding a layer shows raw scores, thresholds, and exact changes.</li><li>Gate magnitude is not full MOLT contribution magnitude or causal importance. No downstream transform has been ablated in this experiment.</li><li>Descriptions are cached from 21 October 2026. They are activation hypotheses, not established causal meanings.</li><li>All 44,640 case/layer/transform pairs are retained, including gates inactive in both conditions. FP32 and FP64 gate evaluation give identical active sets.</li><li>The native observer/zero controls and ablation repeats match exactly. All captured block residuals reproduce the previous study exactly.</li></ul></section><div class="downloads"><a href="active-gate-changes.csv" download>All active gate values (CSV)</a><a href="all-gate-values.csv" download>Every gate, including inactive (CSV)</a><a href="summary.json" download>Exact inputs, labels, scores & provenance (JSON)</a><a href="validation.json" download>Verification</a></div><footer>Exploratory downstream activation comparison · selected prompt contexts · no later MLP replacement</footer></main><script>
function selectCase(name){document.querySelectorAll('.case').forEach(s=>{s.hidden=s.id!==name});document.querySelectorAll('[data-case]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.case===name)))}document.querySelector('.controls').addEventListener('click',e=>{const b=e.target.closest('[data-case]');if(b){selectCase(b.dataset.case);history.replaceState(null,'','#'+b.dataset.case)}});const selected=location.hash.slice(1);if(['month','alphabet','roman'].includes(selected))selectCase(selected);
</script></body></html>'''
buttons = ''.join(f'<button data-case="{c["case"]}" aria-pressed="{str(c["case"]=="month").lower()}">{labels[c["case"]]}</button>' for c in data['cases'])
document = document.replace('__BUTTONS__', buttons).replace('__CASES__', ''.join(case_section(c) for c in data['cases']))
(OUT / 'index.html').write_text(document)
print(json.dumps({'local_report': str(OUT / 'index.html'), 'prompt_tables': 3, 'layer_rows': 18}))
