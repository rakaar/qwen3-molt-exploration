"""Audit the original dashboard examples for the shared decreasing L34 gate."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'results/2026-11-03-eleven-downstream-gates'
path = ROOT / 'comparisons/2026-11-03-eleven-downstream-gates/activation-example-inspection/L34-T1468.json'
page = json.loads(path.read_text())
assert page['title'].startswith('Layer 34 · Transform 1468 ')
assert page['all_tooltip_metadata_verified']
assert [len(g['examples']) for g in page['groups']] == [12, 6, 6]
description = 'The article "an" or "An" preceding a noun, often at the start of a sentence or list item.'
assert description in page['header']
records, token_count = [], 0
for group_index, group in enumerate(page['groups']):
    for example_index, example in enumerate(group['examples']):
        tokens = example['tokens']
        assert len({t['conversation'] for t in tokens}) == 1
        assert [t['token_position'] for t in tokens] == list(range(tokens[0]['token_position'], tokens[0]['token_position'] + len(tokens)))
        assert all(t['gate_display_rounded'] >= 0 and isinstance(t['token_id'], int) for t in tokens)
        peak = max(tokens, key=lambda t: t['gate_display_rounded'])
        if group_index < 2:
            assert peak['display_token'].strip().lower() == 'an'
        records.append({'group': group['name'], 'example_one_based': example_index + 1,
                        'peak': peak, 'displayed_text': ''.join(t['display_token'] for t in tokens)})
        token_count += len(tokens)

def at(group, example, position):
    return next(t for t in page['groups'][group]['examples'][example]['tokens'] if t['token_position'] == position)

assert [(at(0, 0, p)['token_id'], at(0, 0, p)['gate_display_rounded']) for p in range(247, 251)] == [(458, 6.094), (220, 4.438), (16, 2.391), (16, 0)]
assert [(at(2, 1, p)['token_id'], at(2, 1, p)['gate_display_rounded']) for p in range(469, 472)] == [(220, .617), (16, 0), (16, 0)]
assert [(at(2, 3, p)['token_id'], at(2, 3, p)['gate_display_rounded']) for p in range(865, 868)] == [(24, .602), (16, 0), (16, 0)]
summary = json.loads((OUT / 'summary.json').read_text())
measurements = []
for case in summary['cases']:
    feature = next(f for layer in case['layers'] if layer['layer'] == 34 for f in layer['features'] if f['transform'] == 1468)
    measurements.append({'case': case['case'], 'prompt': case['prompt'], 'position': case['position'],
                         'native_gate': feature['native_gate'], 'off_gate': feature['off_gate']})

result = {'feature': 'L34-T1468', 'url': page['url'], 'retrieved_at': page['retrieved_at'],
          'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
          'review_scope': 'All 12 strongest, 6 medium and 6 lower-strength windows shown on the authenticated original dashboard; not an exhaustive corpus scan.',
          'source_label': 'Article "An" Preceding Noun', 'source_description': description,
          'primary_observation': 'All 18 strongest/medium window maxima fall on the an/An token, including word fragments in Anubis, Anagram, Ankh, Annotating and Anxiety.',
          'numeric_observation': 'One strongest example activates on an, the following space and the first digit of 11-year-old. A lower example activates on the space immediately before 11.4; another activates on 9 before the final 11 in 1911.',
          'twelve_observation': 'No clear twelve-related activation example was found in the 24 displayed windows.',
          'interpretation': 'The examples support a broad an/An token pattern with some before-11 timing. They do not establish an abstract eleven feature or explain why its gate decreases at is across the three intervention cases. No causal role for this later transform has been tested.',
          'month_alphabet_roman_measurements': measurements, 'window_records': records,
          'validation': {'status': 'pass', 'windows': len(records), 'token_tooltip_records': token_count,
                         'all_18_strongest_medium_peaks_on_an_token': True,
                         'before_11_digit_and_space_coordinates_verified': True,
                         'live_description_matches_cache': True},
          'new_model_inference': False}
(OUT / 'T1468-examples.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
lines = ['# L34-T1468: activating examples of the shared decreasing gate', '',
         f"[Original authenticated dashboard]({page['url']})", '', result['review_scope'], '',
         result['primary_observation'], '', result['numeric_observation'], '', result['twelve_observation'], '',
         'Square brackets mark the active token. Gate values are rounded dashboard tooltip values.', '',
         '| Context | Active token | Displayed gate | Conversation / position |', '|---|---|---:|---|',
         '| about an 11-year-old | ` an` | 6.094 | 3936 / 247 |',
         '| about an [space]11-year-old | space immediately before 11 | 4.438 | 3936 / 248 |',
         '| about an 11-year-old | first digit `1` | 2.391 | 3936 / 249 |',
         '| rate is at [space]11.4 percent | space immediately before 11.4 | 0.617 | 9329 / 469 |',
         '| dynasty in 1911 | digit `9`, before the remaining `11` | 0.602 | 5243 / 865 |', '',
         'The second digit of 11-year-old and both digits of 11.4 have zero displayed gate. The word-fragment examples argue for a broader lexical pattern than the label description alone suggests.', '',
         '## Gate at final input ` is` in our paired experiment', '',
         '| Prompt family | Native | After L29-T2375 ablation |', '|---|---:|---:|']
for r in measurements:
    lines.append(f"| {r['case']} | {r['native_gate']:.6f} | {r['off_gate']:.6f} |")
lines += ['', result['interpretation'], '',
          'This is a review of gate activation examples, not a measurement of the full operator contribution or a downstream intervention. No model inference was run.', '',
          'Source token IDs, coordinates, displayed strengths, the source hash and all window texts are retained in the raw capture and T1468-examples.json.', '',
          'Reproduce: `python3 experiments/eleven-downstream-gates-20261103/inspect_t1468.py`.']
(OUT / 'T1468_EXAMPLES.md').write_text('\n'.join(lines) + '\n')
print(json.dumps({'validation': result['validation'], 'measurements': measurements}, indent=2))
