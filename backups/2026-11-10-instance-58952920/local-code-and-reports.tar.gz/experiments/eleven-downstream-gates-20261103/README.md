# Downstream MOLT gate observation

Keep all native Qwen3-4B MLPs. Remove only the natural L29-T2375 contribution at the final input ` is`, then compare the layer-specific MOLT gates at L30-L35 between native and ablated states for the same month, alphabet and Roman prompts.

`run.py` captures the post-attention residual before native `post_attention_layernorm`, which is the input expected by the MOLT checkpoint, and separately records the normalized tensor actually entering the native MLP. All later MLPs compute normally. Native/observed/zero controls and exact ablation repeats are included; block residuals must match the previous residual study exactly.

`analyze.py` applies each layer's own cached gate encoder and input mean/std to the captured final-position states, using FP64 and an independent FP32 active-mask audit. The six gate archives and original checkpoint tensor bytes were hash-verified in preparation. It retains raw scores, thresholds, all active/inactive gate values, signed changes, cached labels, complete active unions and source hashes. It does not need the low-rank UV operators or replace the native MLPs.

After verified collection, run:

```sh
python3 experiments/eleven-downstream-gates-20261103/analyze.py
python3 experiments/eleven-downstream-gates-20261103/render.py
```

The local HTML report has one six-row table per prompt, with native active gates, active gates after the L29 intervention, newly on/off sets, and largest scalar changes. Full active-union values and cached explanations expand below each table. The complete 44,640 case/layer/transform pairs are exported to CSV.

This is an observational downstream comparison. A gate increase, threshold crossing or suggestive cached label is not a measurement of the transform's full contribution or evidence that it causes the answer change.
