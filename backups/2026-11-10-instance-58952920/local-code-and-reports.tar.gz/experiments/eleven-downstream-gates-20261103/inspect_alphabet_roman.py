"""Audit original examples for alphabet/Roman switches and largest graded changes."""
import csv
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / 'comparisons/2026-11-03-eleven-downstream-gates/alphabet-roman-example-inspection'
OUT = ROOT / 'results/2026-11-03-eleven-downstream-gates'
targets_path = SOURCE / 'targets.json'
targets = json.loads(targets_path.read_text())
assert len(targets) == 19 and len({(r['layer'], r['transform']) for r in targets}) == 19
findings = {
    (32, 1181): 'Broad Christmas/Halloween/autumn contexts. Frequently active on prepositions, conjunctions and punctuation before seasonal content. No K/L or twelve-specific pattern established in the displayed selection.',
    (33, 391): 'Many strongest examples concern quantities and units such as ounces, plus mixed technical contexts. The broad list label is incomplete; no clear K/L or twelve-specific pattern was found.',
    (33, 587): 'Strong precursor examples before the word Twelve and literal 12, but also before 11 and 13, dates, chemistry and code. This is a numerical-sequence lead, not a twelve-selective feature. Medium/lower windows all repeat activation on the chat-start marker.',
    (33, 968): 'Strongly active on copulas is/was/are in ordinary prose. No clear K/L or twelve-specific activation pattern in the displayed windows.',
    (34, 666): 'Copulas in prose, particularly was/is and continuations such as still/all/only. No clear ordinal-specific pattern in the reviewed windows.',
    (34, 965): 'Strong before-K/k pattern across DISK, honky-tonk, 4K, 14k, Westerkerk and other words. This feature turns off in the alphabet experiment. The moderate/high programming window is a counterexample to a simple immediate-K-only description.',
    (35, 760): 'Strong before-K/k pattern across 8K, 14K, kg, Hawking, Maersk and Korea. This feature also turns off in the alphabet experiment. Some non-Latin windows contain undecodable fragments and are not used for the K interpretation.',
    (35, 1177): 'Mixed short fields, names, dates and output entities. One strongest window includes activation on the quote and digits of 11th Infantry Regiment, but no clear L/twelve precursor pattern.',
    (31, 50): 'Broad mathematical definitions and programming. A lower-strength window activates on the space immediately before 11 percent (0.531). This is a weak before-eleven example, not twelve specificity.',
    (32, 979): 'Mostly book/citation/title endings and entity fragments. No clear XI/XII-specific precursor pattern in the reviewed examples.',
    (33, 1873): 'Strongest examples often precede rhyming line endings such as tall, all, call, swell and whole. Other examples include a French word fragment and chat-start markers. No clear XI/XII pattern.',
    (34, 1837): 'Acronym/entity fragments, parentheses and HTML list formatting. No clear XI/XII or before-twelve pattern in the displayed examples.',
    (35, 1221): 'Several strong windows anticipate X or I/i in code: PIC X(10), Mouse X and loop-index i. The same Mouse example also activates before Y. This suggests a broad token/notation lead, not a XII-selective gate.',
    (34, 1440): 'Strong before-L/l pattern across a literal quoted l, 1L, London, Lab, -law, LA and code fragments. Gate increases in the alphabet experiment. A K. L. initials window has an intervening punctuation token.',
    (35, 2117): 'Strong before-L/l pattern across stapler, a literal quoted l, demi-glace, charlidamelio and dlon. Gate increases in the alphabet experiment. It shares the exact quote-before-l corpus coordinate with L34-T1440.',
    (33, 14): 'Many strongest windows anticipate K/k: 14k, kg, GKE/SKE, kinesis, knee and code variable k. Its gate decreases, while remaining active, in the alphabet experiment.',
    (35, 111): 'Strong Roman-numeral-format examples before XVIII, VIII, I and III, alongside many date/month prepositions. A lower window activates on the space before literal 12. This is a broad numeral/date lead, not XII specificity.',
    (33, 909): 'Broad lowercase institutional/entity names and grammatical bridges, including United Nations, OECD and IMF contexts. No clear XI/XII-specific pattern.',
    (32, 1082): 'Numerical/date/range contexts with varied values. Strong examples include a hyphen before the 11 in 2010-11, April before 11, and many 13/14/15 values. Broad numerical continuation evidence, not twelve specificity.',
}
# Group index, example index (zero-based), context radius, description.
selections = {
    (34, 965): [(0, 1, 2, 2, 'DIS before K'), (0, 3, 2, 2, '4 before K'), (0, 6, 2, 3, 'Counterexample: moderate/high input option')],
    (35, 760): [(0, 3, 2, 3, 'aw before king in Hawking'), (0, 6, 2, 2, '8 before K')],
    (33, 14): [(0, 4, 2, 3, '4 before k in 14k gold'), (0, 9, 1, 3, 'int before code variable k')],
    (34, 1440): [(0, 4, 2, 3, 'Quote immediately before literal l'), (0, 10, 2, 2, '1 immediately before L'), (0, 6, 1, 4, 'Initial K before dot then L')],
    (35, 2117): [(0, 0, 2, 2, 'stap before ler'), (0, 2, 2, 3, 'Same quote-before-l coordinate as L34-T1440')],
    (33, 587): [(0, 0, 2, 3, 'Quote before Twelve'), (0, 3, 2, 4, 'Equals sign then active space before 12'),
                (0, 2, 2, 3, 'Counterexample: space before 13'), (0, 8, 2, 3, 'Counterexample: space before September 11')],
    (35, 1221): [(0, 1, 2, 3, 'PIC before X'), (0, 3, 2, 2, 'Mouse before X; same window also contains Mouse before Y'), (0, 4, 2, 2, 'Semicolon before loop index i')],
    (35, 111): [(0, 0, 2, 3, 'Period before XVIII'), (0, 4, 2, 2, 'Henry before VIII'), (0, 9, 2, 2, 'Act before III'), (2, 5, 2, 3, 'Lower-strength space before literal 12')],
    (31, 50): [(2, 0, 2, 3, 'Lower-strength space before 11 percent')],
    (32, 1082): [(0, 0, 2, 3, 'Hyphen before 11 in the season 2010-11')],
    (33, 1873): [(0, 0, 2, 2, 'so before poetic tall')],
}
all_values = {}
with (OUT / 'all-gate-values.csv').open() as stream:
    for row in csv.DictReader(stream):
        all_values[(row['case'], int(row['layer']), int(row['transform']))] = row
review = {'scope': 'All 13 on/off switches in alphabet/Roman plus the top three absolute continuously-active gate changes per prompt, excluding L34-T1468 already inspected separately.',
          'source': 'Authenticated original dashboard: all 12 strongest, 6 medium and 6 lower-strength displayed windows per feature.',
          'timing': 'Square brackets mark the active token. Following token strings/IDs are recorded separately. Gate strengths in examples are rounded dashboard values.',
          'intervention_scope': 'No GPU inference or new intervention. These are examples from a separate corpus, related to the existing final-input is gate comparisons.',
          'features': [], 'source_sha256': {str(targets_path.relative_to(ROOT)): hashlib.sha256(targets_path.read_bytes()).hexdigest()}}
windows, token_count = 0, 0
for target in targets:
    layer, tid = target['layer'], target['transform']
    path = SOURCE / f'L{layer}-T{tid}.json'
    page = json.loads(path.read_text())
    assert page['title'].startswith(f'Layer {layer} · Transform {tid} ')
    assert page['all_tooltip_metadata_verified']
    assert [len(g['examples']) for g in page['groups']] == [12, 6, 6]
    assert target['explanation'] in page['header']
    assert re.search(r'/ 10,000,000 tokens', page['header'])
    selected = []
    for group in page['groups']:
        for example in group['examples']:
            ts = example['tokens']
            assert len({t['conversation'] for t in ts}) == 1
            assert [t['token_position'] for t in ts] == list(range(ts[0]['token_position'], ts[0]['token_position'] + len(ts)))
            assert all(isinstance(t['token_id'], int) and t['gate_display_rounded'] >= 0 for t in ts)
            windows += 1; token_count += len(ts)
    for gi, ei, left, right, note in selections.get((layer, tid), []):
        group = page['groups'][gi]; ts = group['examples'][ei]['tokens']
        i = max(range(len(ts)), key=lambda i: ts[i]['gate_display_rounded']); t = ts[i]
        excerpt = ''.join(x['display_token'] for x in ts[max(0, i-left):i]) + '[' + t['display_token'].replace(' ', '·') + ']' + ''.join(x['display_token'] for x in ts[i+1:i+right+1])
        selected.append({'group': group['name'], 'example_one_based': ei + 1, 'note': note,
                         'excerpt': excerpt, 'active_token': t, 'following_tokens': ts[i+1:i+right+1]})
    changes = {}
    for case in ['month', 'alphabet', 'roman']:
        row = all_values[(case, layer, tid)]
        changes[case] = {k: float(row[k]) for k in ['native_gate', 'off_gate', 'gate_delta']}
    record = {**target, 'url': page['url'], 'retrieved_at': page['retrieved_at'], 'finding': findings[(layer, tid)],
              'displayed_windows_reviewed': 24, 'live_description_matches_cache': True,
              'changes_across_three_prompts': changes, 'selected_evidence': selected}
    review['features'].append(record)
    review['source_sha256'][str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
assert windows == 456
lookup = {(f['layer'], f['transform']): f for f in review['features']}
k34 = lookup[(34, 965)]['selected_evidence'][0]
k35 = lookup[(35, 760)]['selected_evidence'][1]
assert k34['active_token']['display_token'] == ' DIS' and k34['following_tokens'][0]['token_id'] == 42
assert k35['active_token']['display_token'] == '8' and k35['following_tokens'][0]['token_id'] == 42
l34 = lookup[(34, 1440)]['selected_evidence'][0]
l35 = lookup[(35, 2117)]['selected_evidence'][1]
assert l34['active_token']['display_token'] == l35['active_token']['display_token'] == ' "'
assert (l34['active_token']['conversation'], l34['active_token']['token_position']) == (6035, 914)
assert (l35['active_token']['conversation'], l35['active_token']['token_position']) == (6035, 914)
assert l34['following_tokens'][0]['token_id'] == l35['following_tokens'][0]['token_id'] == 75
assert all(t['gate_display_rounded'] == 0 for t in [k34['following_tokens'][0], k35['following_tokens'][0], l34['following_tokens'][0], l35['following_tokens'][0]])
numeric = lookup[(33, 587)]['selected_evidence']
assert numeric[0]['following_tokens'][0]['display_token'] == 'Tw'
assert [t['token_id'] for t in numeric[1]['following_tokens'][:3]] == [220, 16, 17]
assert [t['token_id'] for t in numeric[2]['following_tokens'][:2]] == [16, 18]
mouse = json.loads((SOURCE / 'L35-T1221.json').read_text())['groups'][0]['examples'][3]['tokens']
assert any(t['display_token'] == 'Mouse' and mouse[i+1]['display_token'] == ' Y' and t['gate_display_rounded'] > 0 for i, t in enumerate(mouse[:-1]))
review['validation'] = {'status': 'pass', 'features': len(targets), 'windows': windows, 'token_tooltip_records': token_count,
                        'all_live_descriptions_match_cache': True, 'token_coordinates_contiguous': True,
                        'before_K_token_IDs_verified': True, 'shared_before_literal_l_coordinate_verified': True,
                        'T587_before_Twelve_12_and_13_timing_verified': True, 'T1221_Mouse_Y_counterexample_verified': True}
review['limitations'] = ['Displayed examples are a selected subset of a ten-million-token corpus, not an exhaustive selectivity test.',
                         'Before-K/L includes word fragments and case/whitespace variants; it is not a claim that every example predicts the exact answer BPE token.',
                         'Medium/lower windows for several features repeat chat-start markers and add limited semantic diversity.',
                         'These MOLT gates are diagnostics on native states; neither examples nor gate-value shifts establish a causal contribution direction.',
                         'No causal tests were run on these new candidates. Existing T1468 negative ablation/rescue results do not rule out these other features.']
(OUT / 'alphabet-roman-example-review.json').write_text(json.dumps(review, indent=2, ensure_ascii=False) + '\n')
lines = ['# Activating examples of changed alphabet and Roman gates', '',
         '**Alphabet: a coherent before-K down / before-L up pattern is visible in the examples.** L33-T14, L34-T965 and L35-T760 weaken or turn off; L34-T1440 and L35-T2117 strengthen. These activation observations are candidates for causal tests, not a demonstrated mechanism.', '',
         review['scope'], '', review['source'], '', review['timing'], '',
         '**Roman: broader numeral-format leads.** L35-T1221 has X and I/i code contexts (and a Y counterexample); L35-T111 precedes several Roman numerals as well as dates. No comparably clean XI-versus-XII separation was found in the displayed examples.', '',
         '**Shared numerical lead:** L33-T587 peaks before Twelve and 12, with clear 11/13 counterexamples. Its gate rises in both alphabet and Roman prompts, but falls in the month prompt, so it is not established as a general twelve feature.', '']
for case in ['alphabet', 'roman']:
    lines += [f'## {case.title()}', '', '| Feature | Native gate -> T2375 off | Observed example pattern |', '|---|---:|---|']
    for f in review['features']:
        if f['case'] != case: continue
        lines.append(f"| [L{f['layer']}-T{f['transform']}]({f['url']}) | {f['native_gate']:.6f} -> {f['off_gate']:.6f} | {f['finding']} |")
    lines += ['']
lines += ['## Selected token-level evidence', '', 'The next token is recorded separately from the active token; for example `[·DIS]K` means activation belongs to DIS, before K. A middle dot marks a space.', '']
for f in review['features']:
    if not f['selected_evidence']: continue
    lines += [f"### L{f['layer']}-T{f['transform']}", '', f"[Original examples]({f['url']})", '',
              '| Excerpt | Displayed gate | Conversation / token | Interpretation |', '|---|---:|---|---|']
    for e in f['selected_evidence']:
        t = e['active_token']
        lines.append(f"| `{e['excerpt']}` | {t['gate_display_rounded']:.3f} | {t['conversation']} / {t['token_position']} | {e['note']} |")
    lines += ['']
lines += ['## What remains to test', '',
          'The clearest alphabet follow-ups would preserve the native contributions of the K-related gates during T2375 ablation, or remove the L-related contributions individually. Roman candidates and the shared numerical T587 remain less specific. None of these causal follow-ups was performed here.', '',
          'The earlier failed T1468 rescue does not rule out these distinct candidates or combinations of them.', '', '## Limits', '']
lines += ['- ' + x for x in review['limitations']]
lines += ['', f"Validation: {len(targets)} features, {windows} displayed windows, {token_count} tooltip token records; all source identities, contiguous coordinates and label matches verified.", '',
          'Raw pages and SHA-256 hashes are preserved under comparisons/2026-11-03-eleven-downstream-gates/alphabet-roman-example-inspection/. Reproduce this audit: `python3 experiments/eleven-downstream-gates-20261103/inspect_alphabet_roman.py`.', '']
(OUT / 'ALPHABET_ROMAN_EXAMPLES.md').write_text('\n'.join(lines))
print(json.dumps({'validation': review['validation'], 'T587_cross_prompt_changes': lookup[(33, 587)]['changes_across_three_prompts']}, indent=2))
