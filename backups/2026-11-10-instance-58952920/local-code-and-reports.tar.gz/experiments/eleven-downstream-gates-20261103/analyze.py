"""Evaluate layer-specific MOLT gates on paired native-model input captures."""
import csv
import hashlib
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SOURCE = ROOT / 'comparisons/2026-11-03-eleven-downstream-gates/remote-export/eleven-downstream-gates-20261103'
OUT = ROOT / 'results/2026-11-03-eleven-downstream-gates'
OUT.mkdir(exist_ok=True)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


source_path = SOURCE / 'artifacts/results.json'
source = json.loads(source_path.read_text())
assert source['status'] == 'complete' and source['hooks_remaining'] == 0
assert source['protocol']['gate_layers'] == list(range(30, 36))
assert source['protocol']['later_MLPs_replaced'] is False
gate_manifest_path = HERE / 'gate-cache-manifest.json'
gate_manifest = json.loads(gate_manifest_path.read_text())
assert gate_manifest['revision'] == source['protocol']['molt_revision']
assert gate_manifest['NPZ_and_original_tensor_hashes_verified']
provenance = {str(source_path.relative_to(ROOT)): sha(source_path),
              str(gate_manifest_path.relative_to(ROOT)): sha(gate_manifest_path)}
captures = {}
audited_files = 0
references = json.loads((SOURCE / 'references.json').read_text())
assert sha(SOURCE / 'references.npz') == references['arrays_sha256']
with np.load(SOURCE / 'references.npz', allow_pickle=False) as archive:
    reference_arrays = {k: archive[k].copy() for k in archive.files}
for case in source['cases']:
    name, pos = case['case'], case['position']
    runs = {}
    for condition, row in case['runs'].items():
        p = SOURCE / 'artifacts' / row['arrays']['file']
        assert sha(p) == row['arrays']['sha256']
        provenance[str(p.relative_to(ROOT))] = sha(p)
        with np.load(p, allow_pickle=False) as a:
            runs[condition] = {k: a[k].copy() for k in a.files}
        audited_files += 1
    native, off = runs['native-observed'], runs['gate-off']
    assert np.array_equal(native['residuals'], reference_arrays[name + '_native_residuals'])
    assert np.array_equal(off['residuals'], reference_arrays[name + '_off_residuals'])
    assert np.array_equal(native['first_logits'], reference_arrays[name + '_native_logits'])
    assert np.array_equal(runs['native-unhooked']['first_logits'], native['first_logits'])
    for key in ['first_logits', 'residuals', 'later_molt_inputs', 'later_mlp_inputs']:
        assert np.array_equal(native[key], runs['zero-strength'][key])
        assert np.array_equal(off[key], runs['gate-off-repeat'][key])
    for key in ['later_molt_inputs', 'later_mlp_inputs']:
        assert native[key].shape == off[key].shape == (6, pos + 1, 2560)
        assert np.array_equal(native[key][:, :pos], off[key][:, :pos])
    captures[name] = {'metadata': case, 'native': native, 'off': off}

result = {'protocol': source['protocol'], 'runtime': source['runtime'], 'cases': [],
          'gate_evaluation': 'CPU FP64 encoder evaluation with separate FP32 membership and value audit. gate = raw if raw > learned threshold and raw > 0, else zero; raw = encoder @ ((post_attention_residual - mean) / std) + bias.',
          'scope': 'Final input is in native and L29-T2375-off runs; L30-L35 encoders are observed offline. Every later native MLP runs normally. No later gate or MLP is replaced.',
          'cached_labels': '21 October 2026 cache; titles/explanations are hypotheses about activation, not causal meanings.',
          'limitations': ['Gate activation is a scalar, not the full gate-times-operator contribution or a causal-effect ranking.',
                          'These downstream gate changes are observational; none of these later transforms has been intervened on.',
                          'Reported gate changes are within a layer; gate magnitudes are not calibrated effect sizes across layers.'],
          'source_sha256': provenance, 'analysis_sha256': sha(Path(__file__)), 'new_model_inference_for_gate_scoring': False}
case_rows = {name: [] for name in captures}
all_gate_rows, scalar_arrays = [], {}
max_raw_error = 0.
membership_checks = 0
for layer_index, layer in enumerate(range(30, 36)):
    asset = next(a for a in gate_manifest['layers'] if a['layer'] == layer)
    path = ROOT / asset['project_path']
    assert sha(path) == asset['sha256']
    provenance[str(path.relative_to(ROOT))] = sha(path)
    with np.load(path, allow_pickle=False) as a:
        w32 = {k: a[k].copy() for k in a.files}
    w64 = {k: v.astype(np.float64) for k, v in w32.items()}
    assert w64['encoder'].shape == (2480, 2560)
    label_path = ROOT / f'comparisons/2026-10-21-toxic-persona-survey/hf-labels/layer-{layer:02d}.jsonl'
    labels = {r['feature_id']: r for r in (json.loads(line) for line in label_path.read_text().splitlines() if line.strip())}
    assert len(labels) == 2480 and all(r['layer'] == layer for r in labels.values())
    provenance[str(label_path.relative_to(ROOT))] = sha(label_path)
    for name, capture in captures.items():
        pos = capture['metadata']['position']
        gates, raws = {}, {}
        for condition in ['native', 'off']:
            x32 = capture[condition]['later_molt_inputs'][layer_index, pos]
            z64 = (x32.astype(np.float64) - w64['mean']) / w64['std']
            raw64 = w64['encoder'] @ z64 + w64['bias']
            threshold64 = w64['threshold'].reshape(-1)
            active64 = (raw64 > threshold64) & (raw64 > 0)
            gate64 = np.where(active64, raw64, 0.)
            z32 = (x32 - w32['mean']) / w32['std']
            raw32 = w32['encoder'] @ z32 + w32['bias']
            active32 = (raw32 > w32['threshold'].reshape(-1)) & (raw32 > 0)
            assert np.array_equal(active32, active64), (name, layer, condition, 'threshold sensitivity')
            max_raw_error = max(max_raw_error, float(np.max(np.abs(raw64 - raw32))))
            membership_checks += len(active64)
            gates[condition], raws[condition] = gate64, raw64
            scalar_arrays[f'{name}_L{layer}_{condition}_raw'] = raw64
            scalar_arrays[f'{name}_L{layer}_{condition}_gate'] = gate64
        a, b = gates['native'], gates['off']
        delta = b - a
        union = np.flatnonzero((a > 0) | (b > 0))
        features = []
        for tid in range(2480):
            state = 'newly_on' if a[tid] == 0 and b[tid] > 0 else 'newly_off' if a[tid] > 0 and b[tid] == 0 else 'increased' if delta[tid] > 0 else 'decreased' if delta[tid] < 0 else 'unchanged'
            row = {'case': name, 'layer': layer, 'position': pos, 'transform': tid,
                   'label': labels[tid].get('title') or 'No cached title', 'threshold': float(threshold64[tid]),
                   'native_raw': float(raws['native'][tid]), 'off_raw': float(raws['off'][tid]),
                   'native_gate': float(a[tid]), 'off_gate': float(b[tid]), 'gate_delta': float(delta[tid]),
                   'native_threshold_margin': float(raws['native'][tid] - max(threshold64[tid], 0)),
                   'off_threshold_margin': float(raws['off'][tid] - max(threshold64[tid], 0)), 'change': state}
            all_gate_rows.append(row)
            if tid in union:
                row = dict(row)
                row.update(explanation=labels[tid].get('explanation', ''), label_status=labels[tid].get('status'))
                features.append(row)
        case_rows[name].append({'layer': layer,
                               'native_active': [r['transform'] for r in features if r['native_gate'] > 0],
                               'off_active': [r['transform'] for r in features if r['off_gate'] > 0],
                               'newly_on': [r['transform'] for r in features if r['change'] == 'newly_on'],
                               'newly_off': [r['transform'] for r in features if r['change'] == 'newly_off'],
                               'largest_changes': [r['transform'] for r in sorted(features, key=lambda r: (-abs(r['gate_delta']), r['transform']))[:5]],
                               'native_molt_input_l2': float(np.linalg.norm(capture['native']['later_molt_inputs'][layer_index, pos].astype(np.float64))),
                               'off_molt_input_l2': float(np.linalg.norm(capture['off']['later_molt_inputs'][layer_index, pos].astype(np.float64))),
                               'features': features})
for name, capture in captures.items():
    meta = capture['metadata']
    result['cases'].append({'case': name, 'prompt': meta['prompt'], 'position': meta['position'], 'token': ' is',
                            'native_first_token': meta['runs']['native-observed']['greedy_first_token'],
                            'off_first_token': meta['runs']['gate-off']['greedy_first_token'],
                            'L29_natural_gate': meta['runs']['gate-off']['natural_gate'], 'layers': case_rows[name]})
result['validation'] = {'status': 'pass', 'captured_array_files_hash_verified': audited_files,
                        'native_observer_zero_and_off_repeat_exact': True,
                        'all_block_residuals_match_previous_study_exactly': True,
                        'earlier_input_states_exactly_unchanged': True,
                        'native_MLPs_replaced': False, 'gate_layers': 6, 'transforms_per_layer': 2480,
                        'case_layer_transform_pairs': len(all_gate_rows), 'FP32_FP64_membership_checks': membership_checks,
                        'FP32_FP64_membership_disagreements': 0, 'FP32_FP64_raw_max_absolute_error': max_raw_error,
                        'gate_cache_and_original_checkpoint_tensor_hashes_verified': True}
(OUT / 'summary.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
(OUT / 'validation.json').write_text(json.dumps(result['validation'], indent=2) + '\n')
with (OUT / 'all-gate-values.csv').open('w', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(all_gate_rows[0]))
    writer.writeheader(); writer.writerows(all_gate_rows)
with (OUT / 'active-gate-changes.csv').open('w', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(all_gate_rows[0]))
    writer.writeheader(); writer.writerows(r for r in all_gate_rows if r['native_gate'] > 0 or r['off_gate'] > 0)
np.savez_compressed(OUT / 'gate-scores.npz', **scalar_arrays)

lines = ['# Downstream MOLT gates after L29-T2375 removal', '', result['scope'], '',
         'Native MLPs are unchanged. Each later MOLT encoder receives its own layer\'s post-attention residual before native post_attention_layernorm, using checkpoint mean/std. Gate values are scored offline in FP64; independent FP32 evaluation gives identical active sets.', '',
         'Labels are cached from 21 October and describe activation hypotheses. This is a gate comparison, not a measurement of full MOLT contributions or later-transform causal effects.', '']
for case in result['cases']:
    lines += [f"## {case['case'].title()}", '', f"Prompt: `{case['prompt']}`. Only input position {case['position']} (` is`) is directly edited at L29.", '',
              '| Layer | Native active gates | After L29-T2375 off | Largest gate changes |', '|---|---|---|---|']
    for row in case['layers']:
        lookup = {r['transform']: r for r in row['features']}
        def active(ids, key):
            return ', '.join(f"T{tid} ({lookup[tid][key]:.3f})" for tid in ids) or 'None'
        changes = '; '.join(f"T{tid}: {lookup[tid]['native_gate']:.3f} -> {lookup[tid]['off_gate']:.3f} ({lookup[tid]['gate_delta']:+.3f}); {lookup[tid]['label']}" for tid in row['largest_changes'])
        lines.append(f"| L{row['layer']} | {active(row['native_active'], 'native_gate')} | {active(row['off_active'], 'off_gate')} | {changes} |")
    lines += ['', 'Exact newly on/off sets and full labels, raw scores, thresholds and all active-gate values are in summary.json and the interactive table.', '']
lines += ['## Verification', '', json.dumps(result['validation'], indent=2), '',
          'All 44,640 case/layer/transform pairs are retained in all-gate-values.csv, including gates inactive in both conditions. Active-gate-changes.csv retains the full active union. No new native-model inference was required for the offline gate scoring, after the paired input captures.', '',
          'Reproduce: `python3 experiments/eleven-downstream-gates-20261103/analyze.py`, then `python3 experiments/eleven-downstream-gates-20261103/render.py`.', '',
          'These observations identify candidate downstream gates for follow-up; they do not establish which one mediates the answer change.']
(OUT / 'README.md').write_text('\n'.join(lines) + '\n')
print(json.dumps({'validation': result['validation'], 'cases': [
    {'case': c['case'], 'layers': [{'layer': r['layer'], 'native_active': r['native_active'], 'off_active': r['off_active'],
                                  'newly_on': r['newly_on'], 'newly_off': r['newly_off'],
                                  'top_changes': [{k: f[k] for k in ['transform', 'label', 'native_gate', 'off_gate', 'gate_delta']}
                                                  for f in sorted(r['features'], key=lambda f: -abs(f['gate_delta']))[:3]]}
                                 for r in c['layers']]}
    for c in result['cases']]}, indent=2))
