"""Audit original dashboard token windows and preserve a bounded evidence review."""
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / 'comparisons/2026-11-03-eleven-downstream-gates/activation-example-inspection'
OUT = ROOT / 'results/2026-11-03-eleven-downstream-gates'
changes = json.loads((OUT / 'summary.json').read_text())
month = next(c for c in changes['cases'] if c['case'] == 'month')
targets = [(30, 433), (31, 797), (31, 949), (34, 84)]
findings = {
    (30, 433): 'Broad calendar, seasonal and date contexts. Peaks include spaces before 28 days, leap-year divisor 4, February 31st and December 21st, as well as autumn and calendar names. The reviewed windows do not suggest eleven-specific or twelve-specific activation.',
    (31, 797): 'Strongest windows consistently concern snow, snowflakes, white winter landscapes and cold conditions. Peaks occur on prepositions before that content and on snow tokens themselves. This supports a winter-context lead for the month task, without establishing a twelve feature.',
    (31, 949): 'The strongest window peaks on of before December. Another strongest window peaks on and before 12 months, with an intervening space. A lower-strength window peaks on the space immediately before 12th in a horse-racing result. Counterexamples include June, a space before arithmetic result 24, and to before 8th grades. This is a concrete before-twelve lead with substantial broader activation.',
    (34, 84): 'Strong windows include x in dimension notation, in within in-depth, or between alternatives, and email/format boundaries. No clear before-eleven or before-twelve pattern appears in the reviewed windows; the broad connector explanation remains provisional.',
}
# Each selection is a displayed group/example, with a short token excerpt around its maximum.
selections = {
    (30, 433): [(0, 0, 1, 3, 'Space immediately before 28 days'),
                (0, 3, 1, 2, 'Space immediately before leap-year divisor 4'),
                (0, 9, 1, 3, 'Space immediately before December 21st')],
    (31, 797): [(0, 0, 1, 3, 'Preposition before deep snow'),
                (0, 2, 1, 2, 'Preposition before white winter landscape')],
    (31, 949): [(0, 0, 1, 2, 'Before December'),
                (0, 6, 2, 5, 'Before 12 months; one intervening space'),
                (2, 5, 1, 4, 'Space immediately before ordinal 12th'),
                (0, 1, 1, 2, 'Counterexample: before June'),
                (1, 0, 1, 3, 'Counterexample: space before arithmetic result 24'),
                (1, 3, 2, 4, 'Counterexample: to before 8th grades')],
    (34, 84): [(0, 0, 1, 2, 'Connector x in dimension notation'),
               (0, 3, 0, 3, 'Word fragment in before -depth'),
               (0, 2, 0, 3, 'Connector or before an alternative')],
}

review = {'scope': 'The four transforms newly on/off in the month experiment, inspected on the authenticated original dashboard.',
          'selection': 'All 12 strongest, 6 medium and 6 lower-strength displayed windows per feature were inspected. This is not an exhaustive scan of all active positions in the ten-million-token corpus.',
          'timing': 'Gate belongs to the displayed active token. Following text is examined separately. Displayed tooltip strengths are rounded to three decimals, not exact FP32 experiment values.',
          'inference': 'No model inference, GPU edits or downstream causal interventions were performed in this inspection.',
          'features': [], 'source_sha256': {}}
total_windows, total_tokens = 0, 0
for layer, tid in targets:
    path = SOURCE / f'L{layer}-T{tid}.json'
    page = json.loads(path.read_text())
    assert page['all_tooltip_metadata_verified']
    assert page['title'].startswith(f'Layer {layer} · Transform {tid} ')
    assert [len(g['examples']) for g in page['groups']] == [12, 6, 6]
    cached_change = next(f for r in month['layers'] if r['layer'] == layer for f in r['features'] if f['transform'] == tid)
    stats = re.search(r'Fires on ([\d,]+) / ([\d,]+) tokens', page['header'])
    assert stats and int(stats[2].replace(',', '')) == 10_000_000
    for group in page['groups']:
        for example in group['examples']:
            tokens = example['tokens']
            assert len({t['conversation'] for t in tokens}) == 1
            assert [t['token_position'] for t in tokens] == list(range(tokens[0]['token_position'], tokens[0]['token_position'] + len(tokens)))
            assert all(t['gate_display_rounded'] >= 0 and isinstance(t['token_id'], int) for t in tokens)
            total_windows += 1
            total_tokens += len(tokens)
    selected = []
    for group_index, example_index, left, right, note in selections[(layer, tid)]:
        group = page['groups'][group_index]
        example = group['examples'][example_index]
        tokens = example['tokens']
        maximum = max(t['gate_display_rounded'] for t in tokens)
        index = next(i for i, t in enumerate(tokens) if t['gate_display_rounded'] == maximum)
        token = tokens[index]
        excerpt_tokens = tokens[max(0, index - left): min(len(tokens), index + right)]
        before = ''.join(t['display_token'] for t in tokens[max(0, index - left):index])
        after = ''.join(t['display_token'] for t in tokens[index + 1:min(len(tokens), index + right)])
        selected.append({'group': group['name'], 'example_index_zero_based': example_index,
                         'active_token': token['display_token'], 'token_id': token['token_id'],
                         'conversation': token['conversation'], 'position': token['token_position'],
                         'gate_display_rounded': token['gate_display_rounded'],
                         'excerpt': before + '[' + token['display_token'].replace(' ', '·') + ']' + after,
                         'excerpt_tokens': excerpt_tokens, 'note': note})
    record = {'layer': layer, 'transform': tid, 'url': page['url'], 'live_label': cached_change['label'],
              'live_description_matches_saved_description': cached_change['explanation'] in page['header'],
              'displayed_windows_reviewed': 24, 'corpus_token_count_reported': 10_000_000,
              'active_token_count_reported': int(stats[1].replace(',', '')),
              'native_gate_in_month_prompt': cached_change['native_gate'], 'ablated_gate_in_month_prompt': cached_change['off_gate'],
              'finding': findings[(layer, tid)], 'selected_evidence': selected}
    assert record['live_description_matches_saved_description']
    review['features'].append(record)
    review['source_sha256'][str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()

lead = next(f for f in review['features'] if f['transform'] == 949 and f['layer'] == 31)
numeric = lead['selected_evidence'][1]
ordinal = lead['selected_evidence'][2]
assert numeric['active_token'] == ' and' and numeric['gate_display_rounded'] == 4.063
assert [t['token_id'] for t in numeric['excerpt_tokens'][-4:]] == [220, 16, 17, 3951]
assert ordinal['active_token'] == ' ' and ordinal['gate_display_rounded'] == .555
assert [t['token_id'] for t in ordinal['excerpt_tokens'][-3:]] == [16, 17, 339]
review['validation'] = {'status': 'pass', 'features': 4, 'windows': total_windows, 'token_tooltip_records': total_tokens,
                        'groups_per_feature': [12, 6, 6], 'coordinates_contiguous_within_windows': True,
                        'token_ids_and_displayed_strengths_present': True, 'live_descriptions_match_cache': True,
                        'T949_before_12_and_12th_token_sequences_verified': True}
review['analysis_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
(OUT / 'activation-example-review.json').write_text(json.dumps(review, indent=2, ensure_ascii=False) + '\n')

lines = ['# Activating-example review of the four switched month gates', '',
         'Inspected the authenticated original dashboard: 12 strongest, 6 medium and 6 lower-strength windows for each of four transforms. All 96 displayed windows were read, including exact active-token locations and following context. These are the original dashboard examples, not the separate 64-conversation preview.', '',
         '**The clearest before-twelve lead is L31-T949.** Its strongest window peaks before December; another strongest window activates before 12 months, and a lower-strength example activates immediately before 12th in a horse-racing result. It also activates before other months, numbers and ordinals, so these examples do not establish twelve selectivity.', '',
         'Square brackets mark the active token. A middle dot inside brackets denotes a space. Tooltip strengths are displayed rounded to three decimals.', '']
for feature in review['features']:
    lines += [f"## L{feature['layer']}-T{feature['transform']}: {feature['live_label']}", '',
              f"[Original dashboard examples]({feature['url']})", '',
              f"Month prompt gate: {feature['native_gate_in_month_prompt']:.6f} -> {feature['ablated_gate_in_month_prompt']:.6f} after L29-T2375 removal.", '',
              feature['finding'], '', '| Short source excerpt | Displayed gate | Location | Evidence |', '|---|---:|---|---|']
    for e in feature['selected_evidence']:
        lines.append(f"| `{e['excerpt']}` | {e['gate_display_rounded']:.3f} | Conversation {e['conversation']}, token {e['position']} | {e['note']}; {e['group']}, example {e['example_index_zero_based'] + 1} |")
    lines += ['']
lines += ['## What this suggests', '',
          'L31-T949 deserves a causal follow-up because it has genuine precursor timing for twelve-related completions, including a non-month ordinal example. The counterexamples remain essential: its displayed evidence also supports broad timeframe/range behavior.', '',
          'L31-T797 supplies a different lead: a winter-context change could fit a December preference in this month task. This is a hypothesis about the month case, not an explanation of the alphabet or Roman flips.', '',
          'Neither label descriptions nor activation examples show that these transforms cause the answer change. An appropriate next causal check would remove each newly active L31 contribution separately in the L29-T2375-off month run and measure November/December support. That intervention has not been run here.', '',
          'The scope is the displayed example selection, not every activation in the corpus. Full live label descriptions matched the saved descriptions. Original page URLs, retrieved timestamps, group identities, coordinates, token IDs and displayed strengths are preserved in the raw inspection records under comparisons/2026-11-03-eleven-downstream-gates/activation-example-inspection/. Their hashes and selected evidence are in activation-example-review.json.', '',
          'Reproduce the audit/report from those saved records: `python3 experiments/eleven-downstream-gates-20261103/inspect_examples.py`. No model inference or downstream intervention is performed.']
(OUT / 'ACTIVATION_EXAMPLES.md').write_text('\n'.join(lines) + '\n')
print(json.dumps({'validation': review['validation'], 'T949_evidence': lead['selected_evidence']}, ensure_ascii=False, indent=2))
