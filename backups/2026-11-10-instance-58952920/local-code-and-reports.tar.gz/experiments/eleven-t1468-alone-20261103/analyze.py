"""Verify isolated intervention arithmetic and exact candidate-prefix probabilities."""
import csv
import hashlib
import json
import re
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SOURCE = ROOT / 'comparisons/2026-11-03-eleven-t1468-alone/remote-export/eleven-t1468-alone-20261103'
OUT = ROOT / 'results/2026-11-03-eleven-t1468-alone'
OUT.mkdir(exist_ok=True)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def softmax(logits):
    x = logits.astype(np.float64)
    p = np.exp(x - x.max())
    return p / p.sum()


def bf16_round(x):
    x = np.asarray(x, dtype=np.float32)
    assert np.isfinite(x).all()
    bits = x.view(np.uint32)
    rounded = bits + np.uint32(0x7fff) + ((bits >> 16) & 1)
    return (rounded & np.uint32(0xffff0000)).view(np.float32)


source_path = SOURCE / 'artifacts/results.json'
source = json.loads(source_path.read_text())
assert source['status'] == 'complete' and source['hooks_remaining'] == 0
assert source['protocol']['layer'] == 34 and source['protocol']['transform'] == 1468
manifest_path = HERE / 'weights/manifest.json'
manifest = json.loads(manifest_path.read_text())
assert manifest['revision'] == source['protocol']['molt_revision']
assert sha(manifest_path) == source['runtime']['weights_manifest_sha256']
asset = manifest['features'][0]
weight_path = manifest_path.parent / asset['file']
assert sha(weight_path) == asset['sha256']
with np.load(weight_path, allow_pickle=False) as archive:
    w = {k: archive[k].copy() for k in archive.files}
provenance = {str(p.relative_to(ROOT)): sha(p) for p in [source_path, manifest_path, weight_path, Path(__file__)]}
rows, cases, responses = [], [], []
audited_files, audited_vectors = 0, 0
max_operator_error, max_contribution_error, max_probability_error = 0., 0., 0.


def answer_ordinal(name, text):
    if name == 'month':
        match = re.match(r'\s*(november|december)\b', text, re.I)
        return {'november': 11, 'december': 12}.get(match[1].lower()) if match else None
    if name == 'alphabet':
        match = re.match(r'\s*([kl])(?=\W|$)', text, re.I)
        return {'k': 11, 'l': 12}.get(match[1].lower()) if match else None
    match = re.match(r'\s*([ivxlcdm]+)\b', text, re.I)
    return {'xi': 11, 'xii': 12}.get(match[1].lower()) if match else None


for case in source['cases']:
    name, runs = case['case'], case['runs']
    assert all(case[k] for k in ['native_reference_and_observer_zero_controls_exact', 'ablation_repeat_exact',
                                 'L29_and_L34_gate_inputs_native_exact', 'earlier_input_MLP_outputs_and_final_residuals_unchanged'])
    arrays = {}
    score_by_run = {}
    for condition, row in runs.items():
        info = row['arrays']
        path = SOURCE / 'artifacts' / info['file']
        assert path.stat().st_size == info['bytes'] and sha(path) == info['sha256']
        provenance[str(path.relative_to(ROOT))] = info['sha256']
        with np.load(path, allow_pickle=False) as archive:
            a = {k: archive[k].copy() for k in archive.files}
        arrays[condition] = a
        audited_files += 1
        p = row['position']
        if 'L34_input' in a:
            z = (a['L34_input'].astype(np.float64) - w['input_mean'].astype(np.float64)) / w['input_std'].astype(np.float64)
            raw = z @ w['e'].astype(np.float64) + float(w['bias'][0])
            phi = np.where((raw > float(w['theta'][0])) & (raw > 0), raw, 0.)
            operator = (z @ w['V'].astype(np.float64) @ w['U'].astype(np.float64)) * w['output_std'].astype(np.float64)
            contribution = phi[:, None] * operator
            assert np.array_equal(phi > 0, a['gate'] > 0)
            assert np.allclose(raw, a['raw'], atol=1e-5, rtol=1e-5)
            assert np.allclose(operator, a['operator'], atol=2e-5, rtol=2e-5)
            assert np.allclose(contribution, a['contribution'], atol=3e-5, rtol=3e-5)
            max_operator_error = max(max_operator_error, float(np.abs(operator - a['operator']).max()))
            max_contribution_error = max(max_contribution_error, float(np.abs(contribution - a['contribution']).max()))
            audited_vectors += 1
        if row['strength'] is not None:
            assert row['edit_calls'] == 1 and row['edited_input_positions'] == [p]
            assert row['generated_positions_edited'] == []
            assert row['generated_passes_without_edit'] == len(row['steps']) - 1
            delta = -np.float32(row['strength']) * a['contribution'][p]
            assert np.array_equal(delta, a['intended_delta'])
            assert np.array_equal(bf16_round(a['native_mlp'][p] + delta), a['edited_mlp'][p])
            assert np.array_equal(a['native_mlp'][:p], a['edited_mlp'][:p])
            assert np.array_equal(a['edited_mlp'] - a['native_mlp'], a['actual_delta'])
        else:
            assert row['edit_calls'] == 0
        candidate_texts = sum(source['protocol']['probes'][name].values(), [])
        ids = [row['candidate_scores'][t]['token_ids'] for t in candidate_texts]
        assert all(not (a_ids == b_ids[:len(a_ids)]) for i, a_ids in enumerate(ids) for j, b_ids in enumerate(ids) if i != j), 'Candidate token-prefix events overlap'
        scored = {}
        for index, text in enumerate(candidate_texts):
            candidate = row['candidate_scores'][text]
            independent = [float(softmax(a['first_logits'])[candidate['token_ids'][0]])]
            for j, token_id in enumerate(candidate['token_ids'][1:], 1):
                independent.append(float(softmax(a[f'candidate_{index}_step_{j}'])[token_id]))
            error = float(np.max(np.abs(np.array(independent) - candidate['conditional_probabilities'])))
            max_probability_error = max(max_probability_error, error)
            assert error < 1e-6
            assert float(np.prod(candidate['conditional_probabilities'], dtype=np.float64)) == candidate['probability']
            scored[text] = candidate['probability']
        scores = {ordinal: sum(scored[t] for t in texts) for ordinal, texts in source['protocol']['probes'][name].items()}
        assert sum(scores.values()) <= 1.000001
        score_by_run[condition] = scores
        rows.append({'case': name, 'condition': condition, 'prompt': row['prompt'], 'edited_position': p,
                     'native_gate': row.get('natural_gate'), 'P_11_answer_prefix': scores['11'],
                     'P_12_answer_prefix': scores['12'], 'initial_answer_ordinal': answer_ordinal(name, row['response']),
                     'response': row['response'], 'stop_reason': row['stop_reason']})
    native, off = runs['native'], runs['T1468-off']
    for control in ['observed', 'zero-strength']:
        assert native['steps'] == runs[control]['steps'] and native['candidate_scores'] == runs[control]['candidate_scores']
    assert off['steps'] == runs['T1468-off-repeat']['steps']
    assert off['candidate_scores'] == runs['T1468-off-repeat']['candidate_scores']
    for key, value in arrays['T1468-off'].items():
        assert np.array_equal(value, arrays['T1468-off-repeat'][key])
    for condition in ['zero-strength', 'T1468-off', 'T1468-off-repeat']:
        assert np.array_equal(arrays['observed']['L29_input'], arrays[condition]['L29_input'])
        assert np.array_equal(arrays['observed']['L34_input'], arrays[condition]['L34_input'])
    p = off['position']
    assert np.array_equal(arrays['observed']['pre_final_norm'][:p], arrays['T1468-off']['pre_final_norm'][:p])
    record = {'case': name, 'prompt': case['prompt'], 'position': p, 'token': ' is',
              'natural_gate': off['natural_gate'], 'removed_contribution_l2': off['contribution_l2'],
              'native': {'response': native['response'], 'initial_answer_ordinal': answer_ordinal(name, native['response']),
                         'probabilities': score_by_run['native']},
              'T1468_off': {'response': off['response'], 'initial_answer_ordinal': answer_ordinal(name, off['response']),
                            'probabilities': score_by_run['T1468-off']},
              'flips_11_to_12': answer_ordinal(name, native['response']) == 11 and answer_ordinal(name, off['response']) == 12,
              'greedy_output_token_ids_identical': native['output_token_ids'] == off['output_token_ids'],
              'logodds_11_vs_12_change': float(np.log(score_by_run['T1468-off']['11'] / score_by_run['T1468-off']['12']) - np.log(score_by_run['native']['11'] / score_by_run['native']['12'])),
              'P12_change_percentage_points': 100 * (score_by_run['T1468-off']['12'] - score_by_run['native']['12'])}
    cases.append(record)
validation = {'status': 'pass', 'array_files_hash_verified': audited_files,
              'independent_CPU_MOLT_evaluations': audited_vectors,
              'max_absolute_operator_error': max_operator_error, 'max_absolute_contribution_error': max_contribution_error,
              'independent_BF16_subtraction_rounding_exact': True,
              'max_absolute_independent_prefix_probability_error': max_probability_error,
              'native_reference_observer_and_zero_controls_exact': True, 'off_repeat_exact': True,
              'upstream_L29_and_L34_gate_inputs_native_exact': True, 'only_final_input_position_edited': True,
              'all_generated_positions_unedited': True, 'earlier_input_final_residuals_unchanged': True,
              'candidate_token_prefix_events_disjoint': True}
result = {'protocol': source['protocol'], 'runtime': source['runtime'], 'cases': cases, 'validation': validation,
          'source_sha256': provenance, 'flips': sum(c['flips_11_to_12'] for c in cases),
          'all_captured_greedy_output_token_ids_identical': all(c['greedy_output_token_ids_identical'] for c in cases),
          'limits': ['Three selected raw completion prefixes; no claim of generality.',
                     'Ablation subtracts one MOLT approximation contribution from the native MLP; native MLPs are not replaced.',
                     'Probabilities are specified answer-prefix events, including all tokens of XI/XII, not EOS-terminated answer probabilities.',
                     'Full raw continuations are retained even when they repeat or hit the 24-token limit. Initial-answer changes are classified separately.']}
(OUT / 'summary.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
(OUT / 'validation.json').write_text(json.dumps(validation, indent=2) + '\n')
with (OUT / 'probabilities-and-responses.csv').open('w', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
lines = ['# L34-T1468 alone off at final input is', '', source['protocol']['edit_scope'], '',
         f"**{result['flips']} of 3 initial answers changed from eleven to twelve.**", '',
         '| Prompt family | Native first answer -> T1468 off | P(eleven answer), native -> off | P(twelve answer), native -> off |', '|---|---|---:|---:|']
answer_names = {'month': {11: 'November', 12: 'December'}, 'alphabet': {11: 'K', 12: 'L'}, 'roman': {11: 'XI', 12: 'XII'}}
for c in cases:
    a, b = c['native'], c['T1468_off']
    answers = f"{answer_names[c['case']].get(a['initial_answer_ordinal'], 'other')} -> {answer_names[c['case']].get(b['initial_answer_ordinal'], 'other')}"
    lines.append(f"| {c['case']} | {answers} | {100*a['probabilities']['11']:.4f}% -> {100*b['probabilities']['11']:.4f}% | {100*a['probabilities']['12']:.4f}% -> {100*b['probabilities']['12']:.4f}% |")
lines += ['', 'Probability definition: ' + source['protocol']['probability_definition'], '',
          'Roman XI/XII include every token of the listed prefixes, rather than using the probability of the shared-looking x prefix. Each candidate is scored from that condition’s prefill cache without further interventions.', '',
          f"All captured greedy token sequences identical to native after ablation: {result['all_captured_greedy_output_token_ids_identical']}.", '',
          'A change in P(eleven) alone does not determine the eleven-versus-twelve preference, because both answer probabilities can move together. Exact changes in their log probability ratio are retained in summary.json.', '']
for c in cases:
    lines += [f"## {c['case'].title()}", '', f"Prompt: `{c['prompt']}`", '',
              f"Only L34-T1468 at input position {c['position']} (` is`) was removed. Natural gate {c['natural_gate']:.6f}; removed contribution L2 {c['removed_contribution_l2']:.6f}.", '',
              'Native continuation:', '', '```text', c['native']['response'], '```', '',
              'T1468-off continuation:', '', '```text', c['T1468_off']['response'], '```', '']
lines += ['## Verification and limits', '',
          'Native first logits and layer inputs reproduce the saved anchors. Native, read-only observer and zero-strength continuations/probabilities are exact. Each ablation repeats exactly. Independent CPU checks reproduce the MOLT contribution and the BF16 edit rounding; candidate probabilities are recomputed from saved logits.', '']
lines += ['- ' + text for text in result['limits']]
lines += ['', 'Code: experiments/eleven-t1468-alone-20261103/. Raw captures and source hashes are retained under comparisons/2026-11-03-eleven-t1468-alone/.', '']
(OUT / 'README.md').write_text('\n'.join(lines))
print(json.dumps({'cases': cases, 'validation': validation, 'flips': result['flips']}, indent=2))
