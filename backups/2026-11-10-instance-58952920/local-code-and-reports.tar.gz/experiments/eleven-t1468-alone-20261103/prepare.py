"""Fetch only the pinned L34-T1468 operator; audit cached encoder/standardizers."""
import concurrent.futures
import hashlib
import json
import shutil
import struct
import time
from pathlib import Path

import numpy as np
import requests

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
W = HERE / 'weights'
W.mkdir(exist_ok=True)
REV = '081ce901b090b64aeecf9bc8709b57c10411e32a'
URL = f'https://huggingface.co/georglange/qwen3-4b-molt/resolve/{REV}/layer-34/checkpoint.safetensors'
CACHE = ROOT / 'experiments/ch-alllayer-causal-screen/gates'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fetch(start, end):
    for attempt in range(3):
        try:
            response = requests.get(URL + f'?t1468_slice={start}-{end}&n={time.time_ns()}',
                                    headers={'Range': f'bytes={start}-{end}'}, timeout=35)
            response.raise_for_status()
            assert response.status_code == 206
            assert response.headers['Content-Range'].startswith(f'bytes {start}-{end}/')
            assert len(response.content) == end - start + 1
            return response.content
        except Exception:
            if attempt == 2:
                raise
            time.sleep(attempt + 1)


manifest_path = ROOT / 'experiments/eleven-downstream-gates-20261103/gate-cache-manifest.json'
cache_manifest = json.loads(manifest_path.read_text())
assert cache_manifest['revision'] == REV and cache_manifest['NPZ_and_original_tensor_hashes_verified']
asset = next(a for a in cache_manifest['layers'] if a['layer'] == 34)
cache_path = ROOT / asset['project_path']
assert sha(cache_path) == asset['sha256']
with np.load(cache_path, allow_pickle=False) as archive:
    gates = {k: archive[k].copy() for k in archive.files}
for short, key in [('encoder', 'e.weight'), ('bias', 'e.bias'), ('threshold', 'nonlinearity.theta'),
                   ('mean', 'input_standardizer.mean'), ('std', 'input_standardizer.std'), ('outstd', 'output_standardizer.std')]:
    record = next(r for r in asset['records'] if r['key'] == key)
    value = gates[short]
    if record['source_dtype'] == 'BF16':
        bits = value.view(np.uint32)
        assert np.all((bits & 65535) == 0)
        blob = (bits >> 16).astype('<u2').tobytes()
    else:
        assert record['source_dtype'] == 'F32'
        blob = value.astype('<f4').tobytes()
    assert hashlib.sha256(blob).hexdigest() == record['sha256'], short

first = fetch(0, 65535)
size = struct.unpack('<Q', first[:8])[0]
assert size < len(first) - 8
header = json.loads(first[8:8 + size])
assert header == json.loads((CACHE / 'layer-34-header.json').read_text())
(W / 'layer-34-header.json').write_text(json.dumps(header, indent=2) + '\n')
arrays = {'e': gates['encoder'][1468], 'bias': gates['bias'][1468:1469],
          'theta': gates['threshold'].reshape(-1)[1468:1469],
          'input_mean': gates['mean'], 'input_std': gates['std'], 'output_std': gates['outstd']}


def operator(role):
    shape = (32, 2560) if role == 'U' else (2560, 32)
    key = role + 's.4'
    spec = header[key]
    assert spec['dtype'] == 'F32' and spec['shape'] == [1280, *shape]
    # Rank groups have sizes 80,160,320,640,1280; T1468 is index 268 in the last group.
    start = 8 + size + spec['data_offsets'][0] + (1468 - 1200) * 32 * 2560 * 4
    end = start + 32 * 2560 * 4 - 1
    blob = fetch(start, end)
    value = np.frombuffer(blob, dtype='<f4').copy().reshape(shape)
    assert np.isfinite(value).all()
    return role, value, {'source_tensor': key, 'feature_index_in_group': 268,
                         'byte_range_inclusive': [start, end], 'slice_sha256': hashlib.sha256(blob).hexdigest()}


with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    fetched = list(pool.map(operator, ['U', 'V']))
for role, value, _ in fetched:
    arrays[role] = value
path = W / 'L34-T1468.npz'
np.savez_compressed(path, **arrays)
(W / 'manifest.json').write_text(json.dumps({
    'repo': 'georglange/qwen3-4b-molt', 'revision': REV, 'checkpoint_url': URL,
    'whole_checkpoint_not_downloaded': True, 'header_matches_original_cache': True,
    'cached_encoder_and_standardizers_original_tensor_hashes_verified': True,
    'source_gate_cache_sha256': asset['sha256'], 'source_gate_records': asset['records'],
    'features': [{'layer': 34, 'transform': 1468, 'rank': 32, 'file': path.name,
                  'bytes': path.stat().st_size, 'sha256': sha(path), 'operator_records': [r[2] for r in fetched]}]}, indent=2) + '\n')

prior = ROOT / 'experiments/eleven-gate-coactivation-20261103'
for name in ['expected-base-verification.json', 'anchors.json', 'anchors.npz']:
    shutil.copy2(prior / name, HERE / name)
protocol = {'date_local': '2026-11-03', 'model': 'Qwen/Qwen3-4B',
            'base_revision': '1cfa9a7208912126459214e8b04321603b3df60c', 'molt_revision': REV,
            'layer': 34, 'transform': 1468, 'target_gate': 0., 'max_new_tokens': 24,
            'maximum_runtime_minutes': 15, 'prompt_format': 'raw',
            'edit_scope': 'Subtract only the natural L34-T1468 contribution at final input is. L29-T2375 untouched. Later native layers compute normally. No generated-token edits.',
            'edit_arithmetic': 'z=(post-attention residual-input_mean)/input_std; phi=raw if raw>theta and raw>0 else 0; operator=(z@V@U)*output_std; edited_MLP=(native_MLP.float()-phi*operator).to(BF16), only at final input position.',
            'conditions': ['native', 'observed', 'zero-strength', 'T1468-off', 'T1468-off-repeat'],
            'probes': {'month': {'11': [' november', ' November'], '12': [' december', ' December']},
                       'alphabet': {'11': [' k', ' K'], '12': [' l', ' L']},
                       'roman': {'11': [' xi', ' XI'], '12': [' xii', ' XII']}},
            'probability_definition': 'Sum of exact leading-space lower/title-case answer-prefix token-sequence probabilities. Multi-token candidates are teacher-forced from the corresponding prefill cache without additional edits. Punctuation, EOS and other spellings are excluded.'}
(HERE / 'protocol.json').write_text(json.dumps(protocol, indent=2) + '\n')
print(json.dumps({'feature': 'L34-T1468', 'operator_bytes_downloaded': 2 * 32 * 2560 * 4,
                  'feature_asset_sha256': sha(path), 'source_tensors_verified': True}))
