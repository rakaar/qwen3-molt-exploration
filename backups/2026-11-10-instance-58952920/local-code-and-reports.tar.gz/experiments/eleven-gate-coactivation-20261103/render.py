"""Standalone scatter figure and local, filterable token-level view."""
import html
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'results/2026-11-03-eleven-gate-coactivation'
s = json.loads((OUT / 'summary.json').read_text())
stats = s['statistics']
colors = {'month': '#c45c35', 'alphabet': '#188575', 'roman': '#4269b2', 'other': '#8c829b'}
labels = {'month': 'Month', 'alphabet': 'Alphabet', 'roman': 'Roman numeral', 'other': 'Other domains'}


def group(row):
    return row['domain'] if row['domain'] in colors else 'other'


fig, axes = plt.subplots(1, 2, figsize=(13.8, 7.3), gridspec_kw={'width_ratios': [1.3, 1]})
fig.subplots_adjust(left=.065, right=.98, top=.82, bottom=.23, wspace=.24)
for ax, last_only in zip(axes, [False, True]):
    data = [r for r in s['tokens'] if r['plotted'] and (not last_only or r['last_input'])]
    for family in colors:
        for final in [False, True]:
            rows = [r for r in data if group(r) == family and r['last_input'] == final]
            if rows:
                ax.scatter([r['L29_T2375_gate'] for r in rows], [r['L34_T1468_gate'] for r in rows],
                           color=colors[family], marker='D' if final else 'o', s=43 if final else 27,
                           alpha=.78 if final else .55, edgecolors='white', linewidths=.5, zorder=3)
    ax.axhline(0, color='#a7aab1', lw=.8)
    ax.axvline(0, color='#a7aab1', lw=.8)
    ax.grid(alpha=.17)
    ax.set_axisbelow(True)
    ax.set_xlim(-.08, max(r['L29_T2375_gate'] for r in s['tokens']) * 1.12)
    ax.set_ylim(-.10, max(r['L34_T1468_gate'] for r in s['tokens']) * 1.13)
    ax.set_xlabel('L29–T2375 gate, phi(x)', labelpad=9)
    ax.set_ylabel('L34–T1468 gate, phi(x)', labelpad=8)
    ax.set_title(('All input tokens' if not last_only else 'Final input token only') + f' · {len(data)} retained points', loc='left', fontsize=12, pad=13)
    for side in ['top', 'right']:
        ax.spines[side].set_visible(False)
    if last_only:
        offsets = {'month': (-65, 27), 'alphabet': (15, -25), 'roman': (15, 16)}
        for domain in ['month', 'alphabet', 'roman']:
            prompt = {'month': 'the eleventh month of the year is',
                      'alphabet': 'the eleventh letter of the english alphabet is',
                      'roman': 'the eleventh positive integer in roman numerals is'}[domain]
            row = next(r for r in data if r['format'] == 'raw' and r['prompt'] == prompt)
            ax.annotate(labels[domain] + ' “is”', (row['L29_T2375_gate'], row['L34_T1468_gate']),
                        xytext=offsets[domain], textcoords='offset points', fontsize=9, color=colors[domain],
                        arrowprops={'arrowstyle': '-', 'color': colors[domain], 'lw': .7}, zorder=5)
fig.suptitle('Do the two gates coactivate on eleven-related prompts?', x=.065, y=.96, ha='left', fontsize=18, fontweight='bold')
legend = [Line2D([], [], color=colors[k], marker='o', ls='', label=labels[k], markersize=7) for k in colors]
legend += [Line2D([], [], color='#555', marker='D', ls='', label='Final input token', markersize=6)]
fig.legend(handles=legend, loc='lower center', bbox_to_anchor=(.5, .025), ncol=5, frameon=False, fontsize=10)
fig.supxlabel(f"Native model · {stats['prompts']} unique prompts · {stats['input_tokens']} input tokens · only exact (0, 0) pairs omitted\nSame token position across layers; gate scalars, not operator contributions or causal support.", fontsize=9, y=.095)
fig.savefig(OUT / 'gate-coactivation.png', dpi=190, bbox_inches='tight')
fig.savefig(OUT / 'gate-coactivation.svg', bbox_inches='tight')
plt.close(fig)

counts = stats['counts']
lines = ['# Natural coactivation of L29-T2375 and L34-T1468', '',
         f"Measured all input tokens in **{stats['prompts']} distinct historical eleven-related inputs**, spanning five languages, ten domains and raw/chat formats. Both gates are scored on the unmodified native model. No ablation or new generation was performed.", '',
         '![Gate coactivation](gate-coactivation.png)', '',
         '[Interactive scatter](index.html) · [All token pairs, including zeros](all-token-pairs.csv) · [Plotted points](plotted-token-pairs.csv) · [Prompt summary](prompt-summary.csv)', '',
         '**One point = the same prompt and token position in L29 and L34.** x is L29-T2375 and y is L34-T1468. Values use each checkpoint encoder, learned threshold and input standardizers. No UVx, contribution normalization or final RMSNorm is applied.', '',
         f"Of {stats['input_tokens']} input-token pairs, {counts.get('both_active', 0)} have both gates active, {counts.get('T2375_only', 0)} have only T2375 active, {counts.get('T1468_only', 0)} have only T1468 active and {counts.get('both_zero', 0)} have both zero. Only the last group is omitted from the scatter. It remains in the downloadable data.", '',
         f"T2375 activates somewhere in {stats['prompts_with_any_T2375']}/{stats['prompts']} prompts; T1468 in {stats['prompts_with_any_T1468']}/{stats['prompts']}; both activate at the same token in {stats['prompts_with_same_token_coactivation']}/{stats['prompts']} prompts.", '',
         f"Pearson r is {stats['Pearson_plotted_subset_excluding_double_zeros']:.3f} among the retained points and {stats['Pearson_all_input_tokens_including_double_zeros']:.3f} when all double-zero points are included. The higher zero-inclusive value partly reflects shared silence; these dependent token observations do not support a significance claim.", '',
         '## Interpretation limits', '']
lines += ['- ' + x for x in s['limitations']]
lines += ['', 'The scatter checks coactivation. Positive coactivation does not by itself show that either transform supports the eleven answer, and this eleven-only set does not establish ordinal specificity.', '',
          '## Verification', '',
          f"All {stats['prompts']} captures have SHA-256-verified files and exact unhooked/observed full-vocabulary logits at the final input position. The three original month/alphabet/Roman inputs also reproduce their prior native input states and logits exactly and repeat exactly. FP32/FP64 evaluation agrees on every one of {s['validation']['FP32_FP64_membership_checks']} gate membership decisions.", '',
          '## Original reference prompts', '', '| Prompt | L29-T2375 at final is | L34-T1468 at final is |', '|---|---:|---:|']
for prompt in ['the eleventh month of the year is', 'the eleventh letter of the english alphabet is', 'the eleventh positive integer in roman numerals is']:
    p = next(p for p in s['prompts'] if p['prompt'] == prompt and p['format'] == 'raw')
    lines.append(f"| `{prompt}` | {p['last_T2375']:.6f} | {p['last_T1468']:.6f} |")
lines += ['', '## Reproduce', '',
          'Source: experiments/eleven-gate-coactivation-20261103/. Build the catalog, capture native layer-specific inputs on the pinned model, then run analyze.py and render.py. catalog.json enumerates every included prompt and its historical source; summary.json retains source hashes, raw encoder scores and all zero pairs.', '']
(OUT / 'README.md').write_text('\n'.join(lines))

payload = json.dumps(s, ensure_ascii=False).replace('<', '\\u003c')
page = r'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Eleven prompts · two-gate coactivation</title><style>
*{box-sizing:border-box}body{margin:0;background:#f6f5f1;color:#222b32;font:16px/1.55 system-ui,sans-serif}main{max-width:1300px;margin:auto;padding:34px 28px}h1{font-size:32px;line-height:1.2;margin:8px 0 15px}h2{font-size:21px;margin-top:34px}.eyebrow{color:#67737b;font-size:13px;letter-spacing:.1em;text-transform:uppercase}.intro{max-width:1000px;margin-bottom:24px}.stats{display:flex;gap:12px;flex-wrap:wrap;margin:20px 0}.stat{background:white;border:1px solid #deded7;border-radius:9px;padding:12px 18px}.stat strong{font-size:24px;margin-right:6px}.filters{display:flex;flex-wrap:wrap;gap:12px;align-items:end;background:#fff;padding:17px;border:1px solid #deded7;border-radius:10px}label{font-size:13px;display:grid;gap:5px}select,input[type=search]{font:inherit;font-size:14px;padding:8px 10px;border:1px solid #bec6c9;border-radius:5px;max-width:240px}.check{display:flex;gap:6px;align-items:center;padding:8px}.chart{background:#fff;border:1px solid #deded7;border-radius:10px;margin-top:15px;padding:15px 16px 5px}svg{width:100%;height:auto;display:block;overflow:visible}.legend{display:flex;flex-wrap:wrap;gap:17px;font-size:14px;padding:6px 12px}.dot{width:10px;height:10px;display:inline-block;border-radius:50%;margin-right:6px}.note{color:#5a676f;font-size:14px}.detail{background:#eaf0ee;border-radius:8px;padding:16px;margin-top:14px;min-height:100px;overflow-wrap:anywhere}.detail p{margin:5px 0}code{background:#fff8;padding:2px 4px;white-space:pre-wrap}.summary{overflow-x:auto}table{width:100%;border-collapse:collapse;background:white;font-size:13px;margin:14px 0}th,td{text-align:left;padding:10px 12px;border-bottom:1px solid #e4e7e5;vertical-align:top}th{background:#eef0ec}td.prompt{min-width:280px;max-width:550px}a{color:#246c82}button{font:inherit;border:1px solid #b9c3c7;background:white;padding:7px 11px;border-radius:5px;cursor:pointer}circle.point,polygon.point{cursor:crosshair}circle.point:hover,polygon.point:hover{stroke:#172b38;stroke-width:2.5}.downloads{display:flex;flex-wrap:wrap;gap:18px;margin:18px 0}.small{font-size:13px} @media(max-width:650px){main{padding:20px 14px}h1{font-size:26px}.chart{padding:5px}.filters{gap:8px}label{max-width:100%}}
</style><main><div class="eyebrow">Qwen3-4B · native activations · 3 November 2026</div><h1>Do the two gates coactivate on eleven prompts?</h1>
<p class="intro">Each dot pairs <strong>L29–T2375</strong> and <strong>L34–T1468</strong> at the <strong>same input token</strong>. Single-axis points are kept; only exact (0, 0) pairs are hidden. No prompt maxima are paired. No gates are manipulated in this experiment.</p>
<div class="stats" id="stats"></div><div class="filters">
<label>Domain<select id="domain"><option value="">All domains</option></select></label><label>Language<select id="language"><option value="">All languages</option></select></label><label>Format<select id="format"><option value="">Raw + chat</option><option value="raw">Raw completion</option><option value="chat">Chat question</option></select></label>
<label>Find a prompt<input id="search" type="search" placeholder="Prompt text…"></label><label class="check"><input id="final" type="checkbox">Final input token only</label><label class="check"><input id="content" type="checkbox">Exclude chat wrapper tokens</label><button id="reset">Reset</button></div>
<div class="chart"><div class="legend"><span><i class="dot" style="background:#c45c35"></i>Month</span><span><i class="dot" style="background:#188575"></i>Alphabet</span><span><i class="dot" style="background:#4269b2"></i>Roman numeral</span><span><i class="dot" style="background:#8c829b"></i>Other domains</span><span>◆ Final input token · ● Earlier input token</span></div><svg id="plot" viewBox="0 0 1000 600" role="img" aria-label="Scatter: L29 T2375 gate on x axis; L34 T1468 gate on y axis"></svg></div>
<div class="detail" id="detail" aria-live="polite">Hover or focus a point to see its prompt, token position and gate values. Overlapping points are listed together.</div><p class="note" id="visible"></p>
<div class="downloads"><a href="gate-coactivation.png">Download figure</a><a href="all-token-pairs.csv">All token pairs, including zeros</a><a href="plotted-token-pairs.csv">Plotted points</a><a href="prompt-summary.csv">Prompt summary</a></div>
<h2>What this measures</h2><p>These are gate scalars <strong>phi(x)</strong>, calculated from each layer’s own native post-attention residual using that checkpoint’s encoder, standardizers and learned threshold. They are not UVx or the full MOLT contribution. Native MLPs remain unchanged.</p>
<p>Coactivation is evidence of a relationship in these inputs; it does not show that both transforms support the eleven answer. This historical eleven-only set includes inactive gates and native capability failures. It does not establish eleven specificity. Generated continuations are excluded.</p>
<h2>All included prompts</h2><p class="note">The table follows the domain, language, format and text filters. Counts refer to every input token, including chat wrappers; the final-token and wrapper checkboxes filter only the scatter.</p><div class="summary"><table><thead><tr><th>Prompt</th><th>Domain / language / format</th><th>Both active</th><th>Only T2375</th><th>Only T1468</th><th>Both zero</th></tr></thead><tbody id="prompts"></tbody></table></div>
<h2>Checks and limits</h2><p id="checks"></p><p class="note">Token points from related prompts are dependent. No statistical significance or causal claim is made. Removing (0, 0) points changes the displayed sample, so the complete zero-inclusive data are preserved.</p><p class="small"><a href="README.md">Methods and interpretation</a> · <a href="summary.json">Exact values, scope and provenance</a></p></main>
<script id="data" type="application/json">__PAYLOAD__</script><script>
const S=JSON.parse(document.querySelector('#data').textContent),$=id=>document.getElementById(id),C={month:'#c45c35',alphabet:'#188575',roman:'#4269b2',other:'#8c829b'},NS='http://www.w3.org/2000/svg';
for(const key of ['domain','language'])for(const v of [...new Set(S.prompts.map(p=>p[key]))].sort()){const o=document.createElement('option');o.value=v;o.textContent=v;$(key).append(o)}
function el(name,attrs={},text=''){const e=document.createElementNS(NS,name);for(const[k,v]of Object.entries(attrs))e.setAttribute(k,v);if(text)e.textContent=text;return e}
function match(r){return ['domain','language','format'].every(k=>!$(k).value||r[k]===$(k).value)&&r.prompt.toLocaleLowerCase().includes($('search').value.toLocaleLowerCase())}
function detail(r,data){const equal=data.filter(q=>Math.abs(q.L29_T2375_gate-r.L29_T2375_gate)<1e-10&&Math.abs(q.L34_T1468_gate-r.L34_T1468_gate)<1e-10);const box=$('detail');box.replaceChildren();const title=document.createElement('strong');title.textContent=`T2375 = ${r.L29_T2375_gate.toFixed(6)} · T1468 = ${r.L34_T1468_gate.toFixed(6)}${equal.length>1?' · '+equal.length+' overlapping points':''}`;box.append(title);for(const q of equal.slice(0,8)){const p=document.createElement('p');p.textContent=`${q.prompt}  |  ${q.language}, ${q.format}  |  token ${q.position}: ${JSON.stringify(q.token)} (${q.role}${q.last_input?', final input':''})`;box.append(p)}if(equal.length>8){const p=document.createElement('p');p.textContent=`${equal.length-8} additional overlapping points; use the filters or download the CSV.`;box.append(p)}}
function render(){const candidates=S.tokens.filter(match),data=candidates.filter(r=>r.plotted&&(!$('final').checked||r.last_input)&&(!$('content').checked||r.role==='content')),counts={};for(const r of candidates)counts[r.state]=(counts[r.state]||0)+1;
$('detail').textContent='Hover or focus a point to see its prompt, token position and gate values. Overlapping points are listed together.';
$('stats').innerHTML=`<div class="stat"><strong>${S.prompts.filter(match).length}</strong> unique prompts</div><div class="stat"><strong>${data.length}</strong> plotted points</div><div class="stat"><strong>${data.filter(r=>r.state==='both_active').length}</strong> both active in view</div>`;
const svg=$('plot');svg.replaceChildren();const L=94,T=32,W=850,H=480,xmax=Math.max(...S.tokens.map(r=>r.L29_T2375_gate))*1.12,ymax=Math.max(...S.tokens.map(r=>r.L34_T1468_gate))*1.13;
const x=v=>L+W*v/xmax,y=v=>T+H-H*v/ymax;
for(let i=0;i<=5;i++){const xx=xmax*i/5,yy=ymax*i/5;svg.append(el('line',{x1:x(xx),x2:x(xx),y1:T,y2:T+H,stroke:'#e5e8e5'}),el('text',{x:x(xx),y:T+H+26,'text-anchor':'middle',fill:'#52616b','font-size':15},xx.toFixed(1)),el('line',{x1:L,x2:L+W,y1:y(yy),y2:y(yy),stroke:'#e5e8e5'}),el('text',{x:L-15,y:y(yy)+5,'text-anchor':'end',fill:'#52616b','font-size':15},yy.toFixed(1)))}
svg.append(el('line',{x1:L,x2:L+W,y1:y(0),y2:y(0),stroke:'#89979d'}),el('line',{x1:x(0),x2:x(0),y1:T,y2:T+H,stroke:'#89979d'}),el('text',{x:L+W/2,y:580,'text-anchor':'middle','font-size':19,fill:'#263b46'},'L29–T2375 gate, phi(x)'),el('text',{x:28,y:T+H/2,transform:`rotate(-90 28 ${T+H/2})`,'text-anchor':'middle','font-size':19,fill:'#263b46'},'L34–T1468 gate, phi(x)'));
for(const r of data){const xx=x(r.L29_T2375_gate),yy=y(r.L34_T1468_gate),a={class:'point',fill:C[r.domain]||C.other,opacity:.72,stroke:'white','stroke-width':.8,tabindex:0,'aria-label':`${r.prompt}; token ${r.position} ${r.token}; T2375 ${r.L29_T2375_gate}; T1468 ${r.L34_T1468_gate}`};const p=r.last_input?el('polygon',{...a,points:`${xx},${yy-6} ${xx+6},${yy} ${xx},${yy+6} ${xx-6},${yy}`}):el('circle',{...a,cx:xx,cy:yy,r:4.2});p.addEventListener('mouseenter',()=>detail(r,data));p.addEventListener('focus',()=>detail(r,data));svg.append(p)}
const included=candidates.filter(r=>(!$('final').checked||r.last_input)&&(!$('content').checked||r.role==='content'));$('visible').textContent=`${data.length} plotted / ${included.length} input-token pairs under these filters. ${included.filter(r=>r.state==='both_zero').length} exact double-zero pairs hidden. ${data.filter(r=>r.state==='T2375_only').length} points on x-axis; ${data.filter(r=>r.state==='T1468_only').length} on y-axis. Positions are zero-based.`;
const body=$('prompts');body.replaceChildren();for(const p of S.prompts.filter(match)){const tr=document.createElement('tr');for(const [i,v]of [p.prompt,`${p.domain} / ${p.language} / ${p.format}`,p.counts.both_active||0,p.counts.T2375_only||0,p.counts.T1468_only||0,p.counts.both_zero||0].entries()){const td=document.createElement('td');td.textContent=v;if(i===0)td.className='prompt';tr.append(td)}body.append(tr)}}
for(const id of ['domain','language','format','final','content'])$(id).addEventListener('change',render);$('search').addEventListener('input',render);$('reset').addEventListener('click',()=>{for(const id of ['domain','language','format','search'])$(id).value='';$('final').checked=false;$('content').checked=false;render()});
$('checks').textContent=`All ${S.statistics.prompts} captures passed exact observed-versus-unhooked full-vocabulary logit checks. The three original reference prompts reproduced saved input states and logits exactly. Checkpoint encoder hashes were verified; FP32/FP64 agreed on all ${S.validation.FP32_FP64_membership_checks} active/inactive decisions.`;render();
</script></html>'''
(OUT / 'index.html').write_text(page.replace('__PAYLOAD__', payload))
print(json.dumps({'figure': str(OUT / 'gate-coactivation.png'), 'interactive': str(OUT / 'index.html')}, indent=2))
