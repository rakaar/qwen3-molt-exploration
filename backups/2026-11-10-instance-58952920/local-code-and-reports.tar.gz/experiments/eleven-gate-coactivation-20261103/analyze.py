"""Score both gates at matching token coordinates; retain zeros and provenance."""
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SOURCE = ROOT / 'comparisons/2026-11-03-eleven-gate-coactivation/remote-export/eleven-gate-coactivation-20261103'
OUT = ROOT / 'results/2026-11-03-eleven-gate-coactivation'
OUT.mkdir(exist_ok=True)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


source_path = SOURCE / 'artifacts/results.json'
source = json.loads(source_path.read_text())
catalog_path = HERE / 'catalog.json'
catalog = json.loads(catalog_path.read_text())
assert source['status'] == 'complete' and source['hooks_remaining'] == 0
assert sha(catalog_path) == source['catalog_sha256']
assert len(source['cases']) == len(catalog['cases']) == 56
provenance = {str(p.relative_to(ROOT)): sha(p) for p in [source_path, catalog_path, Path(__file__)]}

# These are the exact checkpoint encoder slices and standardizers already audited.
manifest_path = ROOT / 'experiments/eleven-downstream-gates-20261103/weights/manifest.json'
manifest = json.loads(manifest_path.read_text())
assert manifest['slice_hashes_verified'] and manifest['revision'] == source['protocol']['molt_revision']
asset = manifest['features'][0]
path = manifest_path.parent / asset['file']
assert (asset['layer'], asset['transform']) == (29, 2375) and sha(path) == asset['sha256']
with np.load(path, allow_pickle=False) as a:
    w29 = {new: a[old].copy() for new, old in [('encoder', 'e'), ('bias', 'bias'), ('threshold', 'theta'), ('mean', 'input_mean'), ('std', 'input_std')]}
provenance[str(path.relative_to(ROOT))] = sha(path)
provenance[str(manifest_path.relative_to(ROOT))] = sha(manifest_path)
manifest_path = ROOT / 'experiments/eleven-downstream-gates-20261103/gate-cache-manifest.json'
manifest = json.loads(manifest_path.read_text())
assert manifest['NPZ_and_original_tensor_hashes_verified'] and manifest['revision'] == source['protocol']['molt_revision']
asset = next(a for a in manifest['layers'] if a['layer'] == 34)
path = ROOT / asset['project_path']
assert sha(path) == asset['sha256']
with np.load(path, allow_pickle=False) as a:
    w34 = {'encoder': a['encoder'][1468].copy(), 'bias': a['bias'][1468:1469].copy(),
           'threshold': a['threshold'].reshape(-1)[1468:1469].copy(),
           'mean': a['mean'].copy(), 'std': a['std'].copy()}
provenance[str(path.relative_to(ROOT))] = sha(path)
provenance[str(manifest_path.relative_to(ROOT))] = sha(manifest_path)
weights = {29: w29, 34: w34}
rows, prompt_rows = [], []
membership_checks, max_raw_error, anchors = 0, 0., 0
catalog_by_id = {c['id']: c for c in catalog['cases']}
old = json.loads((ROOT / 'results/2026-11-03-eleven-downstream-gates/summary.json').read_text())
for case in source['cases']:
    assert case['observer_full_last_position_logits_exact']
    if case['anchor_exact_and_repeat_verified']:
        anchors += 1
    info = case['arrays']
    path = SOURCE / 'artifacts' / info['file']
    assert path.stat().st_size == info['bytes'] and sha(path) == info['sha256']
    provenance[str(path.relative_to(ROOT))] = info['sha256']
    gates, raws = {}, {}
    with np.load(path, allow_pickle=False) as archive:
        assert np.array_equal(archive['input_ids'], case['prompt_token_ids'])
        for layer in [29, 34]:
            x32, w = archive[f'L{layer}_input'], weights[layer]
            assert x32.shape == (len(case['prompt_token_ids']), 2560)
            raw64 = ((x32.astype(np.float64) - w['mean'].astype(np.float64)) / w['std'].astype(np.float64)) @ w['encoder'].astype(np.float64) + float(w['bias'][0])
            raw32 = ((x32 - w['mean']) / w['std']) @ w['encoder'] + w['bias'][0]
            theta = float(w['threshold'][0])
            active64 = (raw64 > theta) & (raw64 > 0)
            active32 = (raw32 > theta) & (raw32 > 0)
            assert np.array_equal(active64, active32), (case['id'], layer)
            max_raw_error = max(max_raw_error, float(np.max(np.abs(raw64 - raw32))))
            membership_checks += len(raw64)
            gates[layer], raws[layer] = np.where(active64, raw64, 0.), raw64
    original = catalog_by_id[case['id']]
    prior_flipped = any(r.get('prior_last_input_target_12') is True for r in original['prior_records'])
    for position, token in enumerate(case['tokens']):
        x, y = float(gates[29][position]), float(gates[34][position])
        state = 'both_active' if x > 0 and y > 0 else 'T2375_only' if x > 0 else 'T1468_only' if y > 0 else 'both_zero'
        rows.append({'prompt_id': case['id'], 'prompt': case['prompt'], 'domain': case['domain'],
                     'language': case['language'], 'format': case['format'], 'position': position,
                     'token_id': case['prompt_token_ids'][position], 'token': token,
                     'tokenizer_token': case['tokenizer_tokens'][position], 'role': case['token_roles'][position],
                     'last_input': position == len(case['tokens']) - 1,
                     'L29_T2375_gate': x, 'L34_T1468_gate': y,
                     'L29_T2375_raw': float(raws[29][position]), 'L34_T1468_raw': float(raws[34][position]),
                     'state': state, 'plotted': state != 'both_zero', 'prior_last_input_target_12': prior_flipped})
    selected = rows[-len(case['tokens']):]
    counts = dict(Counter(r['state'] for r in selected))
    prompt_rows.append({'id': case['id'], 'prompt': case['prompt'], 'domain': case['domain'],
                        'language': case['language'], 'format': case['format'], 'tokens': len(selected),
                        'counts': counts, 'any_T2375': bool(np.any(gates[29] > 0)),
                        'any_T1468': bool(np.any(gates[34] > 0)),
                        'same_token_coactivation': counts.get('both_active', 0) > 0,
                        'last_T2375': float(gates[29][-1]), 'last_T1468': float(gates[34][-1]),
                        'native_first_token': case['native_first_token'],
                        'prior_last_input_target_12': prior_flipped})
    if case['anchor_exact_and_repeat_verified']:
        reference = next(c for c in old['cases'] if c['prompt'] == case['prompt'])
        expected = next(f for layer in reference['layers'] if layer['layer'] == 34 for f in layer['features'] if f['transform'] == 1468)
        assert abs(gates[29][-1] - reference['L29_natural_gate']) < 1e-5
        assert abs(gates[34][-1] - expected['native_gate']) < 1e-12
assert anchors == 3
counts = dict(Counter(r['state'] for r in rows))
visible = [r for r in rows if r['plotted']]


def correlation(subset):
    a = np.array([[r['L29_T2375_gate'], r['L34_T1468_gate']] for r in subset])
    return float(np.corrcoef(a.T)[0, 1]) if len(a) > 1 and np.all(a.std(axis=0) > 0) else None


stats = {'prompts': len(prompt_rows), 'input_tokens': len(rows), 'plotted_points': len(visible),
         'counts': counts,
         'prompts_with_any_T2375': sum(p['any_T2375'] for p in prompt_rows),
         'prompts_with_any_T1468': sum(p['any_T1468'] for p in prompt_rows),
         'prompts_with_same_token_coactivation': sum(p['same_token_coactivation'] for p in prompt_rows),
         'P_T1468_active_given_T2375_active': counts.get('both_active', 0) / (counts.get('both_active', 0) + counts.get('T2375_only', 0)),
         'Pearson_all_input_tokens_including_double_zeros': correlation(rows),
         'Pearson_plotted_subset_excluding_double_zeros': correlation(visible),
         'Pearson_final_input_positions_including_double_zeros': correlation([r for r in rows if r['last_input']]),
         'formats': dict(Counter(p['format'] for p in prompt_rows)),
         'languages': dict(Counter(p['language'] for p in prompt_rows)),
         'domains': dict(Counter(p['domain'] for p in prompt_rows))}
stats['token_breakdowns'] = {
    field: {value: dict(Counter(r['state'] for r in rows if r[field] == value))
            for value in sorted({r[field] for r in rows})}
    for field in ['format', 'role', 'domain', 'language']}
validation = {'status': 'pass', 'capture_files_hash_verified': len(prompt_rows),
              'all_unhooked_observed_last_position_full_vocabulary_logits_exact': True,
              'three_anchors_match_prior_captures_and_repeat_exactly': True,
              'MOLT_checkpoint_encoder_slice_hashes_verified': True,
              'FP32_FP64_membership_checks': membership_checks, 'FP32_FP64_disagreements': 0,
              'FP32_FP64_max_absolute_raw_error': max_raw_error,
              'same_prompt_same_token_coordinates': True, 'double_zero_points_only_omitted_from_plot': True,
              'no_generation_or_intervention': True}
result = {'question': 'Natural coactivation of L29-T2375 and L34-T1468 on eleven-related inputs',
          'protocol': source['protocol'], 'selection': catalog['selection'], 'exclusions': catalog['exclusions'],
          'gate_definition': 'For each layer independently: z = (post-attention residual - checkpoint mean) / checkpoint std; raw = encoder @ z + bias; phi = raw if raw > threshold and raw > 0, otherwise 0.',
          'thresholds': {str(k): float(v['threshold'][0]) for k, v in weights.items()},
          'statistics': stats, 'validation': validation, 'prompts': prompt_rows, 'tokens': rows,
          'limitations': ['Gate scalars only: no UVx, full MOLT contribution, contribution norm or causal support is measured.',
                          'Native later MLPs remain unchanged; MOLT encoders are diagnostics on the native hidden states.',
                          'These are selected historical eleven-related inputs, not a held-out sample or eleven-vs-other-ordinal specificity control.',
                          'Token points within/across related prompts are dependent; Pearson values are descriptive, with no significance claim.',
                          'Dropping (0,0) conditions the plotted sample and can change its apparent correlation. All points are retained in the CSV.',
                          'Every point pairs the same token coordinate across layers. Separate per-prompt maxima are never paired.',
                          'Input tokens only, including recorded chat wrappers; generated continuations are excluded.'],
          'source_sha256': provenance}
(OUT / 'summary.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(OUT / 'validation.json').write_text(json.dumps(validation, indent=2) + '\n')
for filename, subset in [('all-token-pairs.csv', rows), ('plotted-token-pairs.csv', visible)]:
    with (OUT / filename).open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(subset)
with (OUT / 'prompt-summary.csv').open('w', newline='') as stream:
    fields = [k for k in prompt_rows[0] if k != 'counts'] + ['both_active', 'T2375_only', 'T1468_only', 'both_zero']
    writer = csv.DictWriter(stream, fieldnames=fields)
    writer.writeheader()
    for p in prompt_rows:
        writer.writerow({**{k: v for k, v in p.items() if k != 'counts'},
                         **{k: p['counts'].get(k, 0) for k in fields[-4:]}})
print(json.dumps({'statistics': stats, 'validation': validation}, indent=2))
