"""Collect previously used eleven-related inputs, deduplicated by format and text."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
entries, sources = {}, {}


def read(relative):
    path = ROOT / relative
    sources[relative] = hashlib.sha256(path.read_bytes()).hexdigest()
    return json.loads(path.read_text())


def add(prompt, format, domain, language, source, alias, **metadata):
    assert format in ['raw', 'chat'] and prompt
    key = (format, prompt)
    if key not in entries:
        entries[key] = {'id': 'p-' + hashlib.sha256((format + '\n' + prompt).encode()).hexdigest()[:12],
                        'prompt': prompt, 'format': format, 'domain': domain, 'language': language,
                        'aliases': [], 'prior_records': []}
    entry = entries[key]
    assert entry['domain'] == domain and entry['language'] == language, key
    entry['aliases'].append(alias)
    entry['prior_records'].append({'source': source, 'record': alias, **metadata})
    for field in ['rendered_input', 'prompt_token_ids']:
        if metadata.get(field) is not None:
            if field in entry:
                assert entry[field] == metadata[field], (key, field)
            entry[field] = metadata[field]


# The original raw battery includes failures and inactive-gate cases, not only flips.
case_source = 'experiments/water-raw-ordinal-ablation-20261028/cases.json'
review_source = 'results/2026-10-28-water-raw-ordinal-ablation/summary.json'
reviews = {r['case_id']: r for r in read(review_source)}
for case in read(case_source):
    review = reviews[case['id']]
    add(case['template'].format(ordinal='eleventh'), 'raw', case['id'], 'English', case_source, case['id'],
        native_capability_eligible=review['eligible'],
        prior_last_input_target_12='last_input_only' in review['target_scopes'])

# Previously tested president rephrasings, including capability failures.
president_source = 'experiments/water-raw-ordinal-ablation-20261028/presidents.py'
sources[president_source] = hashlib.sha256((ROOT / president_source).read_bytes()).hexdigest()
for cid, prompt in [('president_standard_case', 'The eleventh president of the United States was'),
                    ('president_name_field', 'The name of the eleventh president of the United States is')]:
    assert prompt.replace('eleventh', '{ordinal}') in (ROOT / president_source).read_text()
    add(prompt, 'raw', 'president', 'English', president_source, cid,
        native_capability_eligible=reviews[cid]['eligible'])

# The multilingual summary preserves the actual rendered inputs and outcome review.
multi_source = 'results/2026-11-01-eleven-multilingual/summary.json'
for case in read(multi_source)['cases']:
    add(case['prompt_11'], case['study'], case['domain'], case['language'], multi_source, case['case_id'],
        rendered_input=case['rendered_input_11'], native_response=case['native_11_response'],
        native_11_correct=case['native_11_initial_correct'],
        prior_last_input_target_12=case.get('last_input_only_answer_ordinal') == 12)

# Original chat capability questions, including cases excluded from steering.
chat_source = 'results/2026-10-28-water-ordinal-battery/controls.json'
for case in read(chat_source):
    add(case['eleventh_prompt'], 'chat', case['case_id'], 'English', chat_source, case['case_id'],
        native_response=case['native_eleventh'], native_capability_eligible=case['eligible'])

# Exact typo, numeric ordinal and raw/chat completion variants actually tested.
variant_source = 'results/2026-10-28-water-eleventh-ablation/controls.json'
for case in read(variant_source):
    format = 'raw' if case['case_id'].endswith('_raw') else 'chat'
    add(case['prompt'], format, 'month', 'English', variant_source, case['case_id'],
        native_response=case['native_answer'])

# The later five-language observation study records token IDs and exact wrappers.
language_source = 'results/2026-11-03-eleven-month-languages/summary.json'
for case in read(language_source)['cases']:
    if case['ordinal'] != 11:
        continue
    native = case['native']
    add(case['prompt'], case['format'], 'month', case['language'], language_source, case['id'],
        rendered_input=native['rendered_input'], prompt_token_ids=native['prompt_token_ids'],
        native_response=native['response'])

# Two additional saved eleven controls have distinct literal wording.
element_source = 'experiments/eleven-fifth-element-scalar-20261103/protocol.json'
element = read(element_source)['controls']['eleventh']
add(element['prompt'], 'raw', 'element', 'English', element_source, 'eleventh-element-in')
activation_source = 'comparisons/2026-11-02-eleven-activation/remote-export/eleven-activation-20261102/artifacts/results.json'
activation = read(activation_source)
for case in activation['cases']:
    native = case['native']
    if case['case_id'] == 'numeric_11':
        add(native['prompt'], 'raw', 'month', 'English', activation_source, case['case_id'],
            prompt_token_ids=native['prompt_token_ids'])

pres_source = 'results/2026-10-28-water-president/summary.json'
for row in read(pres_source):
    if row.get('prompt') == 'Who was the eleventh president of the United States?' and row.get('condition') == 'native':
        add(row['prompt'], 'chat', 'president', 'English', pres_source, 'eleventh-president-chat')

cases = sorted(entries.values(), key=lambda c: (c['domain'], c['language'], c['format'], c['prompt']))
result = {'selection': 'Union of the saved eleven-related raw/chat inputs in the listed historical batteries and follow-ups. Exact format/text duplicates count once. No selection on either current gate value or past intervention success.',
          'exclusions': 'Questions requesting other ordinals (including 1, 5, 12 and 13), intervention-modified hidden states, generated continuations and duplicate inputs. Historical capability failures remain included.',
          'prompt_tokens_only': True, 'chat_enable_thinking': False,
          'cases': cases, 'source_sha256': sources}
HERE.mkdir(exist_ok=True)
(HERE / 'catalog.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'unique_prompts': len(cases), 'languages': sorted({c['language'] for c in cases}),
                  'domains': {d: sum(c['domain'] == d for c in cases) for d in sorted({c['domain'] for c in cases})},
                  'formats': {f: sum(c['format'] == f for c in cases) for f in ['raw', 'chat']}}, indent=2))
