"""Freeze native/off reference states and both pinned MOLT contributions."""
import hashlib
import json
import shutil
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
W = HERE / 'weights'
W.mkdir(exist_ok=True)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assets = []
for source_dir, feature_name in [('eleven-downstream-gates-20261103', 'L29-T2375.npz'),
                                 ('eleven-t1468-alone-20261103', 'L34-T1468.npz')]:
    source = ROOT / 'experiments' / source_dir / 'weights'
    manifest = json.loads((source / 'manifest.json').read_text())
    assert manifest['revision'] == '081ce901b090b64aeecf9bc8709b57c10411e32a'
    feature = next(a for a in manifest['features'] if a['file'] == feature_name)
    assert sha(source / feature_name) == feature['sha256']
    shutil.copy2(source / feature_name, W / feature_name)
    shutil.copy2(source / 'manifest.json', W / (feature_name.replace('.npz', '-provenance.json')))
    assets.append({**feature, 'source_manifest': str(source / 'manifest.json'),
                   'source_manifest_sha256': sha(source / 'manifest.json')})
(W / 'manifest.json').write_text(json.dumps({'revision': '081ce901b090b64aeecf9bc8709b57c10411e32a',
                                            'features': assets}, indent=2) + '\n')
shutil.copy2(ROOT / 'experiments/eleven-t1468-alone-20261103/expected-base-verification.json', HERE / 'expected-base-verification.json')
native_root = ROOT / 'comparisons/2026-11-03-eleven-t1468-alone/remote-export/eleven-t1468-alone-20261103/artifacts'
off_root = ROOT / 'comparisons/2026-11-03-eleven-downstream-gates/remote-export/eleven-downstream-gates-20261103/artifacts'
native_data = json.loads((native_root / 'results.json').read_text())
off_data = json.loads((off_root / 'results.json').read_text())
arrays, cases, provenance = {}, [], {}
for case in native_data['cases']:
    name = case['case']
    native = case['runs']['observed']
    off_case = next(c for c in off_data['cases'] if c['case'] == name)
    off = off_case['runs']['gate-off']
    assert native['prompt'] == off['prompt'] == case['prompt']
    for mode, row, folder in [('native', native, native_root), ('off', off, off_root)]:
        path = folder / row['arrays']['file']
        assert sha(path) == row['arrays']['sha256']
        provenance[str(path.relative_to(ROOT))] = row['arrays']['sha256']
        with np.load(path, allow_pickle=False) as archive:
            if mode == 'native':
                for key in ['first_logits', 'L29_input', 'L34_input', 'pre_final_norm']:
                    arrays[f'{name}_native_{key}'] = archive[key].copy()
                for key in ['gate', 'operator', 'contribution']:
                    arrays[f'{name}_native_{key}34'] = archive[key].copy()
            else:
                arrays[f'{name}_off_first_logits'] = archive['first_logits'].copy()
                arrays[f'{name}_off_L34_input'] = archive['later_molt_inputs'][4].copy()
                arrays[f'{name}_off_pre_final_norm'] = archive['final_norm_input'].copy()
                arrays[f'{name}_native_contribution29'] = archive['contribution'].copy()
                arrays[f'{name}_native_mlp29'] = archive['native_mlp'].copy()
                arrays[f'{name}_off_mlp29'] = archive['edited_mlp'].copy()
    cases.append({'name': name, 'prompt': case['prompt'], 'token_ids': native['prompt_token_ids'],
                  'position': native['position'], 'native_output_token_ids': case['runs']['native']['output_token_ids'],
                  'native_candidate_scores': case['runs']['native']['candidate_scores']})
np.savez_compressed(HERE / 'references.npz', **arrays)
(HERE / 'references.json').write_text(json.dumps({'cases': cases, 'arrays_sha256': sha(HERE / 'references.npz'),
                                                'source_sha256': provenance}, indent=2) + '\n')
prior = json.loads((ROOT / 'experiments/eleven-t1468-alone-20261103/protocol.json').read_text())
protocol = {k: prior[k] for k in ['date_local', 'model', 'base_revision', 'molt_revision', 'max_new_tokens',
                                 'maximum_runtime_minutes', 'prompt_format', 'probes', 'probability_definition']}
protocol.update({'ablation': {'layer': 29, 'transform': 2375, 'position': 'final input is', 'target': 0},
                 'rescue': {'layer': 34, 'transform': 1468, 'position': 'same final input is',
                            'native_gate': 'delta34 = (native_phi34 - current_phi34) * current_operator34',
                            'native_contribution': 'delta34 = native_contribution34 - current_contribution34'},
                 'conditions': ['native', 'observed', 'zero-strength', 'T2375-off', 'off-zero-rescue',
                                'native-gate-rescue', 'native-contribution-rescue', 'T2375-off-repeat',
                                'native-gate-rescue-repeat', 'native-contribution-rescue-repeat'],
                 'scope': 'Only two possible edit sites: L29-T2375 and L34-T1468, each at final input is during prefill. Every later native attention/MLP runs normally. No generated-token edits.',
                 'arithmetic': 'FP32 intended deltas added to each native MLP output, followed by one BF16 cast at each edit site.',
                 'interpretation': 'Compare both rescues against T2375-off. Scalar rescue keeps the changed-input UVx; full contribution rescue restores the native phi(x)*UVx vector. Neither experiment clamps other transforms or later residual streams.'})
(HERE / 'protocol.json').write_text(json.dumps(protocol, indent=2) + '\n')
print(json.dumps({'cases': [c['name'] for c in cases], 'reference_sources_verified': len(provenance),
                  'features': [(a['layer'], a['transform']) for a in assets]}))
