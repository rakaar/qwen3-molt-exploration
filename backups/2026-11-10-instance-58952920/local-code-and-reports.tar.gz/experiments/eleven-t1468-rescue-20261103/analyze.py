"""Audit both edit sites and compare native/off/scalar/full-contribution rescues."""
import csv
import hashlib
import json
import re
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SOURCE = ROOT / 'comparisons/2026-11-03-eleven-t1468-rescue/remote-export/eleven-t1468-rescue-20261103'
OUT = ROOT / 'results/2026-11-03-eleven-t1468-rescue'
OUT.mkdir(exist_ok=True)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def softmax(logits):
    x = logits.astype(np.float64)
    p = np.exp(x - x.max())
    return p / p.sum()


def bf16_round(x):
    x = np.asarray(x, dtype=np.float32)
    assert np.isfinite(x).all()
    bits = x.view(np.uint32)
    rounded = bits + np.uint32(0x7fff) + ((bits >> 16) & 1)
    return (rounded & np.uint32(0xffff0000)).view(np.float32)


def ordinal(name, text):
    patterns = {'month': (r'\s*(november|december)\b', {'november': 11, 'december': 12}),
                'alphabet': (r'\s*([kl])(?=\W|$)', {'k': 11, 'l': 12}),
                'roman': (r'\s*([ivxlcdm]+)\b', {'xi': 11, 'xii': 12})}
    pattern, lookup = patterns[name]
    m = re.match(pattern, text, re.I)
    return lookup.get(m[1].lower()) if m else None


path = SOURCE / 'artifacts/results.json'
source = json.loads(path.read_text())
assert source['status'] == 'complete' and source['hooks_remaining'] == 0
provenance = {str(path.relative_to(ROOT)): sha(path), str(Path(__file__).relative_to(ROOT)): sha(Path(__file__))}
manifest_path = HERE / 'weights/manifest.json'
manifest = json.loads(manifest_path.read_text())
assert sha(manifest_path) == source['runtime']['weights_manifest_sha256']
assert manifest['revision'] == source['protocol']['molt_revision']
weights = {}
for asset in manifest['features']:
    path = manifest_path.parent / asset['file']
    assert sha(path) == asset['sha256']
    provenance[str(path.relative_to(ROOT))] = sha(path)
    with np.load(path, allow_pickle=False) as archive:
        weights[asset['layer']] = {k: archive[k].copy() for k in archive.files}
refmeta = json.loads((HERE / 'references.json').read_text())
assert sha(HERE / 'references.npz') == refmeta['arrays_sha256']
with np.load(HERE / 'references.npz', allow_pickle=False) as archive:
    refs = {k: archive[k].copy() for k in archive.files}
provenance[str((HERE / 'references.json').relative_to(ROOT))] = sha(HERE / 'references.json')
provenance[str((HERE / 'references.npz').relative_to(ROOT))] = refmeta['arrays_sha256']
primary = ['native', 'T2375-off', 'native-gate-rescue', 'native-contribution-rescue']
all_rows, cases = [], []
audited_files, audited_molts, audited_edits = 0, 0, 0
max_operator_error, max_contribution_error, max_probability_error = 0., 0., 0.
for case in source['cases']:
    name, runs = case['case'], case['runs']
    assert all(case[k] for k in ['native_and_off_references_exact', 'zero_controls_exact',
                                 'all_three_ablation_and_rescue_repeats_exact', 'earlier_input_final_residuals_unchanged'])
    arrays, outcomes = {}, {}
    for condition, row in runs.items():
        info = row['arrays']; path = SOURCE / 'artifacts' / info['file']
        assert path.stat().st_size == info['bytes'] and sha(path) == info['sha256']
        provenance[str(path.relative_to(ROOT))] = info['sha256']
        with np.load(path, allow_pickle=False) as archive:
            a = {k: archive[k].copy() for k in archive.files}
        arrays[condition] = a; audited_files += 1
        p, mode = row['position'], row['mode']
        assert row['generated_positions_edited'] == []
        if condition != 'native':
            assert np.array_equal(a['input29'], refs[f'{name}_native_L29_input'])
            expected34 = 'off' if row['T2375_ablated'] else 'native'
            assert np.array_equal(a['input34'], refs[f'{name}_{expected34}_L34_input'])
            for layer, w in weights.items():
                z = (a[f'input{layer}'].astype(np.float64) - w['input_mean'].astype(np.float64)) / w['input_std'].astype(np.float64)
                raw = z @ w['e'].astype(np.float64) + float(w['bias'][0])
                gate = np.where((raw > float(w['theta'][0])) & (raw > 0), raw, 0.)
                operator = (z @ w['V'].astype(np.float64) @ w['U'].astype(np.float64)) * w['output_std'].astype(np.float64)
                contribution = gate[:, None] * operator
                assert np.array_equal(gate > 0, a[f'gate{layer}'] > 0)
                assert np.allclose(raw, a[f'raw{layer}'], atol=1e-5, rtol=1e-5)
                assert np.allclose(operator, a[f'operator{layer}'], atol=2e-5, rtol=2e-5)
                assert np.allclose(contribution, a[f'contribution{layer}'], atol=3e-5, rtol=3e-5)
                max_operator_error = max(max_operator_error, float(np.abs(operator - a[f'operator{layer}']).max()))
                max_contribution_error = max(max_contribution_error, float(np.abs(contribution - a[f'contribution{layer}']).max()))
                audited_molts += 1
            assert np.array_equal(a['contribution29'], refs[f'{name}_native_contribution29'])
            for layer in [29, 34]:
                if f'intended_delta{layer}' not in a:
                    assert row[f'edit_calls{layer}'] == 0
                    continue
                assert row[f'edit_calls{layer}'] == 1
                assert row[f'generated_unedited{layer}'] == len(row['steps']) - 1
                if layer == 29:
                    delta = -a['contribution29'][p] if row['T2375_ablated'] else np.zeros_like(a['contribution29'][p])
                elif mode == 'native-gate-rescue':
                    delta = (refs[f'{name}_native_gate34'][p] - a['gate34'][p]) * a['operator34'][p]
                elif mode == 'native-contribution-rescue':
                    delta = refs[f'{name}_native_contribution34'][p] - a['contribution34'][p]
                else:
                    delta = np.zeros_like(a['contribution34'][p])
                assert np.array_equal(delta, a[f'intended_delta{layer}'])
                assert np.array_equal(bf16_round(a[f'native_mlp{layer}'][p] + delta), a[f'edited_mlp{layer}'][p])
                assert np.array_equal(a[f'native_mlp{layer}'][:p], a[f'edited_mlp{layer}'][:p])
                assert np.array_equal(a[f'edited_mlp{layer}'] - a[f'native_mlp{layer}'], a[f'actual_delta{layer}'])
                audited_edits += 1
        if mode in ['native', 'observed', 'zero-strength']:
            assert np.array_equal(a['first_logits'], refs[f'{name}_native_first_logits'])
        elif mode in ['T2375-off', 'off-zero-rescue']:
            assert np.array_equal(a['first_logits'], refs[f'{name}_off_first_logits'])
        texts = sum(source['protocol']['probes'][name].values(), [])
        sequences = [row['candidate_scores'][t]['token_ids'] for t in texts]
        assert all(not (a_ids == b_ids[:len(a_ids)]) for i, a_ids in enumerate(sequences) for j, b_ids in enumerate(sequences) if i != j)
        exact = {}
        for i, text in enumerate(texts):
            score = row['candidate_scores'][text]
            probs = [float(softmax(a['first_logits'])[score['token_ids'][0]])]
            for j, tid in enumerate(score['token_ids'][1:], 1):
                probs.append(float(softmax(a[f'candidate_{i}_step_{j}'])[tid]))
            error = float(np.max(np.abs(np.array(probs) - score['conditional_probabilities'])))
            assert error < 1e-6
            max_probability_error = max(max_probability_error, error)
            assert float(np.prod(score['conditional_probabilities'], dtype=np.float64)) == score['probability']
            exact[text] = score['probability']
        scores = {k: sum(exact[t] for t in texts) for k, texts in source['protocol']['probes'][name].items()}
        assert sum(scores.values()) <= 1.000001
        record = {'condition': condition, 'P11': scores['11'], 'P12': scores['12'],
                  'initial_answer_ordinal': ordinal(name, row['response']), 'response': row['response'],
                  'stop_reason': row['stop_reason'], 'current_gate34': row.get('current_gate34'),
                  'native_gate34': row['native_gate34'], 'delta34_l2': row.get('delta34_l2', 0.)}
        outcomes[condition] = record
        all_rows.append({'case': name, 'prompt': case['prompt'], 'position': p, **record})
    for control in ['observed', 'zero-strength']:
        assert runs['native']['steps'] == runs[control]['steps']
        assert runs['native']['candidate_scores'] == runs[control]['candidate_scores']
    assert runs['T2375-off']['steps'] == runs['off-zero-rescue']['steps']
    assert runs['T2375-off']['candidate_scores'] == runs['off-zero-rescue']['candidate_scores']
    for mode in primary[1:]:
        repeat = mode + '-repeat'
        assert runs[mode]['steps'] == runs[repeat]['steps']
        assert runs[mode]['candidate_scores'] == runs[repeat]['candidate_scores']
        assert set(arrays[mode]) == set(arrays[repeat])
        assert all(np.array_equal(v, arrays[repeat][k]) for k, v in arrays[mode].items())
    for condition in source['protocol']['conditions'][1:]:
        assert np.array_equal(arrays['observed']['pre_final_norm'][:p], arrays[condition]['pre_final_norm'][:p])
    off_margin = np.log(outcomes['T2375-off']['P11'] / outcomes['T2375-off']['P12'])
    native_margin = np.log(outcomes['native']['P11'] / outcomes['native']['P12'])
    for mode in primary[2:]:
        r = outcomes[mode]
        r['P11_gain_vs_off_percentage_points'] = 100 * (r['P11'] - outcomes['T2375-off']['P11'])
        r['P12_gain_vs_off_percentage_points'] = 100 * (r['P12'] - outcomes['T2375-off']['P12'])
        r['logodds_recovery_fraction'] = float((np.log(r['P11'] / r['P12']) - off_margin) / (native_margin - off_margin))
        r['initial_answer_restored_to_11'] = r['initial_answer_ordinal'] == 11
        r['greedy_token_ids_match_T2375_off'] = runs[mode]['output_token_ids'] == runs['T2375-off']['output_token_ids']
    cases.append({'case': name, 'prompt': case['prompt'], 'position': p,
                  'native_gate34': outcomes['observed']['current_gate34'],
                  'off_gate34': outcomes['T2375-off']['current_gate34'],
                  'conditions': {k: outcomes[k] for k in primary}})
validation = {'status': 'pass', 'array_files_hash_verified': audited_files,
              'independent_CPU_MOLT_evaluations': audited_molts, 'BF16_patch_edits_verified_exactly': audited_edits,
              'max_absolute_operator_error': max_operator_error, 'max_absolute_contribution_error': max_contribution_error,
              'max_absolute_independent_candidate_probability_error': max_probability_error,
              'native_and_T2375_off_reference_logits_exact': True, 'zero_strength_and_zero_rescue_controls_exact': True,
              'all_three_intervention_repeats_exact': True, 'only_final_input_token_edited_at_each_site': True,
              'no_generated_token_edits': True, 'upstream_L29_input_always_native_exact': True,
              'L34_input_identical_for_off_and_both_rescues': True, 'earlier_input_final_residuals_unchanged': True,
              'candidate_token_prefix_events_disjoint': True}
result = {'protocol': source['protocol'], 'runtime': source['runtime'], 'cases': cases,
          'validation': validation, 'source_sha256': provenance,
          'initial_answer_rescues': {mode: sum(c['conditions'][mode]['initial_answer_restored_to_11'] for c in cases) for mode in primary[2:]},
          'limits': ['Three selected raw prefixes; not a generality test.',
                     'The interventions patch MOLT approximation contributions within native MLP outputs. No MLP is replaced wholesale.',
                     'Gate rescue preserves the changed-input operator; full-contribution rescue changes both effective gate and operator contribution.',
                     'Answer-prefix probabilities sum the specified lower/uppercase leading-space spellings, excluding punctuation and EOS.',
                     'Correlative coactivation and standalone ablation did not establish a uniformly positive eleven-support role for T1468.']}
(OUT / 'summary.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
(OUT / 'validation.json').write_text(json.dumps(validation, indent=2) + '\n')
with (OUT / 'probabilities-and-responses.csv').open('w', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(all_rows[0])); writer.writeheader(); writer.writerows(all_rows)
answer_names = {'month': {11: 'November', 12: 'December'}, 'alphabet': {11: 'K', 12: 'L'}, 'roman': {11: 'XI', 12: 'XII'}}
pretty = {'native': 'Native', 'T2375-off': 'L29-T2375 off', 'native-gate-rescue': 'T2375 off + native T1468 scalar gate',
          'native-contribution-rescue': 'T2375 off + full native T1468 contribution'}
lines = ['# Can native T1468 rescue L29-T2375 removal?', '', source['protocol']['scope'], '',
         f"Initial eleven answers restored: scalar gate {result['initial_answer_rescues']['native-gate-rescue']}/3; full contribution {result['initial_answer_rescues']['native-contribution-rescue']}/3.", '',
         'Two rescues are tested separately. Scalar rescue: `delta34 = (native_phi34 - current_phi34) * current_operator34`. Full-contribution rescue: `delta34 = native_contribution34 - current_contribution34`. Both use that same prompt’s native donor at final input ` is`, without extra amplification.', '',
         '| Prompt | Condition | Initial answer | P(11th answer) | P(12th answer) |', '|---|---|---|---:|---:|']
for c in cases:
    for mode in primary:
        r = c['conditions'][mode]
        answer = answer_names[c['case']].get(r['initial_answer_ordinal'], 'other')
        lines.append(f"| {c['case']} | {pretty[mode]} | {answer} | {100*r['P11']:.4f}% | {100*r['P12']:.4f}% |")
lines += ['', 'Probability definition: ' + source['protocol']['probability_definition'], '',
          'Roman XI/XII probabilities include every token in those answer prefixes. Native and off references reproduce exactly. Model computations after the patched sites are recomputed normally.', '']
for c in cases:
    lines += [f"## {c['case'].title()}", '', f"Prompt: `{c['prompt']}`; final input position {c['position']} (` is`).", '',
              f"T1468 gate: native {c['native_gate34']:.6f}; after T2375 removal {c['off_gate34']:.6f}.", '']
    for mode in primary:
        r = c['conditions'][mode]
        lines += [pretty[mode] + ':', '', '```text', r['response'], '```', '']
        if mode in primary[2:]:
            lines += [f"P(11th answer) change vs T2375-off: {r['P11_gain_vs_off_percentage_points']:+.4f} percentage points; P(12th): {r['P12_gain_vs_off_percentage_points']:+.4f} points. Log-odds recovery fraction: {r['logodds_recovery_fraction']:.6f} (0 = off baseline; 1 = native).", '']
lines += ['## Verification and limits', '',
          'The native unhooked run, observed run and zero-strength two-site edits agree exactly. T2375-off and a zero-strength L34 rescue agree exactly. Both rescue variants and T2375-off repeat exactly. Independent CPU checks reproduce each MOLT and every BF16 patch; candidate probabilities are recomputed from saved logits. Earlier input positions remain unchanged.', '']
lines += ['- ' + x for x in result['limits']]
lines += ['', 'Source: experiments/eleven-t1468-rescue-20261103/. Raw arrays, manifests and source hashes: comparisons/2026-11-03-eleven-t1468-rescue/.', '']
(OUT / 'README.md').write_text('\n'.join(lines))
print(json.dumps({'cases': cases, 'validation': validation, 'initial_answer_rescues': result['initial_answer_rescues']}, indent=2))
