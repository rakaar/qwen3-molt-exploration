"""Remove L29-T2375; restore native scalar/full L34-T1468 at the same final is."""
import copy
import hashlib
import json
import os
import time
from pathlib import Path

for key in ['HF_TOKEN', 'HUGGING_FACE_HUB_TOKEN', 'OPENAI_API_KEY', 'VAST_API_KEY', 'VAST_AI_KEY']:
    os.environ.pop(key, None)

import numpy as np
import torch
import torch.nn.functional as F
import transformers
from transformers import AutoModelForCausalLM, AutoTokenizer

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'artifacts'
OUT.mkdir(exist_ok=True)
assert not (OUT / 'results.json').exists(), 'Never overwrite a previous run'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(result):
    path = OUT / 'results.tmp'
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    path.replace(OUT / 'results.json')


protocol = json.loads((ROOT / 'protocol.json').read_text())
expected = json.loads((ROOT / 'expected-base-verification.json').read_text())
assert expected['revision'] == protocol['base_revision']
for row in expected['files']:
    path = ROOT / 'model' / row['file']
    assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256']
assert torch.__version__ == '2.14.0+cu126' and transformers.__version__ == '4.57.6'
assert torch.cuda.is_available() and torch.cuda.is_bf16_supported()
torch.set_num_threads(4)
torch.manual_seed(0)
torch.backends.cuda.matmul.allow_tf32 = False
torch.backends.cudnn.allow_tf32 = False
manifest = json.loads((ROOT / 'weights/manifest.json').read_text())
assert manifest['revision'] == protocol['molt_revision']
weights = {}
for asset in manifest['features']:
    assert (asset['layer'], asset['transform']) in [(29, 2375), (34, 1468)]
    path = ROOT / 'weights' / asset['file']
    assert sha(path) == asset['sha256']
    with np.load(path, allow_pickle=False) as archive:
        weights[asset['layer']] = {k: torch.from_numpy(archive[k].copy()).float().cuda() for k in archive.files}
references_metadata = json.loads((ROOT / 'references.json').read_text())
assert sha(ROOT / 'references.npz') == references_metadata['arrays_sha256']
with np.load(ROOT / 'references.npz', allow_pickle=False) as archive:
    references = {k: archive[k].copy() for k in archive.files}
tok = AutoTokenizer.from_pretrained(ROOT / 'model', local_files_only=True)
model = AutoModelForCausalLM.from_pretrained(ROOT / 'model', local_files_only=True,
    dtype=torch.bfloat16, attn_implementation='eager').to('cuda').eval().requires_grad_(False)
assert len(model.model.layers) == 36 and model.config.hidden_size == 2560
eos = model.generation_config.eos_token_id
eos = set(eos if isinstance(eos, list) else [eos])
started = time.monotonic()


def hooks():
    return sum(len(m._forward_hooks) + len(m._forward_pre_hooks) for m in model.modules())


@torch.inference_mode()
def run(case, condition):
    assert hooks() == 0
    assert time.monotonic() - started < protocol['maximum_runtime_minutes'] * 60
    mode = condition.removesuffix('-repeat')
    observed = mode != 'native'
    ablate29 = mode not in ['native', 'observed', 'zero-strength']
    edit29 = ablate29 or mode == 'zero-strength'
    edit34 = mode in ['zero-strength', 'off-zero-rescue', 'native-gate-rescue', 'native-contribution-rescue']
    ids0 = tok.encode(case['prompt'], add_special_tokens=False)
    assert ids0 == case['token_ids']
    position = len(ids0) - 1
    assert position == case['position'] and tok.decode([ids0[position]]) == ' is'
    state = {'step': 0, 'edit_calls29': 0, 'edit_calls34': 0, 'generated_unedited29': 0, 'generated_unedited34': 0}
    handles = []
    native_gate34 = torch.tensor(references[case['name'] + '_native_gate34'][position], device='cuda')
    native_contribution34 = torch.from_numpy(references[case['name'] + '_native_contribution34'][position]).cuda()

    def observer(layer):
        def observe(_module, inputs):
            if state['step'] != 0:
                return
            w = weights[layer]
            x = inputs[0].detach().float()
            z = (x - w['input_mean']) / w['input_std']
            raw = F.linear(z, w['e'].reshape(1, -1), w['bias']).squeeze(-1)
            phi = torch.where((raw > w['theta'][0]) & (raw > 0), raw, 0.)
            operator = (z @ w['V'] @ w['U']) * w['output_std']
            for key, value in [('input', x), ('z', z), ('raw', raw), ('gate', phi),
                               ('operator', operator), ('contribution', phi[..., None] * operator)]:
                state[f'{key}{layer}'] = value.detach().clone()
        return observe

    def editor(layer):
        def edit(_module, _inputs, output):
            selected = edit29 if layer == 29 else edit34
            if state['step'] != 0:
                if selected:
                    state[f'generated_unedited{layer}'] += 1
                return None
            state[f'native_mlp{layer}'] = output.detach().float().clone()
            if not selected:
                return None
            state[f'edit_calls{layer}'] += 1
            if layer == 29:
                delta = -state['contribution29'][:, position] if ablate29 else torch.zeros_like(output[:, position], dtype=torch.float32)
            elif mode == 'native-gate-rescue':
                delta = (native_gate34 - state['gate34'][:, position, None]) * state['operator34'][:, position]
            elif mode == 'native-contribution-rescue':
                delta = native_contribution34[None] - state['contribution34'][:, position]
            else:
                delta = torch.zeros_like(output[:, position], dtype=torch.float32)
            changed = output.clone()
            changed[:, position] = (output[:, position].float() + delta).to(output.dtype)
            assert torch.equal(changed[:, :position], output[:, :position])
            assert torch.isfinite(changed).all()
            state[f'edited_mlp{layer}'] = changed.detach().float().clone()
            state[f'intended_delta{layer}'] = delta.detach().clone()
            state[f'actual_delta{layer}'] = changed.float() - output.float()
            return changed
        return edit

    def final_norm_input(_module, inputs):
        if state['step'] == 0:
            state['pre_final_norm'] = inputs[0].detach().float().clone()

    if observed:
        for layer in [29, 34]:
            handles.append(model.model.layers[layer].post_attention_layernorm.register_forward_pre_hook(observer(layer)))
            handles.append(model.model.layers[layer].mlp.register_forward_hook(editor(layer)))
        handles.append(model.model.norm.register_forward_pre_hook(final_norm_input))
    ids = torch.tensor([ids0], device='cuda')
    mask, cache, generated, steps = torch.ones_like(ids), None, [], []
    stop = 'token_limit'
    try:
        for step in range(protocol['max_new_tokens']):
            state['step'] = step
            prediction = model(input_ids=ids, attention_mask=mask, past_key_values=cache, use_cache=True)
            cache = prediction.past_key_values
            logits = prediction.logits[0, -1].float()
            probabilities = logits.softmax(-1)
            chosen = int(logits.argmax())
            top, indices = probabilities.topk(5)
            steps.append({'step': step, 'token_id': chosen, 'token': tok.decode([chosen]),
                          'probability': float(probabilities[chosen]),
                          'logits_sha256': hashlib.sha256(logits.cpu().numpy().tobytes()).hexdigest(),
                          'top_tokens': [{'token_id': int(i), 'token': tok.decode([int(i)]), 'probability': float(p)} for p, i in zip(top, indices)]})
            if step == 0:
                first_logits = logits.cpu().numpy().copy()
                first_probabilities = probabilities.cpu().numpy().copy()
                prefill_cache = copy.deepcopy(cache)
            generated.append(chosen)
            if chosen in eos:
                stop = 'eos'
                break
            ids = torch.tensor([[chosen]], device='cuda')
            mask = torch.cat([mask, torch.ones_like(ids)], dim=1)
    finally:
        for handle in handles:
            handle.remove()
    assert hooks() == 0
    for layer, selected in [(29, edit29), (34, edit34)]:
        assert state[f'edit_calls{layer}'] == int(selected)
        assert state[f'generated_unedited{layer}'] == (len(steps) - 1 if selected else 0)
    arrays = {'first_logits': first_logits}
    for key, value in state.items():
        if isinstance(value, torch.Tensor):
            arrays[key] = value[0].cpu().numpy()
    if observed:
        assert np.array_equal(arrays['input29'], references[case['name'] + '_native_L29_input'])
        expected34 = 'off' if ablate29 else 'native'
        assert np.array_equal(arrays['input34'], references[f"{case['name']}_{expected34}_L34_input"])
        assert np.array_equal(arrays['contribution29'], references[case['name'] + '_native_contribution29'])
        assert np.array_equal(arrays['native_mlp29'], references[case['name'] + '_native_mlp29'])
        assert float(arrays['gate34'][position]) > 0
        if not ablate29:
            assert np.array_equal(arrays['contribution34'], references[case['name'] + '_native_contribution34'])
        else:
            assert np.array_equal(arrays['edited_mlp29'], references[case['name'] + '_off_mlp29'])
        if mode in ['observed', 'zero-strength', 'T2375-off', 'off-zero-rescue']:
            assert np.array_equal(arrays['pre_final_norm'], references[f"{case['name']}_{expected34}_pre_final_norm"])
    if mode in ['native', 'observed', 'zero-strength']:
        assert np.array_equal(first_logits, references[case['name'] + '_native_first_logits'])
        assert generated == case['native_output_token_ids']
    elif mode in ['T2375-off', 'off-zero-rescue']:
        assert np.array_equal(first_logits, references[case['name'] + '_off_first_logits'])

    scores = {}
    for index, text in enumerate(sum(protocol['probes'][case['name']].values(), [])):
        tids = tok.encode(text, add_special_tokens=False)
        conditional = [float(first_probabilities[tids[0]])]
        score_cache = copy.deepcopy(prefill_cache)
        score_mask = torch.ones((1, len(ids0)), dtype=torch.long, device='cuda')
        for j, previous in enumerate(tids[:-1], 1):
            score_ids = torch.tensor([[previous]], device='cuda')
            score_mask = torch.cat([score_mask, torch.ones_like(score_ids)], dim=1)
            prediction = model(input_ids=score_ids, attention_mask=score_mask, past_key_values=score_cache, use_cache=True)
            score_cache = prediction.past_key_values
            score_logits = prediction.logits[0, -1].float()
            conditional.append(float(score_logits.softmax(-1)[tids[j]]))
            arrays[f'candidate_{index}_step_{j}'] = score_logits.cpu().numpy()
        scores[text] = {'token_ids': tids, 'conditional_probabilities': conditional,
                        'probability': float(np.prod(conditional, dtype=np.float64))}
    if not ablate29:
        assert scores == case['native_candidate_scores']
    path = OUT / f"{case['name']}--{condition}.npz"
    np.savez_compressed(path, **arrays)
    row = {'case': case['name'], 'condition': condition, 'mode': mode, 'prompt': case['prompt'],
           'prompt_token_ids': ids0, 'position': position, 'token': ' is', 'T2375_ablated': ablate29,
           'T1468_rescue': mode if mode in ['native-gate-rescue', 'native-contribution-rescue'] else None,
           'native_gate34': float(native_gate34), 'native_contribution34_l2': float(native_contribution34.norm()),
           'edited_sites': ([{'layer': 29, 'transform': 2375, 'position': position}] if edit29 else []) +
                           ([{'layer': 34, 'transform': 1468, 'position': position}] if edit34 else []),
           'generated_positions_edited': [], 'edit_calls29': state['edit_calls29'], 'edit_calls34': state['edit_calls34'],
           'generated_unedited29': state['generated_unedited29'], 'generated_unedited34': state['generated_unedited34'],
           'output_token_ids': generated, 'response': tok.decode(generated, skip_special_tokens=True), 'stop_reason': stop,
           'steps': steps, 'candidate_scores': scores,
           'arrays': {'file': path.name, 'bytes': path.stat().st_size, 'sha256': sha(path)}}
    if observed:
        row['current_gate34'] = float(arrays['gate34'][position])
        row['current_contribution34_l2'] = float(np.linalg.norm(arrays['contribution34'][position].astype(np.float64)))
        row['delta34_l2'] = float(np.linalg.norm(arrays['intended_delta34'].astype(np.float64))) if edit34 else 0.
    return row, arrays


result = {'status': 'running', 'protocol': protocol, 'cases': [],
          'runtime': {'torch': torch.__version__, 'transformers': transformers.__version__,
                      'gpu': torch.cuda.get_device_name(), 'attention': 'eager', 'TF32': False,
                      'source_sha256': sha(Path(__file__)), 'weights_manifest_sha256': sha(ROOT / 'weights/manifest.json')}}
save(result)
for case in references_metadata['cases']:
    runs, values = {}, {}
    for condition in protocol['conditions']:
        runs[condition], values[condition] = run(case, condition)
    for condition in ['observed', 'zero-strength']:
        assert runs['native']['steps'] == runs[condition]['steps']
        assert runs['native']['candidate_scores'] == runs[condition]['candidate_scores']
    for layer in [29, 34]:
        assert not np.count_nonzero(values['zero-strength'][f'actual_delta{layer}'])
    assert runs['T2375-off']['steps'] == runs['off-zero-rescue']['steps']
    assert runs['T2375-off']['candidate_scores'] == runs['off-zero-rescue']['candidate_scores']
    assert not np.count_nonzero(values['off-zero-rescue']['actual_delta34'])
    for mode in ['T2375-off', 'native-gate-rescue', 'native-contribution-rescue']:
        repeat = mode + '-repeat'
        assert runs[mode]['steps'] == runs[repeat]['steps']
        assert runs[mode]['candidate_scores'] == runs[repeat]['candidate_scores']
        assert set(values[mode]) == set(values[repeat])
        assert all(np.array_equal(v, values[repeat][k]) for k, v in values[mode].items())
    position = case['position']
    for condition in protocol['conditions'][1:]:
        assert np.array_equal(values['observed']['pre_final_norm'][:position], values[condition]['pre_final_norm'][:position])
    result['cases'].append({'case': case['name'], 'prompt': case['prompt'], 'runs': runs,
                            'native_and_off_references_exact': True, 'zero_controls_exact': True,
                            'all_three_ablation_and_rescue_repeats_exact': True,
                            'earlier_input_final_residuals_unchanged': True})
    save(result)
    print(json.dumps({'completed_case': case['name'], 'conditions': [{
        'condition': key, 'response': runs[key]['response'], 'scores': runs[key]['candidate_scores']}
        for key in ['T2375-off', 'native-gate-rescue', 'native-contribution-rescue']]}, ensure_ascii=False), flush=True)
result.update(status='complete', hooks_remaining=hooks(), runtime_seconds=time.monotonic() - started)
save(result)
print('T1468_RESCUES_COMPLETE', flush=True)
