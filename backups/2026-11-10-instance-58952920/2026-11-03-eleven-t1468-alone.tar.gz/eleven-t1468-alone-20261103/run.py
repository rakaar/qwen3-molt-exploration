"""Ablate only L34-T1468 at final input is; preserve native downstream computation."""
import copy
import hashlib
import json
import os
import time
from pathlib import Path

for key in ['HF_TOKEN', 'HUGGING_FACE_HUB_TOKEN', 'OPENAI_API_KEY', 'VAST_API_KEY', 'VAST_AI_KEY']:
    os.environ.pop(key, None)

import numpy as np
import torch
import torch.nn.functional as F
import transformers
from transformers import AutoModelForCausalLM, AutoTokenizer

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'artifacts'
OUT.mkdir(exist_ok=True)
assert not (OUT / 'results.json').exists(), 'Preserve existing results'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(value):
    temp = OUT / 'results.tmp'
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    temp.replace(OUT / 'results.json')


protocol = json.loads((ROOT / 'protocol.json').read_text())
expected = json.loads((ROOT / 'expected-base-verification.json').read_text())
assert expected['revision'] == protocol['base_revision']
for row in expected['files']:
    path = ROOT / 'model' / row['file']
    assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256']
manifest = json.loads((ROOT / 'weights/manifest.json').read_text())
assert manifest['revision'] == protocol['molt_revision']
feature = manifest['features'][0]
assert (feature['layer'], feature['transform']) == (34, 1468)
path = ROOT / 'weights' / feature['file']
assert sha(path) == feature['sha256']
with np.load(path, allow_pickle=False) as archive:
    cpu_weights = {k: archive[k].copy() for k in archive.files}
anchors = json.loads((ROOT / 'anchors.json').read_text())
assert sha(ROOT / 'anchors.npz') == anchors['arrays_sha256']
with np.load(ROOT / 'anchors.npz', allow_pickle=False) as archive:
    references = {k: archive[k].copy() for k in archive.files}
assert torch.__version__ == '2.14.0+cu126' and transformers.__version__ == '4.57.6'
assert torch.cuda.is_available() and torch.cuda.is_bf16_supported()
torch.set_num_threads(4)
torch.manual_seed(0)
torch.backends.cuda.matmul.allow_tf32 = False
torch.backends.cudnn.allow_tf32 = False
w = {k: torch.from_numpy(v).float().cuda() for k, v in cpu_weights.items()}
tok = AutoTokenizer.from_pretrained(ROOT / 'model', local_files_only=True)
model = AutoModelForCausalLM.from_pretrained(ROOT / 'model', local_files_only=True,
    dtype=torch.bfloat16, attn_implementation='eager').to('cuda').eval().requires_grad_(False)
assert len(model.model.layers) == 36 and model.config.hidden_size == 2560
eos = model.generation_config.eos_token_id
eos = set(eos if isinstance(eos, list) else [eos])
started = time.monotonic()


def hooks():
    return sum(len(m._forward_hooks) + len(m._forward_pre_hooks) for m in model.modules())


@torch.inference_mode()
def run(case, name, observe=False, strength=None):
    assert hooks() == 0
    assert time.monotonic() - started < protocol['maximum_runtime_minutes'] * 60
    ids0 = tok.encode(case['prompt'], add_special_tokens=False)
    assert ids0 == case['token_ids']
    position = len(ids0) - 1
    assert tok.decode([ids0[position]]) == ' is'
    state = {'step': 0, 'edit_calls': 0, 'generated_passes_without_edit': 0}
    handles = []

    def observe29(_module, inputs):
        if state['step'] == 0:
            state['L29_input'] = inputs[0].detach().float().clone()

    def observe34(_module, inputs):
        if state['step'] != 0:
            return
        x = inputs[0].detach().float()
        z = (x - w['input_mean']) / w['input_std']
        raw = F.linear(z, w['e'].reshape(1, -1), w['bias']).squeeze(-1)
        gate = torch.where((raw > w['theta'][0]) & (raw > 0), raw, 0.)
        operator = (z @ w['V'] @ w['U']) * w['output_std']
        state.update(L34_input=x.clone(), z=z, raw=raw, gate=gate,
                     operator=operator, contribution=gate[..., None] * operator)

    def edit34(_module, _inputs, output):
        if state['step'] != 0:
            if strength is not None:
                state['generated_passes_without_edit'] += 1
            return None
        state['native_mlp'] = output.detach().float().clone()
        if strength is None:
            return None
        state['edit_calls'] += 1
        changed = output.clone()
        delta = -float(strength) * state['contribution'][:, position]
        changed[:, position] = (output[:, position].float() + delta).to(output.dtype)
        assert torch.equal(changed[:, :position], output[:, :position])
        assert torch.isfinite(changed).all()
        state.update(edited_mlp=changed.detach().float().clone(),
                     intended_delta=delta.clone(), actual_delta=changed.float() - output.float())
        return changed

    def final_norm_input(_module, inputs):
        if state['step'] == 0:
            state['pre_final_norm'] = inputs[0].detach().float().clone()

    if observe or strength is not None:
        handles.extend([
            model.model.layers[29].post_attention_layernorm.register_forward_pre_hook(observe29),
            model.model.layers[34].post_attention_layernorm.register_forward_pre_hook(observe34),
            model.model.layers[34].mlp.register_forward_hook(edit34),
            model.model.norm.register_forward_pre_hook(final_norm_input)])
    ids = torch.tensor([ids0], device='cuda')
    mask, cache, generated, steps = torch.ones_like(ids), None, [], []
    stop = 'token_limit'
    try:
        for step in range(protocol['max_new_tokens']):
            state['step'] = step
            prediction = model(input_ids=ids, attention_mask=mask, past_key_values=cache, use_cache=True)
            cache = prediction.past_key_values
            logits = prediction.logits[0, -1].float()
            assert torch.isfinite(logits).all()
            probabilities = logits.softmax(-1)
            chosen = int(logits.argmax())
            top, indices = probabilities.topk(5)
            steps.append({'step': step, 'token_id': chosen, 'token': tok.decode([chosen]),
                          'probability': float(probabilities[chosen]),
                          'logits_sha256': hashlib.sha256(logits.cpu().numpy().tobytes()).hexdigest(),
                          'top_tokens': [{'token_id': int(i), 'token': tok.decode([int(i)]), 'probability': float(p)} for p, i in zip(top, indices)]})
            if step == 0:
                first_logits = logits.detach().cpu().numpy().copy()
                first_probabilities = probabilities.detach().cpu().numpy().copy()
                prefill_cache = copy.deepcopy(cache)
            generated.append(chosen)
            if chosen in eos:
                stop = 'eos'
                break
            ids = torch.tensor([[chosen]], device='cuda')
            mask = torch.cat([mask, torch.ones_like(ids)], dim=1)
    finally:
        for handle in handles:
            handle.remove()
    assert hooks() == 0
    assert state['edit_calls'] == (1 if strength is not None else 0)
    if strength is not None:
        assert state['generated_passes_without_edit'] == len(steps) - 1
    arrays = {'first_logits': first_logits}
    for key in ['L29_input', 'L34_input', 'z', 'raw', 'gate', 'operator', 'contribution',
                'native_mlp', 'edited_mlp', 'actual_delta', 'pre_final_norm']:
        if key in state:
            arrays[key] = state[key][0].cpu().numpy()
    if 'intended_delta' in state:
        arrays['intended_delta'] = state['intended_delta'][0].cpu().numpy()
    if 'L29_input' in arrays:
        # Any L34 edit must leave the upstream input, and its own gate input, native.
        for key in ['L29_input', 'L34_input']:
            assert np.array_equal(arrays[key], references[case['name'] + '_' + key])
        assert float(arrays['gate'][position]) > 0
    if strength in [None, 0.]:
        assert np.array_equal(first_logits, references[case['name'] + '_first_logits'])

    scores = {}
    texts = sum(protocol['probes'][case['name']].values(), [])
    for index, text in enumerate(texts):
        tids = tok.encode(text, add_special_tokens=False)
        conditional = [float(first_probabilities[tids[0]])]
        score_cache = copy.deepcopy(prefill_cache)
        score_mask = torch.ones((1, len(ids0)), dtype=torch.long, device='cuda')
        for j, previous in enumerate(tids[:-1], 1):
            score_ids = torch.tensor([[previous]], device='cuda')
            score_mask = torch.cat([score_mask, torch.ones_like(score_ids)], dim=1)
            prediction = model(input_ids=score_ids, attention_mask=score_mask, past_key_values=score_cache, use_cache=True)
            score_cache = prediction.past_key_values
            score_logits = prediction.logits[0, -1].float()
            conditional.append(float(score_logits.softmax(-1)[tids[j]]))
            arrays[f'candidate_{index}_step_{j}'] = score_logits.cpu().numpy()
        scores[text] = {'token_ids': tids, 'conditional_probabilities': conditional,
                        'probability': float(np.prod(conditional, dtype=np.float64))}
    filename = f"{case['name']}--{name}.npz"
    path = OUT / filename
    np.savez_compressed(path, **arrays)
    row = {'case': case['name'], 'condition': name, 'prompt': case['prompt'], 'prompt_token_ids': ids0,
           'position': position, 'token': ' is', 'strength': strength, 'layer_edited': 34 if strength is not None else None,
           'transform_edited': 1468 if strength is not None else None,
           'edited_input_positions': [position] if strength is not None else [], 'generated_positions_edited': [],
           'output_token_ids': generated, 'response': tok.decode(generated, skip_special_tokens=True),
           'stop_reason': stop, 'steps': steps, 'candidate_scores': scores,
           'edit_calls': state['edit_calls'], 'generated_passes_without_edit': state['generated_passes_without_edit'],
           'arrays': {'file': filename, 'bytes': path.stat().st_size, 'sha256': sha(path)}}
    if 'gate' in arrays:
        row.update(natural_gate=float(arrays['gate'][position]),
                   operator_l2=float(np.linalg.norm(arrays['operator'][position].astype(np.float64))),
                   contribution_l2=float(np.linalg.norm(arrays['contribution'][position].astype(np.float64))))
    return row, arrays


result = {'status': 'running', 'protocol': protocol, 'cases': [],
          'runtime': {'torch': torch.__version__, 'transformers': transformers.__version__,
                      'gpu': torch.cuda.get_device_name(), 'attention': 'eager', 'TF32': False,
                      'arithmetic': 'Native BF16; FP32 MOLT contribution subtraction with one BF16 cast',
                      'source_sha256': sha(Path(__file__)), 'weights_manifest_sha256': sha(ROOT / 'weights/manifest.json')}}
save(result)
for case in anchors['cases']:
    runs, values = {}, {}
    for name, observe, strength in [('native', False, None), ('observed', True, None), ('zero-strength', False, 0.),
                                    ('T1468-off', False, 1.), ('T1468-off-repeat', False, 1.)]:
        runs[name], values[name] = run(case, name, observe, strength)
    native = runs['native']
    for control in ['observed', 'zero-strength']:
        assert runs[control]['steps'] == native['steps']
        assert runs[control]['candidate_scores'] == native['candidate_scores']
    for key in values['observed']:
        assert np.array_equal(values['observed'][key], values['zero-strength'][key]), ('zero-control', key)
    assert not np.count_nonzero(values['zero-strength']['actual_delta'])
    assert set(values['T1468-off']) == set(values['T1468-off-repeat'])
    assert all(np.array_equal(value, values['T1468-off-repeat'][key]) for key, value in values['T1468-off'].items())
    assert runs['T1468-off']['steps'] == runs['T1468-off-repeat']['steps']
    assert runs['T1468-off']['candidate_scores'] == runs['T1468-off-repeat']['candidate_scores']
    position = runs['T1468-off']['position']
    for key in ['native_mlp', 'pre_final_norm']:
        assert np.array_equal(values['observed'][key][:position], values['T1468-off'][key][:position]), key
    result['cases'].append({'case': case['name'], 'prompt': case['prompt'], 'runs': runs,
                            'native_reference_and_observer_zero_controls_exact': True,
                            'ablation_repeat_exact': True, 'L29_and_L34_gate_inputs_native_exact': True,
                            'earlier_input_MLP_outputs_and_final_residuals_unchanged': True})
    save(result)
    print(json.dumps({'completed_case': case['name'], 'native': native['response'],
                      'T1468_off': runs['T1468-off']['response'], 'scores': runs['T1468-off']['candidate_scores']}, ensure_ascii=False), flush=True)
result.update(status='complete', hooks_remaining=hooks(), runtime_seconds=time.monotonic() - started)
save(result)
print('T1468_ALONE_ABLATIONS_COMPLETE', flush=True)
