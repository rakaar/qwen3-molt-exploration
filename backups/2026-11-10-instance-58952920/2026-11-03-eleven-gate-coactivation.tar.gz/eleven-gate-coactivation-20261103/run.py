"""Read-only paired gate-input capture on the native model; no interventions."""
import hashlib
import json
import os
import time
from pathlib import Path

for key in ['HF_TOKEN', 'HUGGING_FACE_HUB_TOKEN', 'OPENAI_API_KEY', 'VAST_API_KEY', 'VAST_AI_KEY']:
    os.environ.pop(key, None)

import numpy as np
import torch
import transformers
from transformers import AutoModelForCausalLM, AutoTokenizer

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'artifacts'
OUT.mkdir(exist_ok=True)
assert not (OUT / 'results.json').exists(), 'Never overwrite an earlier capture'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    temp.replace(path)


protocol = json.loads((ROOT / 'protocol.json').read_text())
catalog = json.loads((ROOT / 'catalog.json').read_text())
expected = json.loads((ROOT / 'expected-base-verification.json').read_text())
assert expected['revision'] == protocol['base_revision']
for row in expected['files']:
    path = ROOT / 'model' / row['file']
    assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256']
anchors = json.loads((ROOT / 'anchors.json').read_text())
assert sha(ROOT / 'anchors.npz') == anchors['arrays_sha256']
with np.load(ROOT / 'anchors.npz', allow_pickle=False) as archive:
    anchor_arrays = {k: archive[k].copy() for k in archive.files}
assert torch.__version__ == '2.14.0+cu126'
assert transformers.__version__ == '4.57.6'
assert torch.cuda.is_available() and torch.cuda.is_bf16_supported()
torch.set_num_threads(4)
torch.manual_seed(0)
torch.backends.cuda.matmul.allow_tf32 = False
torch.backends.cudnn.allow_tf32 = False
tokenizer = AutoTokenizer.from_pretrained(ROOT / 'model', local_files_only=True)
model = AutoModelForCausalLM.from_pretrained(ROOT / 'model', local_files_only=True,
    dtype=torch.bfloat16, attn_implementation='eager').to('cuda').eval().requires_grad_(False)
assert len(model.model.layers) == 36 and model.config.hidden_size == 2560
started = time.monotonic()


def hooks():
    return sum(len(m._forward_hooks) + len(m._forward_pre_hooks) for m in model.modules())


@torch.inference_mode()
def capture(token_ids, observed):
    assert hooks() == 0
    states, handles = {}, []
    if observed:
        for layer in [29, 34]:
            def pre_hook(_module, inputs, layer=layer):
                assert layer not in states
                states[layer] = inputs[0].detach().float().clone()
            handles.append(model.model.layers[layer].post_attention_layernorm.register_forward_pre_hook(pre_hook))
    try:
        ids = torch.tensor([token_ids], device='cuda')
        prediction = model(input_ids=ids, attention_mask=torch.ones_like(ids), use_cache=False)
        logits = prediction.logits[0, -1].float().cpu().numpy().copy()
        if observed:
            assert sorted(states) == [29, 34]
        arrays = {f'L{layer}_input': x[0].cpu().numpy() for layer, x in states.items()}
        return logits, arrays
    finally:
        for handle in handles:
            handle.remove()
        assert hooks() == 0


result = {'status': 'running', 'protocol': protocol, 'cases': [],
          'catalog_sha256': sha(ROOT / 'catalog.json'),
          'runtime': {'torch': torch.__version__, 'transformers': transformers.__version__,
                      'gpu': torch.cuda.get_device_name(), 'attention': 'eager', 'dtype': 'BF16',
                      'TF32': False, 'generation': False, 'intervention': None,
                      'base_revision': expected['revision']}}
save(OUT / 'results.json', result)
for case in catalog['cases']:
    assert time.monotonic() - started < protocol['maximum_runtime_minutes'] * 60
    prompt = case['prompt']
    rendered = prompt if case['format'] == 'raw' else tokenizer.apply_chat_template(
        [{'role': 'user', 'content': prompt}], tokenize=False, add_generation_prompt=True, enable_thinking=False)
    if 'rendered_input' in case:
        assert rendered == case['rendered_input'], (case['id'], 'wrapper mismatch')
    encoding = tokenizer(rendered, add_special_tokens=False, return_offsets_mapping=True)
    ids, offsets = encoding['input_ids'], encoding['offset_mapping']
    assert 0 < len(ids) <= 256
    if 'prompt_token_ids' in case:
        assert ids == case['prompt_token_ids']
    plain_logits, _ = capture(ids, False)
    logits, arrays = capture(ids, True)
    assert np.array_equal(plain_logits, logits), (case['id'], 'observer changed logits')
    arrays.update(first_logits=logits, input_ids=np.array(ids, dtype=np.int64))
    anchor = next((a for a in anchors['cases'] if a['prompt'] == prompt and case['format'] == 'raw'), None)
    if anchor:
        assert ids == anchor['token_ids']
        for key in ['first_logits', 'L29_input', 'L34_input']:
            assert np.array_equal(arrays[key], anchor_arrays[anchor['name'] + '_' + key]), (case['id'], key)
        repeat_logits, repeat_states = capture(ids, True)
        assert np.array_equal(logits, repeat_logits)
        assert all(np.array_equal(arrays[k], v) for k, v in repeat_states.items())
    location = rendered.find(prompt)
    assert location >= 0 and rendered.find(prompt, location + 1) == -1
    end = location + len(prompt)
    roles = ['content' if b > location and a < end else 'wrapper' for a, b in offsets]
    path = OUT / (case['id'] + '.npz')
    np.savez_compressed(path, **arrays)
    chosen = int(logits.argmax())
    row = {'id': case['id'], 'prompt': prompt, 'format': case['format'], 'language': case['language'],
           'domain': case['domain'], 'rendered_input': rendered, 'prompt_token_ids': ids,
           'tokens': [tokenizer.decode([i]) for i in ids],
           'tokenizer_tokens': tokenizer.convert_ids_to_tokens(ids), 'token_roles': roles, 'offsets': offsets,
           'native_first_token_id': chosen, 'native_first_token': tokenizer.decode([chosen]),
           'observer_full_last_position_logits_exact': True, 'anchor_exact_and_repeat_verified': bool(anchor),
           'arrays': {'file': path.name, 'bytes': path.stat().st_size, 'sha256': sha(path)}}
    result['cases'].append(row)
    save(OUT / 'results.json', result)
    print(json.dumps({'completed': len(result['cases']), 'of': len(catalog['cases']), 'id': case['id'],
                      'domain': case['domain'], 'language': case['language'], 'tokens': len(ids)}, ensure_ascii=False), flush=True)
assert len(result['cases']) == len(catalog['cases'])
result.update(status='complete', hooks_remaining=hooks(), runtime_seconds=time.monotonic() - started)
save(OUT / 'results.json', result)
print('GATE_COACTIVATION_CAPTURE_COMPLETE', flush=True)
