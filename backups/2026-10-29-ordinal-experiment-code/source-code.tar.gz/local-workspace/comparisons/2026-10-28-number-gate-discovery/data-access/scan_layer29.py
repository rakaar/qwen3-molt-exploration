"""Label-agnostic predecessor-number screen of the saved 64-conversation preview."""
import collections
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'preview-jsonl/layer-29.jsonl'
LABELS = Path('comparisons/2026-10-21-toxic-persona-survey/hf-labels/layer-29.jsonl')


def events(row):
    found = {}
    for ei, ex in enumerate(row['examples']):
        text, acts = ex['text'], ex['gates']
        assert len(text) == len(acts)
        selected_peak_index = next(k for k, a in enumerate(acts) if abs(a-ex['peak']) < 1e-6)
        for i, gate in enumerate(acts):
            if gate <= 0 or re.search(r'\d', text[i]):
                continue
            for lag in [1, 2, 3]:
                j = i + lag
                if j >= len(text):
                    break
                if lag > 1 and any(t.strip() for t in text[i+1:j]):
                    continue
                m = re.match(r'^\s*([0-9]+)(.*)$', text[j], re.S)
                if not m:
                    continue
                digits, tail = m.groups()
                k = j + 1
                if not tail:
                    while k < len(text) and re.fullmatch(r'[0-9]+', text[k]):
                        digits += text[k]
                        k += 1
                number = int(digits)
                if not 1 <= number <= 31:
                    continue
                # Reject decimal/version/time/fraction/range continuations.
                left = ''.join(text[max(0, i-3):i+1])
                numeric_left = bool(re.search(r'\d[.,:/-][ \t]*$', left))
                numeric_right = bool(k+1 < len(text) and text[k] in ['.', ',', ':', '/'] and re.match(r'^\d', text[k+1]))
                key = (ex['conversation'], ex['start']+i, number)
                event = {'conversation': ex['conversation'], 'position': ex['start']+i,
                         'activated_token': text[i], 'gate': gate, 'next_number': number,
                         'next_number_text': digits, 'number_start_position': ex['start']+j,
                         'number_end_position_exclusive': ex['start']+k, 'lag_tokens': lag,
                         'at_selected_window_peak': abs(gate-ex['peak']) < 1e-6,
                         'at_window_maximum': abs(gate-ex['peak']) < 1e-6,
                         'is_collector_selected_peak': i == selected_peak_index,
                         'collector_selected_peak_index': selected_peak_index,
                         'numeric_continuation': numeric_left or numeric_right,
                         'context': ''.join(text[max(0,i-6):min(len(text),k+8)]),
                         'example_index': ei}
                old = found.get(key)
                if old is None or event['lag_tokens'] < old['lag_tokens']:
                    found[key] = event
    return list(found.values())


def main():
    labels = {r['feature_id']: r for r in map(json.loads, LABELS.read_text().splitlines())}
    records = []
    for row in map(json.loads, SOURCE.read_text().splitlines()):
        ev = events(row)
        strict = [e for e in ev if e['lag_tokens'] == 1 and not e['numeric_continuation']]
        primary = [e for e in strict if e['at_selected_window_peak']]
        if not strict:
            continue
        by_number = collections.defaultdict(list)
        for e in primary:
            by_number[e['next_number']].append(e)
        dominant = max(by_number, key=lambda n: (len({e['conversation'] for e in by_number[n]}), sum(e['gate'] for e in by_number[n]))) if by_number else None
        dominant_events = by_number.get(dominant, [])
        lab = labels[row['feature_id']]
        rec = {'layer': 29, 'feature_id': row['feature_id'], 'title': lab['title'], 'explanation': lab['explanation'],
               'preview_windows': len(row['examples']), 'strict_pre_number_events': len(strict),
               'peak_pre_number_events': len(primary), 'dominant_peak_number': dominant,
               'dominant_conversations': len({e['conversation'] for e in dominant_events}),
               'dominant_share_of_numeric_peak_events': len(dominant_events)/max(len(primary),1),
               'dominant_share_of_preview_windows': len(dominant_events)/max(len(row['examples']),1),
               'highest_dominant_gate': max((e['gate'] for e in dominant_events), default=0),
               'events': sorted(ev,key=lambda e:(e['numeric_continuation'],not e['at_selected_window_peak'],e['lag_tokens'],-e['gate']))}
        records.append(rec)
    records.sort(key=lambda r:(r['dominant_conversations'],r['dominant_share_of_numeric_peak_events'],r['dominant_share_of_preview_windows'],r['highest_dominant_gate']),reverse=True)
    out = {'coverage': 'Layer 29 only; all 2480 feature IDs, max8 peak-centered windows per feature from64 conversations /54828 tokens. Label joined after selection. Candidates only, no causal validation.',
           'selection': 'Rank strict immediate nonnumeric-token predecessors at selected conversation-window peaks, target standalone integer1..31. Numeric continuations and lagged/secondary activations retained but not used for primary ranking.',
           'features_with_strict_events':len(records),'candidates':records}
    (ROOT/'layer29-preview-predecessors.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
    calibration = next(r for r in records if r['feature_id']==2375)
    (ROOT/'calibration-L29-T2375.json').write_text(json.dumps(calibration,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'feature_count':2480,'features_with_strict_events':len(records),'top_20':[{k:r[k] for k in ['layer','feature_id','title','dominant_peak_number','dominant_conversations','dominant_share_of_numeric_peak_events','dominant_share_of_preview_windows','highest_dominant_gate']} for r in records[:20]],'calibration':calibration},indent=2))


if __name__=='__main__':
    main()
