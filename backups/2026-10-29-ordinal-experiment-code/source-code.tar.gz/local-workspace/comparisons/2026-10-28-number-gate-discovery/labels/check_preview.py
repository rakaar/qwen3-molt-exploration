"""Independently inspect selected labeled/hypothesis features in the fresh preview."""
import collections
import hashlib
import json
import re
from pathlib import Path

OUT = Path(__file__).resolve().parent
PROJECT = OUT.parents[2]
BASE = PROJECT / 'comparisons/2026-10-28-number-gate-discovery/data-access/preview-jsonl'
REQUESTED = {9:{1963,1313,1486,1981,42},13:{2246,1219,1829},19:{1560,1543,1645,357,90,304},22:{2072,688,370,207},29:{252,1021,1315,1247,664,1624,2375,437,1634,1541,2397,1051,1823,1766,1161,2401}}
WORDS = {s:str(i) for i,s in enumerate(['zero','one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen','twenty'])}
WORDS.update({'first':'1','second':'2','third':'3','fourth':'4','fifth':'5','sixth':'6','seventh':'7','eighth':'8','ninth':'9','tenth':'10','eleventh':'11','twelfth':'12'})
WORDPAT=re.compile(r'^\s*('+ '|'.join(sorted(WORDS,key=len,reverse=True))+r')\b',re.I)
NUMBER=re.compile(r'^([ \t\r\n]*)([+-]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?)')

def main():
    records=[]
    for layer,ids in REQUESTED.items():
        p=BASE/f'layer-{layer:02d}.jsonl'; data=p.read_bytes()
        for line in data.splitlines():
            d=json.loads(line)
            if d['feature_id'] not in ids:continue
            events={};peak_keys=[]
            for ei,ex in enumerate(d['examples']):
                text,gates=ex['text'],ex['gates'];assert len(text)==len(gates)
                center=16 if len(text)>16 and abs(gates[16]-ex['peak'])<1e-7 else max(range(len(gates)),key=lambda i:gates[i])
                for i,g in enumerate(gates):
                    if g<=0 or i+1>=len(text):continue
                    following=''.join(text[i+1:]);m=NUMBER.match(following)
                    number=form=None
                    if m:
                        number=m.group(2);form='digits'
                        if m.end()==len(following):continue
                    else:
                        m=WORDPAT.match(following)
                        if m:number=WORDS[m.group(1).casefold()];form='number_or_ordinal_word'
                    category='non_numeric_following'
                    if number is not None:
                        category='numeric_token_or_digit_continuation' if re.search(r'\d',text[i]) else 'pre_full_number'
                    content=next((j for j in range(i+1,len(text)) if text[j].strip()),None)
                    event={'conversation':ex['conversation'],'absolute_position':ex['start']+i,'window_start':ex['start'],'example_index':ei,'local_position':i,'is_peak':i==center,'gate':g,'token':text[i], 'next_token':text[i+1], 'first_content_token_lag':content-i if content is not None else None,'following_number':number,'number_form':form,'category':category,'context_before':''.join(text[max(0,i-7):i]),'context_after':''.join(text[i+1:i+12])}
                    key=(ex['conversation'],ex['start']+i)
                    if key not in events or (event['is_peak'] and not events[key]['is_peak']):events[key]=event
                    if i==center:peak_keys.append(key)
            events=list(events.values());peak=[e for e in events if e['is_peak']];pre=[e for e in events if e['category']=='pre_full_number'];peakpre=[e for e in peak if e['category']=='pre_full_number']
            records.append({'layer':layer,'feature_id':d['feature_id'],'source_kind':d['source_kind'],'conversations_in_preview':d['conversations'],'tokens_in_preview':d['tokens'],'preview_file':str(p.relative_to(PROJECT)),'preview_file_sha256':hashlib.sha256(data).hexdigest(),'member_sha256':d['member_sha256'],'source_snapshot_sha256':d['source_snapshot_sha256'],'example_windows':len(d['examples']),'peak_classification_counts':dict(collections.Counter(e['category'] for e in peak)),'pre_number_active_positions':len(pre),'pre_number_distinct_conversations':len({e['conversation'] for e in pre}),'pre_number_peak_examples':len(peakpre),'following_number_histogram':dict(collections.Counter(e['following_number'] for e in pre)),'pre_number_events':sorted(pre,key=lambda e:-e['gate']),'peak_events':peak})
    (OUT/'preview-shortlist-evidence.json').write_text(json.dumps(records,indent=2,ensure_ascii=False)+'\n')
    print('Audited',len(records),'feature records in fresh preview. Raw numeric runs include comma-separated thousands; counts are token adjacency only, not causality.')
    for d in records:
        if d['layer']==29 and d['feature_id'] in [437,1634,1541,2397,1051,1823,1766,1161,2375]:
            print('L%d-T%d'%(d['layer'],d['feature_id']),'peaks',d['peak_classification_counts'],'numbers',d['following_number_histogram'])

if __name__=='__main__':main()
