"""Revision-pinned, local-only label triage. No causal or example-only selection."""
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

OUT=Path(__file__).resolve().parent
PROJECT=OUT.parents[2]
SOURCE=PROJECT/'comparisons/2026-10-21-toxic-persona-survey'
PATS={
 'pre_number_title':re.compile(r'(?:space|whitespace|punctuation|preceding|preposition|before|precedes).*(?:numeric|number|quantit|digit|value)|(?:numeric|number|quantit|digit|value).*(?:space|whitespace|before|precedes|preceding)',re.I),
 'pre_number_explanation':re.compile(r'(?:space|whitespace|punctuation|tokens?|prepositions?|markers?).{0,60}(?:before|precedes|preceding).{0,40}(?:numbers?|numerical|numeric|digits?|quantit(?:y|ies)|integers?|numerals?)',re.I),
 'specific_number_title':re.compile(r'["\x27]\d+["\x27]|(?:digit|number|token|numeric).{0,30}\b\d+\b|\b(?:seven|seventh|eleven|eleventh|twelve|twelfth|thirteen|thirteenth|fourteen|fourteenth|fifteen|fifteenth|sixteen|sixteenth|seventeen|seventeenth|eighteen|eighteenth|nineteen|nineteenth)\b',re.I),
 'numeric_title':re.compile(r'number|numeric|numeral|digit|integer|count|quantitative|quantit(?:y|ies)',re.I),
 'ordinal_count_title':re.compile(r'ordinal|successor|increment|decrement|counting|countdown|number sequence|consecutive|enumerat|numbered list|list item|step number',re.I),
 'calendar_title':re.compile(r'month|calendar|weekdays?|day names|alphabet|letter sequence',re.I),
}

def main():
    old=json.loads((SOURCE/'hf-manifest.json').read_text()); expected={s['layer']:s for s in old['sources']}
    rows=[];sources=[]
    for p in sorted((SOURCE/'hf-labels').glob('layer-*.jsonl')):
        raw=p.read_bytes(); chunk=[json.loads(line) for line in raw.splitlines()];layer=chunk[0]['layer']
        assert len(chunk)==2480 and hashlib.sha256(raw).hexdigest()==expected[layer]['sha256']
        sources.append({'layer':layer,'file':str(p.relative_to(PROJECT)),'sha256':expected[layer]['sha256']})
        for x in chunk:x['source_file']=str(p.relative_to(PROJECT))
        rows.extend(chunk)
    found=[]
    for x in rows:
        title=x.get('title') or '';ex=x.get('explanation') or ''
        cats=[n for n,p in PATS.items() if p.search(ex if n.endswith('explanation') else title)]
        if not cats:continue
        score=25*('pre_number_title'in cats)+12*('pre_number_explanation'in cats)+12*('specific_number_title'in cats)+4*('ordinal_count_title'in cats)+3*('calendar_title'in cats)+2*('numeric_title'in cats)+4*(x['layer']>=20)+3*(x['rank']<=64)
        rec={k:x.get(k) for k in ['layer','feature_id','rank','title','explanation','activation_count','frequency','maximum','mean_active','status','source_file']}
        rec.update(categories=cats,score=score,evidence_level='Label/explanation hypothesis; not a causal +1 gate.',released_url=expected[x['layer']]['url'],dashboard_url=f"https://amsterdam.taild80f17.ts.net/layers/layer-{x['layer']}/features/{x['feature_id']}.html")
        found.append(rec)
    found.sort(key=lambda x:(-x['score'],-x['layer'],x['feature_id']))
    selected={(x['layer'],x['feature_id']) for x in found}
    known=[(29,437),(29,1634),(29,1541),(29,2397),(29,1051),(29,2375)]
    manifest={'checked_at_utc':datetime.now(timezone.utc).isoformat(),'scanned_layers':36,'scanned_transform_slots':len(rows),'slots_with_explanations':sum(bool(r.get('explanation')) for r in rows),'coarse_label_matches':len(found),'repository':old['repository'],'pinned_catalog_revision':old['revision'],'catalog_cache_checked_utc':old['checked_utc'],'all_cached_files_match_pinned_manifest':True,'source_manifest':str((SOURCE/'hf-manifest.json').relative_to(PROJECT)),'known_and_preview_family_numeric_retrieval_recall':{f'L{a}-T{b}':(a,b)in selected for a,b in known},'sources':sources,'patterns':{k:v.pattern for k,v in PATS.items()},'model_runs':0}
    (OUT/'all-label-candidates.json').write_text(json.dumps(found,indent=2)+'\n')
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('Scanned',len(rows),'cached pinned labels; coarse matches',len(found),'known Water retrieved',(29,2375)in selected)
    print('Hidden-family numeric-label recall:',manifest['known_and_preview_family_numeric_retrieval_recall'])

if __name__=='__main__':main()
