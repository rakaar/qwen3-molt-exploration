"""Label-agnostic predecessor-number scan of cached interpretation evaluations."""
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent


def streams(data):
    for method, payload in data.get('methods', {}).items():
        for row_index, row in enumerate(payload.get('rows', [])):
            if 'str_tokens' in row and 'activations' in row:
                yield f'{method}.rows[{row_index}]', row['str_tokens'], row['activations'], {'activating_flag': row.get('activating'), 'distance': row.get('distance')}
            if 'sample' in row:
                sample = row['sample']
                for sample_index, (tokens, acts) in enumerate(zip(sample.get('tokens', []), sample.get('activations', []))):
                    yield f'{method}.rows[{row_index}].sample[{sample_index}]', tokens, acts, {'chosen_quantile': sample.get('chosen_quantile'), 'intruder': sample_index == sample.get('intruder_index')}


def main():
    files = []
    for file in ROOT.glob('comparisons/**/*.json'):
        if 'remote-export' in file.parts or file.stat().st_size < 200000:
            continue
        with file.open() as stream:
            head = stream.read(2000)
        if '"methods"' in head:
            files.append(file)
    features = []
    hits = []
    for file in sorted(files):
        data = json.loads(file.read_text())
        feature = file.stem if re.fullmatch(r'L\d+-T\d+', file.stem) else (f"L1-T{data['id']}" if '2026-10-10-layer1' in str(file) else None)
        if feature is None:
            continue
        dedup, local, all_active = set(), [], Counter()
        for location, tokens, acts, extra in streams(data):
            if len(tokens) != len(acts):
                continue
            for i, gate in enumerate(acts):
                if gate <= 0:
                    continue
                all_active['positions'] += 1
                selected = tokens[i]
                if re.search(r'\d\s*$', selected):
                    continue  # Selected digit could be inside a multi-digit number.
                j = i + 1
                while j < len(tokens) and j < i + 4 and not tokens[j].strip():
                    j += 1
                if j >= len(tokens) or j >= i + 4:
                    continue
                following = ''.join(tokens[j:j+8])
                m = re.match(r'^\s*(\d+(?:[,.]\d+)*(?:st|nd|rd|th)?)', following)
                if not m:
                    continue
                literal = m.group(1)
                scalar = re.sub(r'(st|nd|rd|th)$', '', literal)
                number = int(scalar) if scalar.isdigit() else scalar
                truncated = m.end() == len(following) and j+8 >= len(tokens)
                numeric_continuation = bool(re.search(r'\d$', ''.join(tokens[:i])) and selected.strip() in ['.', ','])
                numeric_type = ('window_truncated' if truncated else ('numeric_continuation' if numeric_continuation else ('decimal_or_grouped' if not scalar.isdigit() else ('ordinal' if literal != scalar else 'integer'))))
                # An activation on letters and punctuation before digits is recorded,
                # but a year/measurement/list item is not assumed to be an ordinal.
                key = (tuple(tokens), i, float(gate))
                if key in dedup:
                    continue
                dedup.add(key)
                record = {'feature': feature, 'label': data.get('label', data.get('title')),
                          'selected_token': selected, 'token_index': i, 'gate': gate,
                          'number': number, 'next_token_index': j, 'distance_to_numeric_token': j-i,
                          'number_literal': literal, 'numeric_type': numeric_type,
                          'intervening_tokens': tokens[i+1:j], 'following_tokens': tokens[j:j+8],
                          'context': ''.join(tokens[max(0,i-15):min(len(tokens),j+14)]),
                          'source_path': str(file.relative_to(ROOT)), 'location': location,
                          'source_sha256': hashlib.sha256(file.read_bytes()).hexdigest(),
                          'source_url': f'https://amsterdam.taild80f17.ts.net/layers/layer-{int(feature.split("-")[0][1:])}/features/{int(feature.split("-")[1][1:])}.html',
                          'evidence_type': 'cached interpretation-evaluation sample; not verified as a top dashboard example', **extra}
                hits.append(record);local.append(record)
        features.append({'feature': feature, 'label': data.get('label', data.get('title')),
                         'unique_pre_number_examples': len(local),
                         'numbers': dict(Counter(r['number'] for r in local)),
                         'active_position_occurrences_before_dedup': all_active['positions']})
    (OUT/'cached-pre-number-hits.json').write_text(json.dumps(hits, indent=2, ensure_ascii=False)+'\n')
    (OUT/'cached-feature-summary.json').write_text(json.dumps(features, indent=2, ensure_ascii=False)+'\n')
    print(json.dumps({'files':len(files),'hits':len(hits),'features':features},indent=2))


if __name__ == '__main__':main()
