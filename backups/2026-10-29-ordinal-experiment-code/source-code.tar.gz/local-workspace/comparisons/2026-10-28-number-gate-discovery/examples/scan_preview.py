"""Label-agnostic predecessor-number screen of the fresh 64-conversation preview.

The corpus is NOT the original dashboard's 10M-token top-example campaign.
Only a subsequent causal intervention can establish an n -> n+1 effect.
"""
import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
DATA = HERE.parent / 'data-access/preview-jsonl'


def candidate(tokens, i):
    selected = tokens[i]
    if re.search(r'\d', selected):
        return None
    j = i + 1
    while j < len(tokens) and j <= i + 3 and not tokens[j].strip():
        j += 1
    if j >= len(tokens) or j > i + 3:
        return None
    following = ''.join(tokens[j:])
    match = re.match(r'^\s*([+-]?\d+(?:[,.]\d+)*(?:[eE][+-]?\d+)?)(st|nd|rd|th)?', following)
    if not match:
        return None
    literal, ordinal = match.group(1), match.group(2)
    leading_space = following[:len(following)-len(following.lstrip())]
    bridge = selected + ''.join(tokens[i+1:j]) + leading_space
    left = ''.join(tokens[:i])
    kind = 'integer'
    if match.end() == len(following):
        kind = 'window_truncated_number'
    elif re.search(r'\d[.,:/-]$', left + bridge):
        kind = 'internal_numeric_continuation'
    elif ',' in literal or '.' in literal or 'e' in literal.casefold():
        kind = 'decimal_grouped_or_scientific'
    elif ordinal:
        kind = 'ordinal_integer'
    try:
        number = int(literal)
    except ValueError:
        number = None
    if kind in ['integer', 'ordinal_integer'] and number is not None and 1000 <= number <= 2100:
        kind = 'year_like_integer'
    tail = following[match.end():]
    if kind == 'integer' and re.match(r'/\d', tail):
        kind = 'fraction_literal'
    if kind == 'integer' and re.search(r'[A-Za-z]-$', left + bridge):
        kind = 'identifier_internal'
    if kind == 'integer' and re.match(r'[A-Za-z]', tail):
        kind = 'number_with_attached_unit_or_identifier'
    if kind == 'integer' and re.search(r'\b(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\s*$', left+bridge, re.I):
        kind = 'date_context'
    context_kind = ('numbered_list_start' if '\n' in bridge and re.match(r'[.)](?:\s|$)', tail) else
                    ('ordinal_suffix' if ordinal else 'other_integer_context'))
    return {'number_literal': literal + (ordinal or ''), 'number': number, 'numeric_type': kind,
            'context_kind': context_kind, 'numeric_token_index': j, 'distance_to_numeric_token': j-i,
            'intervening_tokens': tokens[i+1:j], 'number_boundary_observed': kind != 'window_truncated_number'}


def main():
    files = sorted(DATA.glob('layer-*.jsonl'))
    assert len(files) == 5
    events_path, rejects_path = HERE/'preview-pre-number-events.jsonl', HERE/'preview-rejected-number-events.jsonl'
    summaries, ranked, hypotheses, calibration = [], [], [], []
    total_examples = total_features = 0
    counts = Counter()
    sources = {}
    with events_path.open('w') as event_out, rejects_path.open('w') as reject_out:
        for file in files:
            digest = hashlib.sha256(file.read_bytes()).hexdigest()
            sources[str(file.relative_to(ROOT))] = {'bytes': file.stat().st_size, 'sha256': digest}
            for line_no, line in enumerate(file.open(), 1):
                record = json.loads(line)
                layer, fid = record['layer'], record['feature_id']
                feature = f'L{layer}-T{fid}'
                examples = record['examples']
                total_features += 1; total_examples += len(examples)
                events, seen, active = [], set(), set()
                for ex_index, ex in enumerate(examples):
                    tokens, gates = ex['text'], ex['gates']
                    assert len(tokens) == len(gates)
                    peak = ex['peak']
                    peak_index = next((k for k,g in enumerate(gates) if abs(g-peak) <= 1e-6), None)
                    for i, gate in enumerate(gates):
                        if gate <= 0:
                            continue
                        coordinate = (ex['conversation'], ex['start']+i)
                        active.add(coordinate)
                        parsed = candidate(tokens, i)
                        if parsed is None:
                            continue
                        key = coordinate + (parsed['number_literal'],)
                        if key in seen:
                            continue
                        seen.add(key)
                        event = {'feature': feature, 'layer': layer, 'transform': fid,
                                 'source_kind': record['source_kind'], 'preview_conversations': record['conversations'],
                                 'preview_tokens': record['tokens'], 'source_snapshot_sha256': record.get('source_snapshot_sha256'),
                                 'source_jsonl': str(file.relative_to(ROOT)), 'source_jsonl_line': line_no,
                                 'member': record['member'], 'member_sha256': record['member_sha256'],
                                 'example_index': ex_index, 'conversation': ex['conversation'], 'example_start': ex['start'],
                                 'position': ex['start']+i, 'window_position': i, 'selected_token': tokens[i],
                                 'gate': gate, 'example_peak': peak, 'peak_fraction': gate/peak if peak>0 else 0.,
                                 'is_peak': peak>0 and abs(gate-peak) <= 1e-6,
                                 'is_near_peak_98pct': peak>0 and gate >= .98*peak,
                                 'collector_selected_peak_index': peak_index,
                                 'is_collector_selected_peak': i == peak_index,
                                 'selected_type': 'whitespace' if not tokens[i].strip() else ('punctuation' if not re.search(r'[A-Za-z]',tokens[i]) else 'word_or_subword'),
                                 'following_tokens': tokens[i+1:min(len(tokens),i+12)],
                                 'context': ''.join(tokens[max(0,i-12):min(len(tokens),i+15)]),
                                 'original_dashboard_feature_url': f'https://amsterdam.taild80f17.ts.net/layers/layer-{layer}/features/{fid}.html',
                                 **parsed}
                        if parsed['numeric_type'] not in ['integer','ordinal_integer']:
                            reject_out.write(json.dumps(event,ensure_ascii=False)+'\n')
                            counts[parsed['numeric_type']] += 1
                            continue
                        event_out.write(json.dumps(event,ensure_ascii=False)+'\n')
                        counts['valid_integer_predecessor_events'] += 1
                        events.append(event)
                strong = [e for e in events if e['peak_fraction'] >= .8]
                small = [e for e in strong if e['number'] is not None and 1 <= e['number'] <= 31]
                by_number = defaultdict(list)
                for e in small:
                    by_number[e['number']].append(e)
                scores = []
                for number, group in by_number.items():
                    convs = {e['conversation'] for e in group}
                    peaks = {e['conversation'] for e in group if e['is_peak']}
                    exs = {e['example_index'] for e in group}
                    direct = [e for e in group if e['distance_to_numeric_token'] == 1]
                    direct_convs = {e['conversation'] for e in direct}
                    direct_peaks = {e['conversation'] for e in direct if e['is_peak']}
                    direct_focused = {e['conversation'] for e in direct if e['is_collector_selected_peak']}
                    lagged_convs = {e['conversation'] for e in group if e['distance_to_numeric_token'] > 1}
                    specificity = len(group)/max(len(strong),1)
                    coverage = len(exs)/max(len(examples),1)
                    score = 10*len(direct_focused) + 4*len(direct_peaks) + 2*len(direct_convs) + len(lagged_convs) + 3*specificity + 2*coverage + max(e['peak_fraction'] for e in group)
                    best = []
                    for e in sorted(group,key=lambda e:(e['distance_to_numeric_token']>1,not e['is_collector_selected_peak'],not e['is_peak'],-e['peak_fraction'],-e['gate'])):
                        if e['conversation'] not in {x['conversation'] for x in best}:
                            best.append(e)
                    scores.append({'number':number,'score':score,'distinct_strong_conversations':len(convs),
                                   'distinct_peak_conversations':len(peaks),'strong_events':len(group),
                                   'distinct_direct_strong_conversations':len(direct_convs),
                                   'distinct_direct_exact_peak_conversations':len(direct_peaks),
                                   'distinct_direct_collector_peak_conversations':len(direct_focused),
                                   'distinct_lagged_strong_conversations':len(lagged_convs),
                                   'number_specificity_among_strong_numeric_events':specificity,
                                   'example_coverage':coverage,'best_events':best[:5]})
                scores.sort(key=lambda x:(-x['score'],-x['distinct_strong_conversations'],x['number']))
                summary = {'feature':feature,'layer':layer,'transform':fid,'examples_displayed':len(examples),
                           'active_positions_deduplicated':len(active),'valid_integer_predecessor_events':len(events),
                           'strong_predecessor_events':len(strong),'small_integer_strong_events':len(small),
                           'number_event_counts':dict(Counter(e['number'] for e in events)),
                           'ranked_numbers':scores}
                summaries.append(summary)
                for score in scores:
                    hypotheses.append({'feature':feature,'layer':layer,'transform':fid,'examples_displayed':len(examples),**score})
                if scores:
                    ranked.append({'feature':feature, **{k:v for k,v in summary.items() if k!='ranked_numbers'}, **scores[0]})
                if feature == 'L29-T2375':
                    calibration = events
    ranked.sort(key=lambda x:(-x['score'],-x['distinct_strong_conversations'],x['feature']))
    hypotheses.sort(key=lambda x:(-x['score'],-x['distinct_direct_collector_peak_conversations'],x['feature'],x['number']))
    (HERE/'preview-feature-summary.jsonl').write_text(''.join(json.dumps(s,ensure_ascii=False)+'\n' for s in summaries))
    (HERE/'ranked-preview-candidates.json').write_text(json.dumps(ranked[:200],indent=2,ensure_ascii=False)+'\n')
    (HERE/'ranked-number-hypotheses.json').write_text(json.dumps(hypotheses,indent=2,ensure_ascii=False)+'\n')
    (HERE/'calibration-L29-T2375.json').write_text(json.dumps(calibration,indent=2,ensure_ascii=False)+'\n')
    metadata = {'source_warning':'Fresh 64-conversation/54,828-token preview; NOT original dashboard 10M-token strongest examples.',
                'labels_used_for_ranking':False,'features_scanned':total_features,'displayed_example_windows_scanned':total_examples,
                'features_with_strong_small_integer_events':len(ranked),'counts':dict(counts),'sources':sources,
                'ranking':'Primary rank prioritizes DIRECT numeric next-token events at the collector-selected peak, then any exact-peak ties, then other >=80%-peak activations. Whitespace-lag support counted separately and much lower. Number1..31 hypotheses all retained even if not dominant for that feature. Internal numeric continuations, fractions, attached units/identifiers, year-like numbers and date contexts rejected from primary screen. No causal claim.'}
    (HERE/'preview-scan-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
    print(json.dumps({'metadata':metadata,'top20':[{'feature':r['feature'],'number':r['number'],'score':r['score'],'strong_conversations':r['distinct_strong_conversations'],'peak_conversations':r['distinct_peak_conversations'],'example_coverage':r['example_coverage'],'token':r['best_events'][0]['selected_token'],'gate':r['best_events'][0]['gate'],'context':r['best_events'][0]['context']} for r in ranked[:20]],'calibration_events':calibration},indent=2,ensure_ascii=False))


if __name__=='__main__':main()
