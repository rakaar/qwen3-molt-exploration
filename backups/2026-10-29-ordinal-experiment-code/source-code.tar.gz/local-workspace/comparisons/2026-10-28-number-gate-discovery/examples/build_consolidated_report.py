"""Consolidate existing discovery/pilot artifacts; no model or remote operations."""
from __future__ import annotations

import csv
import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
C = ROOT / "comparisons/2026-10-28-number-gate-discovery"
P = ROOT / "experiments/number-predecessor-pilot-20261028"
OUT = ROOT / "results/2026-10-28-number-gate-discovery"
OUT.mkdir(parents=True, exist_ok=True)
sources = {}


def read(path):
    raw = path.read_bytes()
    sources[str(path.relative_to(ROOT))] = hashlib.sha256(raw).hexdigest()
    return json.loads(raw)


def cell(value):
    return str(value).replace("|", "\\|").replace("\n", "\\n")


def table(headers, rows):
    return "\n".join([
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
        *("| " + " | ".join(cell(x) for x in row) + " |" for row in rows),
    ])


def first(run):
    value = run["assessment"]["first_recognized_answer"]
    if value is None and run["answer"].lstrip().lower().startswith("feb,"):
        return "feb (February)"
    return value or "unrecognized; inspect raw response"


def summarize_batch(label, subpath):
    base = P / subpath
    cases = {x["id"]: x for x in read(base / "cases.json")}
    controls = read(base / "artifacts/controls.json")
    results = read(base / "artifacts/results.json")
    audit = read(base / "artifacts/audit.json")
    eligibility = {x["case_id"]: x for x in read(base / "eligibility.json")["cases"]}
    protocol = read(base / "protocol.json")
    rows, responses = [], []
    for control in controls["controls"]:
        case = cases[control["case_id"]]
        n = case["n"]
        native = control["ordinals"][str(n)]["native"]
        next_native = control["ordinals"][str(n + 1)]["native"]
        off = {r["scope"]: r for r in results["runs"] if r["case_id"] == case["id"]}
        natural = next(r["last_input_gate"] for r in audit["case_summary"]
                       if r["case_id"] == case["id"])
        edits = {scope: [{k: t[k] for k in ["position", "token", "natural_gate", "actual_delta_norm"]}
                         for t in r["trace"] if t["actual_delta_norm"] > 0]
                 for scope, r in off.items()}
        eligible = eligibility[case["id"]]["eligible"]
        if not eligible:
            category = "excluded_native_capability"
        elif not any(edits.values()):
            category = "inactive_noop"
        elif any(first(r) == case["expected"][str(n + 1)] for r in off.values()):
            category = "initial_n_to_n_plus_one"
        else:
            category = "active_no_initial_flip"
        specific = next((r for r in results["specificity_controls"]
                         if r["case_id"] == case["id"]), None)
        row = {
            "batch": label, "case_id": case["id"], "feature": case["feature_key"],
            "domain": case["domain"], "n": n, "eligible": eligible,
            "expected_n": case["expected"][str(n)],
            "expected_n_plus_one": case["expected"][str(n + 1)],
            "native_n_initial": first(native), "native_n_plus_one_initial": first(next_native),
            "native_n_automated_assessment": native["assessment"],
            "native_n_plus_one_automated_assessment": next_native["assessment"],
            "manual_capability_review": eligibility[case["id"]],
            "prompt_n": native["prompt"], "prompt_n_plus_one": next_native["prompt"],
            "last_input_gate": natural, "category": category,
            "off_initial": {scope: first(r) for scope, r in off.items()},
            "off_nonzero_edits": edits,
            "input_scopes_identical_output_tokens": (
                off["input_only"]["output_token_ids"] == off["last_input_only"]["output_token_ids"]
                if off else None),
            "specificity_last_gate": next((t["natural_gate"] for t in specific["trace"]
                                           if t["position"] == len(specific["prompt_token_ids"]) - 1), None)
                if specific else None,
            "specificity_output_tokens_equal_native": specific["output_token_ids"] == next_native["output_token_ids"]
                if specific else None,
        }
        rows.append(row)
        for ordinal, value in control["ordinals"].items():
            for mode in ["native", "zero_strength"]:
                if mode in value:
                    r = value[mode]
                    responses.append(dict(batch=label, case_id=case["id"], ordinal=ordinal,
                                          condition=mode, prompt=r["prompt"], response=r["answer"],
                                          stop_reason=r["stop_reason"]))
    for group in ["runs", "specificity_controls", "repeats"]:
        for r in results[group]:
            responses.append(dict(batch=label, case_id=r["case_id"], ordinal=r.get("ordinal", ""),
                                  condition=r["name"], prompt=r["prompt"], response=r["answer"],
                                  stop_reason=r["stop_reason"]))
    counts = dict(control_runs=sum(len(v) - (1 if "answer_sha256" in v else 0)
                                  for c in controls["controls"] for v in c["ordinals"].values()),
                  main_ablation_runs=len(results["runs"]),
                  specificity_runs=len(results["specificity_controls"]),
                  repeat_runs=len(results["repeats"]))
    assert sum(counts.values()) == audit["counts"]["runs"] == len(responses)
    assert audit["status"] == "passed"
    return dict(cases=rows, responses=responses, run_counts=counts,
                outcome_counts=dict(Counter(r["category"] for r in rows)),
                audit={k: v for k, v in audit.items() if k not in ["file_sha256", "case_summary"]},
                protocol=protocol), controls, results


scan = read(C / "examples/scan-final-summary.json")
shortlist = read(C / "examples/audited-shortlist.json")
labels = read(C / "labels/ranked-shortlist.json")
original = read(C / "original-dashboard-verified.json")
main, controls, results = summarize_batch("initial", Path("."))
follow, _, _ = summarize_batch("alternate_prefix_followup", Path("followup"))
runtime = read(P / "artifacts/final-runtime.json")
identity = read(P / "inherited-base-provenance.json")
positive_control = next(c for c in controls["controls"] if c["case_id"] == "L29-T2397--alphabet")
positive_native = positive_control["ordinals"]["4"]["native"]
positive_off = next(r for r in results["runs"]
                    if r["case_id"] == "L29-T2397--alphabet" and r["scope"] == "last_input_only")


def probe_sum(r, ids):
    return sum(r["steps"][0]["probe_probabilities"][str(i)] for i in ids)


positive = dict(feature="L29-T2397", case_id="L29-T2397--alphabet",
                prompt=positive_native["prompt"],
                native_response=positive_native["answer"], off_response=positive_off["answer"],
                native_D_d_probability=probe_sum(positive_native, [422, 294]),
                off_D_d_probability=probe_sum(positive_off, [422, 294]),
                native_E_e_probability=probe_sum(positive_native, [468, 384]),
                off_E_e_probability=probe_sum(positive_off, [468, 384]),
                probability_definition="Sum of leading-space uppercase/lowercase single next-token probabilities, not a full answer-sequence probability.")
assert len(original["records"]) == 12
assert main["outcome_counts"] == {
    "inactive_noop": 9, "excluded_native_capability": 4,
    "active_no_initial_flip": 4, "initial_n_to_n_plus_one": 1}
assert follow["outcome_counts"] == {
    "inactive_noop": 2, "excluded_native_capability": 3, "active_no_initial_flip": 3}
summary = dict(generated_at_utc=datetime.now(timezone.utc).isoformat(), visibility="private_local",
               claim="One new prompt-specific initial-completion n→n+1 effect: L29-T2397 D→E; no verified pre7/+1 gate.",
               labels_coverage=labels["catalog_coverage"], preview=scan,
               observational_shortlist=shortlist, original_dashboard=original,
               initial=main, followup=follow, positive_case=positive,
               runtime=runtime, inherited_base_identity=identity, source_sha256=sources)
(OUT / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
all_rows = main["cases"] + follow["cases"]
fields = ["batch", "case_id", "feature", "domain", "n", "eligible", "native_n_initial",
          "native_n_plus_one_initial", "last_input_gate", "category", "input_only_initial", "last_input_only_initial",
          "specificity_last_gate", "specificity_output_tokens_equal_native", "prompt_n", "prompt_n_plus_one"]
with (OUT / "cases.csv").open("w", newline="") as f:
    w = csv.DictWriter(f, fields); w.writeheader()
    for r in all_rows:
        flat = {k: r.get(k) for k in fields}
        flat.update(input_only_initial=r["off_initial"].get("input_only"),
                    last_input_only_initial=r["off_initial"].get("last_input_only"))
        w.writerow(flat)
with (OUT / "responses.csv").open("w", newline="") as f:
    w = csv.DictWriter(f, ["batch", "case_id", "ordinal", "condition", "prompt", "response", "stop_reason"])
    w.writeheader(); w.writerows(main["responses"] + follow["responses"])

candidate_rows = []
for s in shortlist:
    note = "observational only; not tested here"
    if s["feature"] in {"L29-T437", "L29-T1634", "L29-T1541", "L29-T2397", "L29-T1051", "L19-T357"}:
        note = "causal pilot below"
    if s["feature"] in {"L9-T1981", "L13-T1829", "L19-T1645"}:
        note = "input-only followup linked below"
    if s["feature"] == "L29-T2375":
        note = "known calibration; not a new discovery"
    candidate_rows.append([s["feature"], s["number"], s["distinct_direct_collector_peak_conversations"],
                           s["distinct_lagged_strong_conversations"], note])
candidate_rows.append(["L19-T1560", 3, 2, 0, "independent selected-feature audit; not tested here"])


def outcome_table(batch):
    rows = []
    for r in batch["cases"]:
        off = r["off_initial"]
        offstr = " / ".join(off.get(s, "—") for s in ["input_only", "last_input_only"])
        rows.append([r["feature"], r["domain"], r["n"], r["native_n_initial"],
                     r["native_n_plus_one_initial"], f'{r["last_input_gate"]:.9g}', offstr,
                     r["category"].replace("_", " ")])
    return table(["Gate", "Domain", "N", "Native N", "Native N+1", "Final-input gate", "Off: all input / final input", "Interpretation"], rows)


original_rows = []
original_notes = []
for r in original["records"]:
    original_notes.append(f'- [{r["feature_key"]}]({r["url"]}): {r["caveat"]}')
    for e in r["examples"]:
        original_rows.append([r["feature_key"], f'{e["conversation"]}:{e["token_position"]}',
                              f'`{cell(e["activating_token"])}`', f'{e["displayed_gate_rounded"]:.3f}',
                              f'`{cell(e["following_text"])}`', e["timing"]])
    for e in r.get("peak_tokens_first_four_examples", r.get("peak_tokens_first_three_examples", [])):
        original_rows.append([r["feature_key"], "coordinate not transcribed", f'`{e["token"]}`',
                              f'{e["gate"]:.3f}', "—", "ON numeral; not a predecessor"])

initial_audit, follow_audit = main["audit"], follow["audit"]
combined_counts = {k: initial_audit["counts"][k] + follow_audit["counts"][k]
                   for k in initial_audit["counts"]}
audit_rows = [[label, data["counts"]["runs"], data["counts"]["vector_files"],
               data["counts"]["vector_positions"], data["independent_transfer_hashes_checked"], data["status"]]
              for label, data in [("Initial", initial_audit), ("Followup", follow_audit)]]
audit_rows.append(["Combined", combined_counts["runs"], combined_counts["vector_files"],
                   combined_counts["vector_positions"],
                   initial_audit["independent_transfer_hashes_checked"] + follow_audit["independent_transfer_hashes_checked"], "passed"])

report = f'''# Number-predecessor MOLT gate discovery — 28 October 2026

Private local research report. Layer, transform, conversation and token positions are zero-based. No publication is implied.

**We found one new, narrowly demonstrated +1 completion effect:** switching off **L29–T2397** at the final ` is` in `the fourth letter of the english alphabet is` changes the greedy initial answer from **d to e**. This gate was found from actual examples before **4**, despite its general structural label. The effect does not establish a general increment mechanism: the answer stayed at **IV** with this gate ablated on a Roman-numeral fourth-integer prompt, and capitalization alone made the fourth-letter native answer incorrect before intervention. **No well-supported before-7 gate, or new 7→8 causal effect, was established.**

## Evidence and coverage

The search deliberately separated labels, activation timing and causal intervention.

| Source | Coverage | What it supports |
| --- | --- | --- |
| Revision-pinned released label catalog | 36 layers; 89,280 slots; 85,488 explanations; 4,671 coarse numeric/ordinal/calendar matches | Retrieval and descriptive context only |
| Label-agnostic aligned activation preview | Layers 9, 13, 19, 22, 29; 12,400 feature records; 66,450 windows | Observed predecessor timing on a fresh 64-conversation / 54,828-token sample |
| Original authenticated dashboard | Selected examples from 12 feature pages; original 10,000,000-token campaign | Independent original-campaign timing checks; not a complete original-corpus scan |
| Initial causal pilot | 18 planned feature/domain cases; 14 capability-eligible; 124 model runs | Exact native controls and two input-ablation scopes |
| Exploratory alternate-prefix followup | 8 planned cases; 5 capability-eligible; 49 runs | Limited checks in Roman numerals and capitalized “English” prefixes |

The preview is **not** the original dashboard's top-example dataset. It contains the first 64 UltraChat `test_sft` conversations, truncated to at most 1,024 tokens each; each feature keeps up to eight strongest distinct-conversation peak windows, with up to 16 tokens on either side. Of 12,400 records, 10,406 have at least one displayed example and 1,994 have none. The public interpretation release does not expose the original activation arrays or rendered examples; its scoring prompts often end at the peak, omitting the following token. A 36-layer label scan is therefore not a 36-layer activation-example scan.

Pinned labels: `georglange/qwen3-4b-molt-interpretations@5160cb8fb34db41545e8ceabb3fb1ea047b519e4`; all 36 cached label hashes match the release manifest. Model/weight provenance is discussed under audit below. Detailed access provenance: [data-access notes](../../comparisons/2026-10-28-number-gate-discovery/data-access/README.md).

## Finding actual predecessor activations

A gate belongs to the displayed selected token. A **direct predecessor** means the next token starts the number; a **whitespace-lag** event has intervening blank token(s). Gates firing **on** a numeral are a different category. Split digit tokens were reconstructed (for example `1`, `1` means 11), with complete-number boundaries required. The collector-selected peak is the first maximum in the conversation, normally window index 16; tied later maxima and secondary positive gates were counted separately.

Across 153,444 deduplicated positive feature/conversation/position records, the scan retained **2,360 integer-predecessor events**: 1,394 direct and 966 whitespace-lag. By activation strength/location, 916 were collector-selected peaks, 2 other equal maxima and 1,442 lower positive activations. There were 540 direct collector-peak events before any accepted integer, including 392 before integers 1–31 across 211 features.

The primary screen rejected 419 internal-numeral continuations, 177 decimal/grouped/scientific values, 155 fractions, 343 year-like integers, 40 date contexts, 59 identifier-internal events, 107 attached units/identifiers and 72 numbers truncated by the window. These remain in a separate rejection stream. Thus a space before 521 is not counted as before the whole number 5, and a period inside an IP address is not counted as an ordinal predecessor.

Labels were joined **after** activation ranking. The declared coarse label retrieval missed five of six selected known/late-layer-family gates, including the known L29–T2375 Water gate; it retrieved only L29–T1541. That is a diagnostic on this selected family, not a corpus-wide recall estimate.

### Observational shortlist

Counts below are distinct conversations in the small preview. “Direct peak” uses the actual collector-selected maximum; lagged strong support is separate. These counts describe association, not causal efficacy or number exclusivity.

{table(["Gate", "Following integer", "Direct peak conversations", "Lagged strong conversations", "Status"], candidate_rows)}

The four before-2 features share much of the same source text; they are not four independent datasets. The family often fires on punctuation/newlines at list boundaries. L19–T357 has only two before-6 recipe examples; L29–T2401 before-6 is on `Chapter` or `Slide` with a following whitespace token. The known calibration L29–T2375 has newline gate 1.96875 at preview conversation 39, token 329, directly before the split digits of 11; another example precedes 21st, so even this is not eleven-exclusive.

Exact preview contexts, selected tokens, strengths, coordinates, source-member hashes and dashboard links are in [audited shortlist](../../comparisons/2026-10-28-number-gate-discovery/examples/audited-shortlist.json). [Full scan notes](../../comparisons/2026-10-28-number-gate-discovery/examples/README.md) and [independent label/preview audit](../../comparisons/2026-10-28-number-gate-discovery/labels/README.md) preserve the separate search outputs.

### Original-dashboard verification

These are selected DOM-backed transcriptions from the original 10M-token dashboard, checked read-only on 28 October. Gates are **UI-rounded to three decimals**; following text may be shortened. Conversation IDs here belong to the original campaign, not the 64-conversation preview. For entries marked “direct”, leading whitespace can be part of a single following token; this source is a selected transcription, not the primary strict numeric-event parser. Filename, array, identifier and time examples are retained visibly rather than promoted to standalone ordinal evidence.

{table(["Gate", "Conversation:token", "Activating token", "Gate (UI)", "Following text", "Timing"], original_rows)}

{chr(10).join(original_notes)}

Machine-readable transcriptions and source links: [original-dashboard-verified.json](../../comparisons/2026-10-28-number-gate-discovery/original-dashboard-verified.json). These checks confirm some predecessor associations while showing that several gates also respond to numeric substrings or structure.

### Seven-focused leads and rejections

No feature has repeated before-7 support across more than one independent conversation in this preview. L22–T207 has one selected-peak space before `Chapter 7` (conversation 5, position 650, gate 2.640625); its other contexts are broad technical/proper-noun/date contexts. L9–T42 has one space before `Slide 7` (conversation 56, position 450, gate 2.171875), but is active on 9,988,655 of 10M original tokens (99.89%), so this is weak evidence. L19–T90 is a lagged `Slide` header lead; L19–T304 has only a lower secondary before-7 gate, about one quarter of its selected peak. These are not seven detectors.

L29–T1766/T1823 before-7 contexts come from the same USDA-zone conversation, not independent counting examples. L19–T200 fires on the `Now` part of a name before a new list line. L9–T1963 fires on 7 within `37mm`; its apparent predecessor was an oregano suffix before an ingredient fraction. L29–T1021/T1247 are mainly on-number/within-number features. L13–T2246 is a broad pre-year/pre-number space gate. Original checks rejected L26–T1452, L30–T1453, L6–T1331 and L27–T2011 as supported before-7 candidates: their strongest displayed peaks are on 7/VII or numeric-internal separators. This does not prove no unseen precursor context exists.

## Causal pilot: what was actually removed

The resident native Qwen3-4B MLPs were retained. For one selected transform at selected **input** positions, the edit subtracts its natural scalar gate multiplied by its input-dependent low-rank operator contribution, targeting gate zero. The remaining native MLP contribution is preserved. Computation uses FP32 for the edit, then one BF16 rounding. This is a contribution ablation, not replacement of every native MLP by a MOLT approximation.

Each candidate was tested separately. The two scopes were **all input tokens** and **only the final input token**; neither scope steered generated output tokens. Prompts were raw completion prefixes, greedy decoding, at most 24 new tokens, with no chat template or thinking wrapper. The six candidates were L29–T437/1634/1541/2397/1051 for N=1/2/3/4/5 and L19–T357 for N=6. Their initial three domains were months, English alphabet letters and a synthetic numbered fruit list.

Before ablation, native completions for **both N and N+1** had to be initially correct, and an observer with zero intervention had to reproduce native exactly. Full responses were manually reviewed and their hashes bound in eligibility files before intervention. The criterion concerns the **initial answer**, not later text. In particular, raw `feb` was accepted as February; two automated month-parser nulls are recorded as parser disagreements rather than native capability failures. Wrong third-letter B and sixth-letter E completions excluded four initial alphabet cases.

Initial bookkeeping: **54 controls** (36 native N/N+1 + 18 zero observers), **28 ablations** (14 eligible × 2 scopes), **14 N+1 specificity checks**, and **28 repeats** (14 native + 14 final-input ablations): **124 runs**. Conditions and deterministic repeats are not independent statistical samples.

{outcome_table(main)}

All six month gates were inactive on these prefixes, so month outputs did not change. Nine eligible cases were wholly inactive/no-op, four list cases removed a nonzero contribution but kept the same initial number, and one case changed to N+1. Inactivity is not evidence that an active feature has no causal effect. All 14 N+1 specificity gates were also zero and their full saved outputs matched native: useful no-op checks, but not active, norm-matched specificity controls.

### New positive: fourth letter D → E

Exact raw prefix:

```text
the fourth letter of the english alphabet is
```

L29–T2397 naturally activated at final token ` is`, position **7**, with gate **0.7188358306884766**. Setting its contribution to zero produced actual removed-vector norm **8.819436073303223**. In the all-input scope this was the only nonzero edit, so both scopes produced identical saved output tokens and next-token distributions.

| Next-token probability mass | Native | Gate off |
| --- | ---: | ---: |
| ` D` + ` d` | {100 * positive['native_D_d_probability']:.10f}% | {100 * positive['off_D_d_probability']:.10f}% |
| ` E` + ` e` | {100 * positive['native_E_e_probability']:.10f}% | {100 * positive['off_E_e_probability']:.10f}% |

These are sums over two leading-space, single-token case variants, not whole-answer probabilities. Native greedily starts ` d`; ablation starts ` e`. The fifth-letter native control initially answers E correctly; ablating that matched N+1 prefix has gate zero and leaves its output unchanged.

Saved native continuation (24-token cap):

```text
{positive_native['answer']}
```

Saved gate-off continuation:

```text
{positive_off['answer']}
```

The first completion is a clear D→E change; the continuing text is not a uniformly coherent answer to the requested question. Native raw completions also contain self-questioning, repetition and later mistakes. The supported causal claim is therefore **a prompt-specific initial-answer shift**, not coherent general arithmetic, a validated counting circuit, or complete semantic control.

## Completed alternate-prefix followup

After seeing D→E, eight alternate cases were declared: Roman positive integers N=2–5 and letter prompts differing by capitalized `English`, for the same four L29 gates. This is exploratory followup chosen after the pilot, not an independent preregistered replication. Native N/N+1 eligibility was checked again: only five cases passed, because capitalized third-letter and fourth-letter raw prefixes were already wrong. Roman numeral matching ignores case, and native quoted `f` was accepted as F.

Followup bookkeeping: **24 controls + 10 ablations + 5 specificity + 10 repeats = 49 runs**. The second CPU audit passed. No added +1 effect appeared.

{outcome_table(follow)}

L29–T2397 was active at the final ` is` for the fourth Roman-integer prefix (gate 0.7557848691940308), but the answer stayed IV under either scope. L29–T1051 was active for the fifth Roman integer (1.0638526678085327) and capitalized-English fifth-letter prefix (1.0883034467697144), but stayed V and E respectively. Roman N=2/3 were inactive no-ops. All five N+1 specificity checks were inactive and exactly reproduced native. The native capitalized fourth-letter prefix already started E, so it cannot be counted as a successful induced D→E effect.

Exact prompts, full native/off/specificity/repeat continuations and eligibility decisions are available in [cases.csv](cases.csv), [responses.csv](responses.csv) and [summary.json](summary.json).

## Independent audit and provenance

Both CPU audits reconstruct saved gates/operators and sampled edits from local weight slices, verify saved next-token probabilities and BF16 rounding, verify transfer/vector hashes, test unselected-position invariance, and compare zero observers, repeats and no-ops. They report:

{table(["Batch", "Runs", "Vector files", "Sampled vector positions", "Verified remote-artifact hashes", "CPU audit"], audit_rows)}

Combined: 26 exact native/zero pairs, 38 exact repeat comparisons, and 41 exact no-op comparisons. The maximum absolute encoder reconstruction error is {max(initial_audit['errors']['max_encoder_absolute'], follow_audit['errors']['max_encoder_absolute']):.9g}; maximum relative operator L2 error {max(initial_audit['errors']['max_operator_relative_l2'], follow_audit['errors']['max_operator_relative_l2']):.9g}; maximum saved-probability reconstruction error {max(initial_audit['errors']['max_probability_reconstruction'], follow_audit['errors']['max_probability_reconstruction']):.9g}. All sampled BF16 edits matched exactly; all saved vector hashes matched. Final runtime reports zero remaining hooks and unchanged attention implementation.

Expected base revision: `Qwen/Qwen3-4B@1cfa9a7208912126459214e8b04321603b3df60c`; MOLT weights: `georglange/qwen3-4b-molt@081ce901b090b64aeecf9bc8709b57c10411e32a`. The warm base model was inherited from the prior CH run, whose loader SHA-verifies every expected base file before local-only loading. [Inherited-base provenance](../../experiments/number-predecessor-pilot-20261028/inherited-base-provenance.json) pins those loading sources and verification files. Runtime configuration has a null commit hash because it loaded a local cache; this pilot did not compute a fresh whole-base file/memory hash.

Limits of the audit: reconstruction starts from saved standardized FP32 residuals rather than the original residual x; vectors sample selected positions/steps rather than saving every vector; the all-input scope has no separate repeat (native and final-input ablations do); prior loading provenance supplies checkpoint identity. Passing these checks verifies the recorded intervention implementation within those limits, not a broad semantic mechanism.

Primary hash-bound measurements: [initial controls](../../experiments/number-predecessor-pilot-20261028/artifacts/controls.json), [initial results](../../experiments/number-predecessor-pilot-20261028/artifacts/results.json), [initial audit](../../experiments/number-predecessor-pilot-20261028/artifacts/audit.json); [followup controls](../../experiments/number-predecessor-pilot-20261028/followup/artifacts/controls.json), [followup results](../../experiments/number-predecessor-pilot-20261028/followup/artifacts/results.json), [followup audit](../../experiments/number-predecessor-pilot-20261028/followup/artifacts/audit.json). Their hashes and report-generation inputs are preserved in `summary.json`; full raw responses remain private here.

## Expanded gate-off study

The [cross-domain followup](../2026-10-28-t2397-cross-domain-ablation/README.md) extends T2397 to ten raw-prefix task families and third/fourth targets. It completed 187 additional planned runs after native capability review. D→E reproduced; no additional initial-answer shift appeared. Integer 4, Roman IV and square 16 remained unchanged despite active contributions before their answers. The linked report separates inactive cases, native failures, generated-space activations and the four intervention scopes. These 187 runs are separate from the 173-run discovery pilot above.

## Separate tests of the before-2, before-3 and before-5 gates

The [T1634/T1541/T1051 cross-domain study](../2026-10-28-l29-n235-cross-domain-ablation/README.md) tested each gate separately after checking native N and N+1 answers. Seven of ten question families passed capability screening per gate. No initial-answer change appeared. T1634/T1541 were inactive before the eligible question answers; additional active numbered-list controls retained 2 and 3. T1051 was active before six eligible question answers and changed probabilities without an initial-answer flip. Across the question suite and three active list controls, 390 completed runs were audited. These runs are separate from the earlier discovery and T2397-only studies.

## Other-layer before-2 gates: restricted input-only check

The [three-task input-only study](../2026-10-28-other-before2-input-only/README.md) tested L9–T1981, L13–T1829 and L19–T1645 separately on months, Roman numerals and positive-integer positions. Both native second/third answers passed before intervention. No initial-answer change appeared under all-input or final-input-only ablation. Only L9–T1981 was active in any tested input, at formatting tokens in the chat-formatted integer case; the other inputs were inactive. Generated tokens were never edited. The integer format was repaired based on native capability before intervention; failed raw-QA baselines were preserved separately. This limited study does not establish absence of effects in naturally active numbered-list contexts.

## Interpretation and remaining work

The activation examples reveal a useful family of boundary features that labels hide. One newly tested member, L29–T2397, supports the fourth-letter D answer on one raw prefix, and removing it shifts the model to E. Generalization is unresolved: active Roman/list conditions did not show the same initial shift, while native capability failures make several superficially simple prefixes unsuitable tests.

A next experiment should retain exact N/N+1 capability checks, measure natural activation on each prompt, and distinguish inactive no-ops from active removals. For T2397, matched raw/chat prompt variants, active norm-matched unrelated-transform controls, and a contribution dose/restoration test would help determine whether the D→E shift is specific and stable. The before-2 features in layers 9/13/19 now have the limited input-only checks linked above; their tested question inputs were mostly inactive. L19–T363 remains an observational candidate. A stronger seven search requires more aligned postpeak activation coverage; the current search does not justify claiming that such gates do not exist.

The exploratory alternate-prefix followup is complete and audited. No further model runs, publishing or resource lifecycle action is part of this report-generation step.
'''
(OUT / "README.md").write_text(report)
print(json.dumps({"output": str(OUT), "cases": len(all_rows), "responses": len(main["responses"]) + len(follow["responses"]),
                  "main_outcomes": main["outcome_counts"], "followup_outcomes": follow["outcome_counts"],
                  "combined_audit_counts": combined_counts, "source_files": len(sources)}))
