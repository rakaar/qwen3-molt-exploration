"""Package code/configuration only; keep raw experimental data in the local archive."""
import hashlib
import io
import json
import re
import tarfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
PRIVATE=ROOT/'artifacts/experiment-closeout-20261029'
OUT=ROOT/'backups/2026-10-29-ordinal-experiment-code'
OUT.mkdir(parents=True,exist_ok=True)
m=json.loads((PRIVATE/'experiment-closeout-20261029.manifest.json').read_text())
source={}
configs={'protocol.json','plan.json','cases.json','case-templates.json','ground-truth.json','expected-base-verification.json','integer-chat-prompts.json'}
def selected(p):
    return p.suffix in {'.py','.sh','.toml','.yaml','.yml'} or p.name in configs or (p.name=='manifest.json' and p.parent.name=='weights') or (p.suffix=='.txt' and any(s in p.name.lower() for s in ['requirement','freeze']))
for row in m['files']:
    p=Path(row['path'])
    if selected(p):
        data=(PRIVATE/'verified-content'/row['sha256']).read_bytes()
        assert hashlib.sha256(data).hexdigest()==row['sha256']
        source['remote-workspace/'+row['path']]=data
for folder in (ROOT/'experiments').iterdir():
    if not folder.is_dir() or not any(folder.name.startswith(x) for x in ['ch-coactivation-','water-','t2397-cross-domain-','l29-n235-','other-before2-','ordinal-ablation-site-']):continue
    for p in folder.rglob('*'):
        if not p.is_file() or p.is_symlink() or any(x in p.parts for x in ['__pycache__','.venv','artifacts','model']):continue
        if selected(p):source['local-workspace/'+str(p.relative_to(ROOT))]=p.read_bytes()
for p in (ROOT/'comparisons/2026-10-28-number-gate-discovery').rglob('*.py'):
    source['local-workspace/'+str(p.relative_to(ROOT))]=p.read_bytes()
for p in Path(__file__).parent.glob('*.py'):
    source['local-workspace/'+str(p.relative_to(ROOT))]=p.read_bytes()
patterns=[rb'-----BEGIN [A-Z ]*PRIVATE KEY-----',rb'gh[pousr]_[A-Za-z0-9]{30,}',rb'github_pat_[A-Za-z0-9_]{30,}',rb'hf_[A-Za-z0-9]{30,}',rb'AKIA[0-9A-Z]{16}']
suspect=[name for name,b in source.items() if any(re.search(p,b) for p in patterns)]
assert not suspect, {'review_before_upload':suspect}
entries=[{'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for name,b in sorted(source.items())]
archive=OUT/'source-code.tar.gz'
with tarfile.open(archive,'w:gz') as t:
    for name,b in sorted(source.items()):
        info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o755 if name.endswith('.sh') else 0o644
        t.addfile(info,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as t:
    for row in entries:assert hashlib.sha256(t.extractfile(row['path']).read()).hexdigest()==row['sha256']
result={'created_date':'2026-10-29','scope':'Experiment source, run/audit/report code, task configurations and dependency records. Raw outputs, audit vectors, model/transform weights and credentials are excluded from this public source bundle.','remote_code_file_count':sum(Path(r['path']).suffix in ['.py','.sh'] for r in m['files']),'source_files':len(entries),'source_bytes':sum(r['bytes'] for r in entries),'source_archive':'source-code.tar.gz','archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.file_digest(archive.open('rb'),'sha256').hexdigest(),'base_checkpoint':'Qwen/Qwen3-4B@1cfa9a7208912126459214e8b04321603b3df60c','molt_checkpoint':'georglange/qwen3-4b-molt@081ce901b090b64aeecf9bc8709b57c10411e32a','files':entries}
(OUT/'source-manifest.json').write_text(json.dumps(result,indent=2)+'\n')
(OUT/'RESTORE.txt').write_text('Experiment source backup — 29 October 2026\n\nExtract source-code.tar.gz with: tar -xzf source-code.tar.gz\n\nremote-workspace/ preserves the source/configuration layout on the experiment GPU.\nlocal-workspace/ preserves local preparation, launch, analysis, audit and report scripts,\nincluding the ordinal results-site exporter. All 117 remote Python/shell source files\nare included unchanged. See source-manifest.json for exact file hashes and pinned\npublic base/MOLT checkpoint revisions.\n\nThis is a source backup, not an inference-ready environment. The original scripts\ninclude task-specific paths and some expect an already loaded native model. Restore\nthe recorded environment and supporting data/weights before executing them. Nothing\nin the backup starts a GPU or runs inference automatically.\n\nThe full private backup (all 5,640 remote files, including raw generations, audit\nvectors, logs and selected transform weights) was retained and hash-verified locally.\nLarge public base weights and virtual environments are reproducible and excluded.\nNo dashboard disk contents are part of this experiment backup.\n')
print(json.dumps({k:v for k,v in result.items() if k!='files'},indent=2))
