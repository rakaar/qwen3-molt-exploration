"""Match the fresh remote manifest against prior backups and retrieve only gaps."""
import hashlib
import json
import os
import shutil
import sys
import tarfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'artifacts/experiment-closeout-20261029'
manifest=json.loads((OUT/'experiment-closeout-20261029.manifest.json').read_text())
rows=manifest['files'];needed={r['sha256'] for r in rows}
sizes={r['bytes'] for r in rows}
blobs=OUT/'verified-content';blobs.mkdir(exist_ok=True)
found={p.name for p in blobs.iterdir() if p.is_file() and hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==p.name}

def accept(data):
    if len(data) not in sizes:return
    key=hashlib.sha256(data).hexdigest()
    if key in needed and key not in found:
        (blobs/key).write_bytes(data);found.add(key)

if sys.argv[1]=='index':
    assert shutil.disk_usage(OUT).free>2_000_000_000
    roots=[ROOT/'experiments'/n for n in manifest['roots']]
    roots += [p for p in (ROOT/'comparisons').glob('2026-10-28-*') if any(s in p.name for s in ['coactivation','water','number-gate','t2397','l29-n235','other-before2'])]
    for root in roots:
        if not root.exists():continue
        for path,dirs,files in os.walk(root):
            dirs[:]=[d for d in dirs if d not in ['.venv','model','__pycache__','.git']]
            for name in files:
                p=Path(path)/name
                if not p.is_symlink() and p.stat().st_size in sizes:accept(p.read_bytes())
    print(json.dumps({'matched_from_local_files':len(found),'unique_hashes_needed':len(needed)}),flush=True)
    for archive in sorted((ROOT/'artifacts').glob('*20261028*private-backup.tar.gz')):
        if found>=needed:break
        with tarfile.open(archive,'r|gz') as t:
            for m in t:
                if m.isfile() and m.size in sizes:accept(t.extractfile(m).read())
        print(json.dumps({'archive_checked':archive.name,'unique_hashes_found':len(found)}),flush=True)
    missing=[r for r in rows if r['sha256'] not in found]
    (OUT/'missing-files.json').write_text(json.dumps(missing,indent=2)+'\n')
    print(json.dumps({'fresh_manifest_files':len(rows),'matched_files':len(rows)-len(missing),'missing_files':len(missing),'missing_bytes':sum(r['bytes'] for r in missing)}),flush=True)
elif sys.argv[1]=='assemble':
    gap=OUT/'missing-files.tar.gz'
    if gap.exists():
        with tarfile.open(gap,'r|gz') as t:
            for m in t:
                if m.isfile():accept(t.extractfile(m).read())
    assert found>=needed, {'missing_hashes':len(needed-found)}
    dest=OUT/'verified-full-experiment-backup.tar.gz'
    with tarfile.open(dest,'w:gz',compresslevel=3) as t:
        for row in rows:
            assert not Path(row['path']).is_absolute() and '..' not in Path(row['path']).parts
            p=blobs/row['sha256'];assert p.stat().st_size==row['bytes']
            t.add(p,arcname=row['path'],recursive=False)
        t.add(OUT/'experiment-closeout-20261029.manifest.json',arcname='BACKUP-MANIFEST.json')
    expected={r['path']:r for r in rows};seen=set()
    with tarfile.open(dest,'r|gz') as t:
        for m in t:
            if not m.isfile() or m.name=='BACKUP-MANIFEST.json':continue
            b=t.extractfile(m).read();r=expected[m.name]
            assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'],m.name
            seen.add(m.name)
    assert seen==set(expected)
    receipt={'status':'verified','instance_id':58073786,'remote_manifest_files':len(rows),'verified_archived_files':len(seen),'fresh_remote_manifest_matches_every_file':True,'archive':str(dest),'archive_bytes':dest.stat().st_size,'archive_sha256':hashlib.file_digest(dest.open('rb'),'sha256').hexdigest(),'method':'Matched fresh remote file hashes against existing local copies and prior archives; copied gaps; independently streamed every final archived file to verify its SHA256.'}
    (OUT/'backup-verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt),flush=True)
