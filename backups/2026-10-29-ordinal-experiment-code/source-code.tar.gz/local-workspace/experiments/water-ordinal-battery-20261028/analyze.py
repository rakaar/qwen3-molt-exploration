"""Audit native capability gating, all-token coverage, and sampled edit vectors."""
import csv
import hashlib
import json
import math
from pathlib import Path

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
EXPORT=ROOT/'comparisons/2026-10-28-water-ordinal-battery/remote-export/water-ordinal-battery-20261028'
OUT=ROOT/'results/2026-10-28-water-ordinal-battery'


def bf16_round(x):
    bits=np.ascontiguousarray(x,dtype=np.float32).view(np.uint32)
    bits=bits+np.uint32(0x7FFF)+((bits>>16)&1)
    return (bits & np.uint32(0xFFFF0000)).view(np.float32)


def main():
    OUT.mkdir(exist_ok=True)
    controls=json.loads((EXPORT/'artifacts/controls.json').read_text())
    results=json.loads((EXPORT/'artifacts/results.json').read_text())
    refinement=json.loads((EXPORT/'artifacts/refinement.json').read_text())
    cases=json.loads((EXPORT/'cases.json').read_text());by_case={c['id']:c for c in cases}
    reviewed={e['case_id']:e for e in results['eligibility']['cases']}
    assert controls['status']==results['status']=='complete'
    assert refinement['status']=='complete' and refinement['hooks_remaining']==0
    assert refinement['parent_results_sha256']==hashlib.sha256((EXPORT/'artifacts/results.json').read_bytes()).hexdigest()
    assert refinement['source_sha256']==hashlib.sha256((EXPORT/'refine.py').read_bytes()).hexdigest()
    assert controls['hooks_remaining']==results['hooks_remaining']==0
    assert hashlib.sha256((EXPORT/'artifacts/controls.json').read_bytes()).hexdigest()==results['controls_sha256']
    assert results['eligibility']['controls_file_sha256']==results['controls_sha256']
    for record in [controls,results]:
        for name,expected in record['source_sha256'].items():
            assert hashlib.sha256((EXPORT/name).read_bytes()).hexdigest()==expected
    feature=controls['feature'];file=EXPORT/'weights'/feature['file']
    assert (feature['layer'],feature['transform'])==(29,2375)
    assert hashlib.sha256(file.read_bytes()).hexdigest()==feature['sha256']
    with np.load(file,allow_pickle=False) as a:w={k:a[k].astype(np.float64) for k in a.files}
    n_vectors=n_vector_positions=n_coverage=n_runs=0
    errors={'max_gate_score_absolute_error':0.,'max_operator_relative_l2_error':0.,'max_probability_reconstruction_error':0.}

    def audit(run):
        nonlocal n_vectors,n_vector_positions,n_coverage,n_runs
        n_runs+=1
        assert run['hooks_remaining']==0
        if run['target'] is not None:
            expected=len(run['prompt_token_ids'])+len(run['output_token_ids'])-1
            assert len(run['trace'])==expected
            assert [t['position'] for t in run['trace']]==list(range(expected))
            for t in run['trace']:
                index=t['position']
                token=run['prompt_token_ids'][index] if index<len(run['prompt_token_ids']) else run['output_token_ids'][index-len(run['prompt_token_ids'])]
                assert t['token_id']==token and t['fixed_gate']==run['target'] and t['alpha']==run['alpha']
            n_coverage+=expected
        for s in run['steps']:
            error=abs(math.exp(s['selected_logit']-s['logsumexp'])-s['selected_probability'])
            errors['max_probability_reconstruction_error']=max(errors['max_probability_reconstruction_error'],error)
            assert error<8e-6
        for v in run['vectors']:
            path=EXPORT/'artifacts'/v['file'];assert hashlib.sha256(path.read_bytes()).hexdigest()==v['sha256']
            with np.load(path,allow_pickle=False) as a:x={k:a[k] for k in a.files}
            assert len(x['positions'])==x['gate'].size
            assert all(any(t['position']==int(p) for t in run['trace']) for p in x['positions'])
            raw=x['z'].astype(np.float64)@w['e']+w['bias'][0]
            error=float(np.max(np.abs(raw-x['raw'])));errors['max_gate_score_absolute_error']=max(errors['max_gate_score_absolute_error'],error)
            assert np.allclose(raw,x['raw'],atol=3e-5,rtol=3e-5)
            gate=np.where((raw>w['theta'][0])&(raw>0),raw,0.)
            assert np.allclose(gate,x['gate'],atol=3e-5,rtol=3e-5)
            operator=(x['z'].astype(np.float64)@w['V']@w['U'])*w['output_std']
            error=float(np.linalg.norm(operator-x['operator'])/max(np.linalg.norm(operator),1e-12))
            errors['max_operator_relative_l2_error']=max(errors['max_operator_relative_l2_error'],error);assert error<1e-4
            delta=np.float32(v['alpha'])*(np.float32(v['target'])-x['gate'])[...,None]*x['operator']
            assert np.array_equal(delta,x['intended_delta'])
            assert np.array_equal(bf16_round(x['native_mlp']+delta),x['edited_mlp'])
            assert np.array_equal(x['edited_mlp']-x['native_mlp'],x['actual_delta'])
            n_vectors+=1;n_vector_positions+=x['gate'].size

    native_by_id={};control_summary=[]
    for row in controls['controls']:
        cid=row['case_id'];native_by_id[cid]=row['first'];e=reviewed[cid];case=by_case[cid]
        for key in ['first','eleventh','zero_first','zero_11th']:audit(row[key])
        for a,b in [('first','zero_first'),('eleventh','zero_11th')]:
            assert row[a]['steps']==row[b]['steps'] and row[a]['output_token_ids']==row[b]['output_token_ids']
        assert hashlib.sha256(row['first']['answer'].encode()).hexdigest()==e['first_answer_sha256']
        assert hashlib.sha256(row['eleventh']['answer'].encode()).hexdigest()==e['eleventh_answer_sha256']
        assert e['eligible']==(e['first_correct'] and e['eleventh_correct'])
        control_summary.append({'case_id':cid,'label':case['label'],'first_prompt':case['first_prompt'],
                                'eleventh_prompt':case['eleventh_prompt'],'first_expected':case['original_expected'],
                                'eleventh_expected':case['target_expected'],'native_first':row['first']['answer'],
                                'native_eleventh':row['eleventh']['answer'],'first_stop':row['first']['stop_reason'],
                                'eleventh_stop':row['eleventh']['stop_reason'],'eligible':e['eligible'],
                                'review_reason':e['review_reason'],
                                'first_naturally_active_positions':sum(t['natural_gate']>0 for t in row['zero_first']['trace']),
                                'eleventh_naturally_active_positions':sum(t['natural_gate']>0 for t in row['zero_11th']['trace'])})
    rows=[]
    for run in results['gate_runs']:
        audit(run);assert reviewed[run['case_id']]['eligible']
        assert run['prompt']==by_case[run['case_id']]['first_prompt']
        rows.append({'phase':'sparse_screen','case_id':run['case_id'],'fixed_gate':run['target'],'answer':run['answer'],
                     'stop_reason':run['stop_reason'],**run['assessment']})
    for run in results['case_repeats']:
        audit(run)
        if run['name']=='native_repeat':original=native_by_id[run['case_id']]
        else:original=next(r for r in results['gate_runs'] if r['case_id']==run['case_id'] and r['target']==run['target'])
        assert run['output_token_ids']==original['output_token_ids'] and run['steps']==original['steps']
        if run['name']=='target_repeat':assert run['trace']==original['trace']
    for run in refinement['runs']:
        audit(run);assert reviewed[run['case_id']]['eligible']
        assert run['prompt']==by_case[run['case_id']]['first_prompt']
        rows.append({'phase':'adaptive_refinement','case_id':run['case_id'],'fixed_gate':run['target'],
                     'answer':run['answer'],'stop_reason':run['stop_reason'],**run['assessment']})
    for run in refinement['repeats']:
        audit(run)
        original=(native_by_id[run['case_id']] if run['name']=='refinement_native_repeat' else
                  next(r for r in refinement['runs'] if r['case_id']==run['case_id'] and r['target']==run['target']))
        assert run['output_token_ids']==original['output_token_ids'] and run['steps']==original['steps']
        if run['name']=='refinement_target_repeat':assert run['trace']==original['trace']
    grid=results['protocol']['fixed_gate_values'];summary=[]
    for case in cases:
        cid=case['id'];eligible=reviewed[cid]['eligible']
        screen=[r for r in rows if r['case_id']==cid and r['fixed_gate']>=2 and r['phase']=='sparse_screen']
        extra=[r for r in rows if r['case_id']==cid and r['phase']=='adaptive_refinement']
        runs=screen+extra
        assert sorted(r['fixed_gate'] for r in screen)==grid if eligible else not runs
        assert sorted(r['fixed_gate'] for r in extra)==refinement['specifications'].get(cid,[])
        summary.append({'case_id':cid,'label':case['label'],'first_expected':case['original_expected'],
                        'eleventh_expected':case['target_expected'],'eligible':eligible,'strengths_tested':len(screen),
                        'refinement_strengths_tested':len(extra),'total_strengths_tested':len(runs),
                        'exact_short_target_answers':sum(r['clean_target_answer'] for r in runs),
                        'first_recognized_target_answers':sum(r['first_recognized_is_target'] for r in runs),
                        'any_target_mentions':sum(r['target_mentioned'] for r in runs),
                        'November_fragments':sum(r['November_marker'] for r in runs),
                        'clean_target_values':[r['fixed_gate'] for r in runs if r['clean_target_answer']],
                        'first_target_values':[r['fixed_gate'] for r in runs if r['first_recognized_is_target']]})
    assert results['month_replicates_prior_results_exactly']
    prior_path=ROOT/'comparisons/2026-10-28-water-month/remote-export/water-month-20261028/artifacts/results.json'
    prior=json.loads(prior_path.read_text());old_by_name={r['name']:r for r in prior['runs']}
    month_runs=[native_by_id['month']]+[r for r in results['gate_runs'] if r['case_id']=='month' and r['target']>=2]
    for run in month_runs:
        old=old_by_name['native' if run['target'] is None else f"fixed_{int(run['target'])}"]
        assert run['output_token_ids']==old['output_token_ids']
        for current,previous in zip(run['steps'],old['steps']):
            assert all(current[k]==previous[k] for k in ['selected_probability','selected_logit','logsumexp'])
    validation={'status':'passed','native_control_cases':len(cases),'native_generation_runs':2*len(cases),
                'exact_zero_control_runs':2*len(cases),'eligible_cases':sum(e['eligible'] for e in reviewed.values()),
                'excluded_cases':sum(not e['eligible'] for e in reviewed.values()),'strength_grid':grid,
                'sparse_steering_comparisons':sum(s['strengths_tested'] for s in summary),
                'adaptive_refinement_comparisons':len(refinement['runs']),
                'total_steering_comparisons':sum(s['total_strengths_tested'] for s in summary),'all_runs_audited':n_runs,
                'cpu_vector_files_audited':n_vectors,'sampled_vector_token_positions_audited':n_vector_positions,
                'all_processed_position_coverage_checks':n_coverage,'BF16_sampled_edits_exact':True,
                'all_native_repeats_exact':True,'all_target_repeats_exact':True,
                'eligibility_bound_to_native_answer_hashes':True,'no_steering_on_ineligible_cases':True,
                'month_calibration_matches_previous_experiment_exactly':True,'hooks_remaining':0,**errors}
    validation['independent_prior_month_condition_matches']=len(month_runs)
    for name,data in [('validation.json',validation),('controls.json',control_summary),('summary.json',summary),('responses.json',rows)]:
        (OUT/name).write_text(json.dumps(data,indent=2)+'\n')
    for name,data in [('controls.csv',control_summary),('responses.csv',rows)]:
        with (OUT/name).open('w',newline='') as f:
            wcsv=csv.DictWriter(f,fieldnames=list(data[0]),lineterminator='\n');wcsv.writeheader();wcsv.writerows(data)
    lines=['# L29–T2375 ordinal transfer battery — 28 October 2026','',
           'Native first and eleventh questions were tested and manually reviewed before any steering. Eligibility was bound to exact native-answer hashes. Failed or incomplete eleventh controls were excluded, not counted as steering failures.','',
           '## Native capability check','',
           '| Case | Native first answer | Correct eleventh answer | Native eleventh result | Eligible? |',
           '|---|---|---|---|---|']
    for c in control_summary:
        display=c['native_eleventh'] if len(c['native_eleventh'])<90 else '(truncated without the required final answer)'
        lines.append(f"| {c['label']} | {c['native_first']} | {c['eleventh_expected']} | {display} | {'yes' if c['eligible'] else 'no'} |")
    lines+=['','## Sparse fixed-gate screen','',
            'Strengths tested on each eligible first-question prompt: '+', '.join(map(str,grid))+'. After partial XI and 11 effects, an adaptive follow-up tested the previously untested Roman strengths 31–49 (excluding 40) and integer strengths 81–89. These are deterministic selected-prompt comparisons, not independent samples. Untested intervals can still hide effects.','',
            '| Case | Strengths | Exact short eleventh answers | Eleventh answer recognized first | Any target mention |',
            '|---|---:|---:|---:|---:|']
    for s in summary:
        if s['eligible']:lines.append(f"| {s['label']} | {s['total_strengths_tested']} | {s['exact_short_target_answers']} | {s['first_recognized_target_answers']} | {s['any_target_mentions']} |")
    lines+=['','An exact short target answer must terminate at EOS and contain only an accepted answer alias after formatting normalization. First-recognized and any-mention columns are weaker lexical diagnostics; they can count fragments in corrupted responses and do not establish a coherent answer switch. All candidate responses are retained below.','',
            '## All target candidates and representative failures','']
    for case in cases:
        if not reviewed[case['id']]['eligible']:continue
        lines += [f"### {case['label']}",'',f"Prompt: `{case['first_prompt']}`",'']
        runs=[r for r in rows if r['case_id']==case['id'] and r['fixed_gate']>=2]
        selected=[r for r in runs if r['clean_target_answer'] or r['first_recognized_is_target'] or r['fixed_gate'] in [2,57,90]]
        for r in selected:
            lines += [f"**Gate {r['fixed_gate']:g}** · {r['stop_reason']} · exact short target: {r['clean_target_answer']}",'','```text',r['answer'],'```','']
    lines += ['## Method and limits','',
              'The same pinned native BF16 Qwen3-4B and FP32 MOLT slice as the month study are reused. Only L29–T2375 is edited, with `(fixed_gate - current_natural_gate) * ((z @ V) @ U) * output_std` at every processed input and autoregressive output position, including special input tokens. Eager attention, TF32 off, greedy decoding, thinking disabled, maximum 64 generated tokens. Native MLP remainder is retained.','',
              f"Independent audit: {n_vectors} saved vector files covering {n_vector_positions} sampled positions. Encoder, gate, operator and BF16 edit reconstruction passed. Runtime trace coverage checked {n_coverage} processed positions. Native and target repetitions were exact; hooks removed. Month responses and selected-token statistics at all overlapping values exactly reproduce the earlier month experiment.",'',
              'The prime model control answered 11 instead of 31. The unnumbered-list control answered the tenth item, jungle, instead of the eleventh, violin. Square and triangular controls were unverified because their 64-token generations truncated before 121/66. These exclusions do not establish general model incapability at longer budgets or other prompts.','',
              'High fixed gates do not identify what a transform exclusively encodes. The operator depends on the current input. A coherent success would establish a steering effect in that condition; a sparse negative screen would not establish month specificity. No active norm-matched other-feature controls or full-layer reconstruction study was performed.','',
              'Ground truth: [prime sequence](https://oeis.org/A000040) · [Hydrogen](https://periodic-table.rsc.org/element/1) · [Sodium](https://periodic-table.rsc.org/element/11). Alphabet/list indices, positive squares and triangular numbers were independently checked locally.','',
              '[Native answers](controls.csv) · [Every steered response](responses.csv) · [Validation](validation.json)','']
    (OUT/'README.md').write_text('\n'.join(lines))
    print(json.dumps({'validation':validation,'outcomes':summary},indent=2))


if __name__=='__main__':main()
