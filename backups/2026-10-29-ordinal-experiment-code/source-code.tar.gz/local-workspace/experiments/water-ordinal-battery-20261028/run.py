"""Native-capability controls precede eligibility and any ordinal steering."""
import hashlib
import json
import platform
import re
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
import transformers

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'artifacts'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    temp.replace(path)


def normalized(text):
    return ' '.join(text.replace('**', '').replace('`', '').replace('–', '-').split()).strip(' \t\r\n.?!\"\'').casefold()


def assess(case, answer, stop_reason):
    text = normalized(answer)
    originals = {normalized(x) for x in case['original_aliases']}
    targets = {normalized(x) for x in case['target_aliases']}
    labels = list(dict.fromkeys(case['all_labels'] + case['original_aliases'] + case['target_aliases']))
    found = []
    if case['answer_type'] == 'number':
        found.extend((m.start(), m.group()) for m in re.finditer(r'(?<![A-Za-z0-9])[-+]?\d+(?![A-Za-z0-9])', answer))
        labels = [x for x in labels if not re.fullmatch(r'[-+]?\d+', x)]
    elif case['answer_type'] == 'letter':
        found.extend((m.start(), m.group()) for m in re.finditer(r'(?<![A-Za-z])[A-Z](?![A-Za-z])', answer))
        labels = []
        if len(text) == 1 and text.isalpha():
            found.append((0, text.upper()))
    for label in labels:
        pattern = r'(?<![A-Za-z0-9])' + re.escape(label) + r'(?![A-Za-z0-9])'
        found.extend((m.start(), label) for m in re.finditer(pattern, answer, re.I))
    found.sort(key=lambda x: x[0])
    first = found[0][1] if found else None
    first_norm = normalized(first) if first is not None else None
    target_mentioned = any(normalized(label) in targets for _, label in found)
    return {'normalized_answer': text, 'first_recognized_answer': first,
            'first_recognized_is_original': first_norm in originals,
            'first_recognized_is_target': first_norm in targets,
            'target_mentioned': target_mentioned,
            'clean_original_answer': stop_reason == 'eos' and text in originals,
            'clean_target_answer': stop_reason == 'eos' and text in targets,
            'literal_eleven_marker': bool(re.search(r'\b(?:11|eleven|eleventh)\b', answer, re.I)),
            'November_marker': bool(re.search(r'\bNov(?:ember)?\b', answer, re.I))}


class Battery:
    def __init__(self, model, tokenizer):
        OUT.mkdir(exist_ok=True)
        self.protocol = json.loads((ROOT / 'protocol.json').read_text())
        self.cases = json.loads((ROOT / 'cases.json').read_text())
        self.model, self.tokenizer = model, tokenizer
        manifest = json.loads((ROOT / 'weights/manifest.json').read_text())
        self.feature = manifest['features'][0]
        assert len(manifest['features']) == 1 and (self.feature['layer'], self.feature['transform']) == (29, 2375)
        assert manifest['revision'] == self.protocol['molt_revision']
        assert sha(ROOT / 'weights' / self.feature['file']) == self.feature['sha256']
        with np.load(ROOT / 'weights' / self.feature['file'], allow_pickle=False) as a:
            self.weights = {k: torch.from_numpy(a[k].copy()).float().cuda() for k in a.files}
        assert self.weights['U'].shape == (32, 2560) and self.weights['V'].shape == (2560, 32)
        assert torch.__version__ == self.protocol['runtime']['torch']
        assert transformers.__version__ == self.protocol['runtime']['transformers']
        assert not model.training and next(model.parameters()).dtype == torch.bfloat16
        assert self.hook_count() == 0
        torch.set_num_threads(4)
        torch.manual_seed(0)
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        eos = model.generation_config.eos_token_id
        self.eos = set(eos if isinstance(eos, list) else [eos])
        self.attention = [b.self_attn.forward for b in model.model.layers]
        self.started = time.monotonic()
        self.runtime = {'torch': torch.__version__, 'transformers': transformers.__version__,
                        'python': platform.python_version(), 'gpu': torch.cuda.get_device_name(),
                        'model_dtype': 'BF16', 'MOLT_dtype': 'FP32'}

    def hook_count(self):
        return sum(len(m._forward_hooks) + len(m._forward_pre_hooks) for m in self.model.modules())

    @torch.inference_mode()
    def run(self, case, prompt, name, target=None, alpha=1., audit=False):
        tok, model, w = self.tokenizer, self.model, self.weights
        chat = tok.apply_chat_template([{'role': 'user', 'content': prompt}], tokenize=False,
                                       add_generation_prompt=True, enable_thinking=False)
        prompt_ids = tok.encode(chat, add_special_tokens=False)
        state = {'step': 0, 'prefix_ids': list(prompt_ids)}
        handles, traces, vectors, scores, generated = [], [], [], [], []

        def observe(_module, inputs):
            z = (inputs[0].detach().float() - w['input_mean']) / w['input_std']
            raw = F.linear(z, w['e'].reshape(1, -1), w['bias']).squeeze(-1)
            assert torch.allclose(raw, (z*w['e']).sum(-1)+w['bias'][0], atol=3e-5, rtol=3e-5)
            gate = torch.where((raw > w['theta'][0]) & (raw > 0), raw, 0.)
            state.update(z=z, raw=raw, gate=gate, operator=(z @ w['V'] @ w['U'])*w['output_std'])

        def edit(_module, _inputs, output):
            count = len(prompt_ids) if state['step'] == 0 else 1
            assert output.shape == (1, count, 2560)
            delta = float(alpha)*(float(target)-state['gate']).unsqueeze(-1)*state['operator']
            assert torch.isfinite(delta).all()
            changed = (output.float()+delta).to(output.dtype)
            assert torch.isfinite(changed).all()
            actual = changed.float()-output.float()
            if alpha == 0.:
                assert torch.equal(changed, output)
            positions = list(range(len(prompt_ids))) if state['step'] == 0 else [len(prompt_ids)+state['step']-1]
            token_ids = prompt_ids if state['step'] == 0 else [state['prefix_ids'][-1]]
            for j, (pos, token) in enumerate(zip(positions, token_ids)):
                traces.append({'position': pos, 'phase': 'input' if state['step']==0 else 'output',
                               'token_id': token, 'token': tok.decode([token]), 'raw': float(state['raw'][0,j]),
                               'natural_gate': float(state['gate'][0,j]), 'fixed_gate': target, 'alpha': alpha,
                               'operator_norm': float(state['operator'][0,j].norm()),
                               'intended_delta_norm': float(delta[0,j].norm()),
                               'actual_delta_norm': float(actual[0,j].norm())})
            if audit and state['step'] in self.protocol['audit_vector_steps']:
                # Audit selected positions; runtime coverage above includes every position.
                js = list(range(max(0,count-3),count))
                file = f"{case['id']}--{name}--step-{state['step']}.npz"
                np.savez_compressed(OUT/file, positions=np.array([positions[j] for j in js]),
                                    z=state['z'][:,js].cpu().numpy(), raw=state['raw'][:,js].cpu().numpy(),
                                    gate=state['gate'][:,js].cpu().numpy(), operator=state['operator'][:,js].cpu().numpy(),
                                    native_mlp=output[:,js].float().cpu().numpy(), edited_mlp=changed[:,js].float().cpu().numpy(),
                                    intended_delta=delta[:,js].cpu().numpy(), actual_delta=actual[:,js].cpu().numpy())
                vectors.append({'file': file, 'sha256': sha(OUT/file), 'target': target, 'alpha': alpha})
            return changed

        block = model.model.layers[29]
        if target is not None:
            handles = [block.post_attention_layernorm.register_forward_pre_hook(observe),
                       block.mlp.register_forward_hook(edit)]
        ids = torch.tensor([prompt_ids], device='cuda')
        mask, cache, stop = torch.ones_like(ids), None, 'token_limit'
        try:
            for step in range(self.protocol['max_new_tokens']):
                assert time.monotonic()-self.started < self.protocol['max_runtime_minutes']*60
                state['step'] = step
                pred = model(input_ids=ids, attention_mask=mask, past_key_values=cache, use_cache=True)
                cache = pred.past_key_values
                logits = pred.logits[0,-1].float()
                assert torch.isfinite(logits).all()
                lp = logits.log_softmax(-1)
                greedy = int(logits.argmax())
                values, indices = lp.exp().topk(6)
                scores.append({'position': step, 'token_id': greedy, 'token': tok.decode([greedy]),
                               'selected_probability': float(lp[greedy].exp()), 'selected_logit': float(logits[greedy]),
                               'logsumexp': float(logits.logsumexp(-1)),
                               'top_tokens': [{'token_id': int(i), 'token': tok.decode([int(i)]), 'probability': float(p)}
                                              for i,p in zip(indices,values)]})
                generated.append(greedy)
                state['prefix_ids'].append(greedy)
                if greedy in self.eos:
                    stop = 'eos'
                    break
                ids = torch.tensor([[greedy]], device='cuda')
                mask = torch.cat([mask,torch.ones_like(ids)],dim=1)
            assert all(b.self_attn.forward==f for b,f in zip(model.model.layers,self.attention))
        finally:
            for h in handles:
                h.remove()
        assert self.hook_count()==0
        if target is not None:
            assert len(traces)==len(prompt_ids)+len(generated)-1
            assert [t['position'] for t in traces]==list(range(len(traces)))
        answer = tok.decode(generated,skip_special_tokens=True)
        return {'case_id':case['id'],'name':name,'prompt':prompt,'chat':chat,'prompt_token_ids':prompt_ids,
                'target':target,'alpha':alpha,'answer':answer,'output_token_ids':generated,'steps':scores,
                'trace':traces,'vectors':vectors,'stop_reason':stop,'hooks_remaining':0,
                'assessment':assess(case,answer,stop)}


def run_native_controls(model,tokenizer):
    assert not (OUT/'controls.json').exists(),'Inspect existing controls before retrying.'
    battery=Battery(model,tokenizer)
    result={'status':'running','started_at_utc':datetime.now(timezone.utc).isoformat(),
            'protocol':battery.protocol,'cases':battery.cases,'feature':battery.feature,'runtime':battery.runtime,
            'source_sha256':{n:sha(ROOT/n) for n in ['run.py','protocol.json','cases.json']},'controls':[]}
    for case in battery.cases:
        first=battery.run(case,case['first_prompt'],'native_first')
        eleventh=battery.run(case,case['eleventh_prompt'],'native_11th')
        zero=battery.run(case,case['first_prompt'],'zero_first',target=0.,alpha=0.,audit=True)
        zero11=battery.run(case,case['eleventh_prompt'],'zero_11th',target=0.,alpha=0.,audit=False)
        assert first['output_token_ids']==zero['output_token_ids'] and first['steps']==zero['steps']
        assert eleventh['output_token_ids']==zero11['output_token_ids'] and eleventh['steps']==zero11['steps']
        row={'case_id':case['id'],'first':first,'eleventh':eleventh,'zero_first':zero,'zero_11th':zero11}
        result['controls'].append(row)
        save(OUT/'controls.json',result)
        print('NATIVE_CONTROL',case['id'],json.dumps({'first':first['answer'],'eleventh':eleventh['answer'],
                                                   'first_sha256':hashlib.sha256(first['answer'].encode()).hexdigest(),
                                                   'eleventh_sha256':hashlib.sha256(eleventh['answer'].encode()).hexdigest()}),flush=True)
    result.update(status='complete',finished_at_utc=datetime.now(timezone.utc).isoformat(),hooks_remaining=battery.hook_count())
    save(OUT/'controls.json',result)
    print('NATIVE_CONTROLS_COMPLETE: steering has not started; inspect both answers for every case.',flush=True)
    return battery,result


def run_steering(battery,controls):
    assert controls['status']=='complete' and not (OUT/'results.json').exists()
    eligibility=json.loads((ROOT/'eligibility.json').read_text())
    by_id={x['case_id']:x for x in controls['controls']}
    reviewed={x['case_id']:x for x in eligibility['cases']}
    assert set(reviewed)==set(by_id)
    for cid,row in reviewed.items():
        assert row['first_answer_sha256']==hashlib.sha256(by_id[cid]['first']['answer'].encode()).hexdigest()
        assert row['eleventh_answer_sha256']==hashlib.sha256(by_id[cid]['eleventh']['answer'].encode()).hexdigest()
        assert row['eligible']==(row['first_correct'] and row['eleventh_correct'])
    previous=json.loads(Path('/workspace/water-month-20261028/artifacts/results.json').read_text())
    reference={x['name']:x for x in previous['runs']}

    def match_month(run,old):
        assert run['output_token_ids']==old['output_token_ids']
        assert [(s['selected_probability'],s['selected_logit'],s['logsumexp']) for s in run['steps']]==[(s['selected_probability'],s['selected_logit'],s['logsumexp']) for s in old['steps']]

    result={'status':'running','started_at_utc':datetime.now(timezone.utc).isoformat(),'protocol':battery.protocol,
            'eligibility':eligibility,'controls_sha256':sha(OUT/'controls.json'),'gate_runs':[],'case_repeats':[],
            'source_sha256':{n:sha(ROOT/n) for n in ['run.py','protocol.json','cases.json','eligibility.json']}}
    for case in battery.cases:
        if not reviewed[case['id']]['eligible']:
            continue
        native=by_id[case['id']]['first']
        if case['id']=='month':
            match_month(native,reference['native'])
        run=battery.run(case,case['first_prompt'],'fixed_0',target=0.,audit=True)
        result['gate_runs'].append(run)
        for k in battery.protocol['fixed_gate_values']:
            run=battery.run(case,case['first_prompt'],f'fixed_{k}',target=float(k),audit=k in [2,57,90])
            if case['id']=='month':
                match_month(run,reference[f'fixed_{k}'])
            result['gate_runs'].append(run)
            save(OUT/'results.json',result)
            print('STEERING',case['id'],k,json.dumps({'answer':run['answer'],'assessment':run['assessment']}),flush=True)
        current=[r for r in result['gate_runs'] if r['case_id']==case['id'] and r['target']>=2]
        clean=[r for r in current if r['assessment']['clean_target_answer']]
        partial=[r for r in current if r['assessment']['first_recognized_is_target']]
        candidate=min(clean or partial,key=lambda r:r['target']) if clean or partial else None
        if candidate:
            rep=battery.run(case,case['first_prompt'],'target_repeat',target=candidate['target'],audit=True)
            assert rep['output_token_ids']==candidate['output_token_ids'] and rep['steps']==candidate['steps'] and rep['trace']==candidate['trace']
            result['case_repeats'].append(rep)
        repeat=battery.run(case,case['first_prompt'],'native_repeat')
        assert repeat['output_token_ids']==native['output_token_ids'] and repeat['steps']==native['steps']
        result['case_repeats'].append(repeat)
        save(OUT/'results.json',result)
    result.update(status='complete',finished_at_utc=datetime.now(timezone.utc).isoformat(),
                  hooks_remaining=battery.hook_count(),month_replicates_prior_results_exactly=True,
                  only_edited_feature={'layer':29,'transform':2375})
    save(OUT/'results.json',result)
    print('BATTERY_COMPLETE',len(result['gate_runs']),'gate runs; hooks',result['hooks_remaining'],flush=True)
    return result
