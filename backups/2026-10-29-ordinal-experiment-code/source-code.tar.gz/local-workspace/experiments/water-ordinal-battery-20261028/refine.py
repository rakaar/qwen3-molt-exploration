"""Adaptive nearby-strength checks after partial XI/11 effects in the sparse screen."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'artifacts'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(data):
    p=OUT/'refinement.tmp'
    p.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
    p.replace(OUT/'refinement.json')


def run_refinement(battery,controls):
    assert not (OUT/'refinement.json').exists()
    parent=json.loads((OUT/'results.json').read_text());assert parent['status']=='complete'
    allowed={x['case_id'] for x in parent['eligibility']['cases'] if x['eligible']}
    grid=parent['protocol']['fixed_gate_values']
    specs={'roman':[k for k in range(31,50) if k not in grid], 'integer':list(range(81,90))}
    assert set(specs)<=allowed
    cases={x['id']:x for x in battery.cases};native={x['case_id']:x['first'] for x in controls['controls']}
    data={'status':'running','started_at_utc':datetime.now(timezone.utc).isoformat(),
          'selection':'Adaptive refinement after the sparse screen: XI in a confused gate-40 Roman response and 11 followed by repetition at integer gate 90. Check the nearby untested integer strengths; retain every result.',
          'specifications':specs,'parent_results_sha256':digest(OUT/'results.json'),
          'controls_sha256':digest(OUT/'controls.json'),'source_sha256':digest(ROOT/'refine.py'),
          'runs':[],'repeats':[]}
    for cid,values in specs.items():
        case=cases[cid]
        for k in values:
            run=battery.run(case,case['first_prompt'],f'refine_{k}',target=float(k),audit=k in [31,39,41,49,81,89])
            data['runs'].append(run);save(data)
            print('REFINEMENT',cid,k,json.dumps({'answer':run['answer'],'assessment':run['assessment']}),flush=True)
        current=[r for r in data['runs'] if r['case_id']==cid]
        clean=[r for r in current if r['assessment']['clean_target_answer']]
        partial=[r for r in current if r['assessment']['first_recognized_is_target']]
        chosen=min(clean or partial,key=lambda r:r['target']) if clean or partial else None
        if chosen:
            repeat=battery.run(case,case['first_prompt'],'refinement_target_repeat',target=chosen['target'],audit=True)
            assert repeat['output_token_ids']==chosen['output_token_ids'] and repeat['steps']==chosen['steps'] and repeat['trace']==chosen['trace']
            data['repeats'].append(repeat)
        repeated_native=battery.run(case,case['first_prompt'],'refinement_native_repeat')
        assert repeated_native['output_token_ids']==native[cid]['output_token_ids'] and repeated_native['steps']==native[cid]['steps']
        data['repeats'].append(repeated_native);save(data)
    data.update(status='complete',finished_at_utc=datetime.now(timezone.utc).isoformat(),hooks_remaining=battery.hook_count())
    save(data)
    print('REFINEMENT_COMPLETE',len(data['runs']),'additional strengths; hooks',data['hooks_remaining'],flush=True)
    return data
