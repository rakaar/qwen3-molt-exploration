"""Adaptive phrasing controls after the lowercase president prefix failed natively."""
import hashlib
import json
import runpy
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'artifacts'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save(name, d):
    p = OUT / name
    tmp = p.with_suffix('.tmp')
    tmp.write_text(json.dumps(d, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    tmp.replace(p)


def controls(model, tokenizer):
    assert not (OUT / 'president-controls.json').exists()
    base = runpy.run_path(str(ROOT / 'run.py'))
    engine = runpy.run_path(str(ROOT / 'engine.py'))['Selective'](model, tokenizer)
    president = next(c for c in engine.cases if c['id'] == 'president')
    cases = []
    for cid, template in [('president_standard_case', 'The {ordinal} president of the United States was'),
                          ('president_name_field', 'The name of the {ordinal} president of the United States is')]:
        c = dict(president); c.update(id=cid, template=template); cases.append(c)
    engine.cases = cases
    d = {'status': 'running', 'started_at_utc': datetime.now(timezone.utc).isoformat(), 'cases': cases,
         'reason': 'Adaptive capability repair after lowercase president prefix produced incorrect/descriptive initial continuations. These two templates are fixed before their outcomes; no president ablation before manual review.',
         'parent_controls_sha256': sha(OUT / 'controls.json'), 'source_sha256': sha(ROOT / 'presidents.py'), 'controls': []}
    for case in cases:
        row = {'case_id': case['id'], 'ordinals': {}}
        for ordinal in [1, 11, 12]:
            c = base['phase_case'](case, ordinal)
            prompt = c['template'].format(ordinal=engine.protocol['ordinals'][str(ordinal)])
            native = engine.run(c, prompt, f'ordinal-{ordinal}--native')
            zero = engine.run(c, prompt, f'ordinal-{ordinal}--zero', spec={'kind': 'all'}, target=0., alpha=0., audit=True)
            assert native['steps'] == zero['steps'] and native['output_token_ids'] == zero['output_token_ids']
            row['ordinals'][str(ordinal)] = {'native': native, 'zero_strength': zero,
                                            'answer_sha256': hashlib.sha256(native['answer'].encode()).hexdigest()}
            print('PRESIDENT_NATIVE', case['id'], ordinal, native['assessment']['first_recognized_answer'], flush=True)
        d['controls'].append(row); save('president-controls.json', d)
    d.update(status='complete', finished_at_utc=datetime.now(timezone.utc).isoformat(), hooks_remaining=engine.hooks())
    save('president-controls.json', d)
    return engine, d


def ablations(engine, native_controls):
    assert native_controls['status'] == 'complete' and not (OUT / 'president-results.json').exists()
    review = json.loads((ROOT / 'president-eligibility.json').read_text())
    assert review['controls_sha256'] == sha(OUT / 'president-controls.json')
    by_review = {r['case_id']: r for r in review['cases']}
    by_id = {r['case_id']: r for r in native_controls['controls']}
    for cid, r in by_review.items():
        assert r['eligible'] == all(r['correct'].values())
        assert r['answer_sha256'] == {k: by_id[cid]['ordinals'][k]['answer_sha256'] for k in ['1', '11', '12']}
    base = runpy.run_path(str(ROOT / 'run.py'))
    engine.started = time.monotonic()
    d = {'status': 'running', 'started_at_utc': datetime.now(timezone.utc).isoformat(), 'eligibility': review,
         'controls_sha256': sha(OUT / 'president-controls.json'), 'source_sha256': sha(ROOT / 'presidents.py'),
         'runs': [], 'specificity_controls': [], 'repeats': []}
    for case in engine.cases:
        cid = case['id']
        if not by_review[cid]['eligible']:
            continue
        c = base['phase_case'](case, 11)
        original = by_id[cid]['ordinals']['11']['native']
        n = len(original['prompt_token_ids'])
        specs = {'all_positions': {'kind': 'all'}, 'input_only': {'kind': 'input'},
                 'last_input_only': {'kind': 'positions', 'positions': [n-1]}, 'output_only': {'kind': 'output'}}
        for scope, spec in specs.items():
            r = engine.run(c, original['prompt'], f'ordinal-11--off-{scope}', spec=spec, target=0., audit=True)
            r['scope'], r['ordinal'] = scope, 11
            d['runs'].append(r); save('president-results.json', d)
            print('PRESIDENT_OFF', cid, scope, r['assessment']['first_recognized_answer'], flush=True)
        for ordinal in [1, 12]:
            c2 = base['phase_case'](case, ordinal)
            original2 = by_id[cid]['ordinals'][str(ordinal)]['native']
            n2 = len(original2['prompt_token_ids'])
            r = engine.run(c2, original2['prompt'], f'ordinal-{ordinal}--off-last', spec={'kind': 'positions', 'positions': [n2-1]}, target=0., audit=True)
            r['scope'], r['ordinal'] = 'last_input_only', ordinal
            d['specificity_controls'].append(r)
        all_off = next(r for r in d['runs'] if r['case_id'] == cid and r['scope'] == 'all_positions')
        for name, reference in [('native-repeat', original), ('all-off-repeat', all_off)]:
            r = engine.run(c, original['prompt'], name, spec=reference['spec'], target=reference['target'], alpha=reference['alpha'], audit=True)
            assert r['steps'] == reference['steps'] and r['trace'] == reference['trace'] and r['output_token_ids'] == reference['output_token_ids']
            r['repeats_name'] = reference['name']; d['repeats'].append(r)
        save('president-results.json', d)
    d.update(status='complete', finished_at_utc=datetime.now(timezone.utc).isoformat(), hooks_remaining=engine.hooks())
    save('president-results.json', d)
    return d
