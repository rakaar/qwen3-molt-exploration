"""Native first/11th/12th controls must pass manual review before ablation."""
import hashlib
import json
import runpy
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'artifacts'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save(p, d):
    temp = p.with_suffix('.tmp')
    temp.write_text(json.dumps(d, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    temp.replace(p)


def phase_case(case, ordinal):
    c = dict(case)
    c['original_expected'] = c['expected'][str(ordinal)]
    c['target_expected'] = c['expected']['12']
    return c


def run_controls(model, tokenizer):
    assert not (OUT / 'controls.json').exists()
    ns = runpy.run_path(str(ROOT / 'engine.py'))
    engine = ns['Selective'](model, tokenizer)
    d = {'status': 'running', 'started_at_utc': datetime.now(timezone.utc).isoformat(),
         'protocol': engine.protocol, 'cases': engine.cases, 'feature': engine.feature,
         'source_sha256': {n: sha(ROOT / n) for n in ['run.py', 'engine.py', 'protocol.json', 'cases.json', 'plan.json', 'ground-truth.json']}, 'controls': []}
    for case in engine.cases:
        row = {'case_id': case['id'], 'ordinals': {}}
        for ordinal in [1, 11, 12]:
            c = phase_case(case, ordinal)
            prompt = c['template'].format(ordinal=engine.protocol['ordinals'][str(ordinal)])
            native = engine.run(c, prompt, f'ordinal-{ordinal}--native')
            observed = engine.run(c, prompt, f'ordinal-{ordinal}--zero', spec={'kind': 'all'}, target=0., alpha=0., audit=True)
            assert native['steps'] == observed['steps'] and native['output_token_ids'] == observed['output_token_ids']
            row['ordinals'][str(ordinal)] = {'native': native, 'zero_strength': observed,
                                            'answer_sha256': hashlib.sha256(native['answer'].encode()).hexdigest()}
            print('RAW_NATIVE', case['id'], ordinal, 'first label', native['assessment']['first_recognized_answer'],
                  'expected', c['original_expected'], 'answer-prefix', json.dumps(native['answer'][:150]), flush=True)
        d['controls'].append(row)
        save(OUT / 'controls.json', d)
    d.update(status='complete', finished_at_utc=datetime.now(timezone.utc).isoformat(), hooks_remaining=engine.hooks())
    save(OUT / 'controls.json', d)
    print('RAW_CONTROLS_COMPLETE: inspect native capability before any ablation.', flush=True)
    return engine, d


def run_ablations(engine, controls):
    assert controls['status'] == 'complete' and not (OUT / 'results.json').exists()
    review = json.loads((ROOT / 'eligibility.json').read_text())
    assert review['controls_sha256'] == sha(OUT / 'controls.json')
    reviewed = {r['case_id']: r for r in review['cases']}
    by_id = {r['case_id']: r for r in controls['controls']}
    for cid, r in reviewed.items():
        assert r['eligible'] == all(r['correct'][str(k)] for k in [1, 11, 12])
        for k in ['1', '11', '12']:
            assert r['answer_sha256'][k] == by_id[cid]['ordinals'][k]['answer_sha256']
    engine.started = time.monotonic()
    d = {'status': 'running', 'started_at_utc': datetime.now(timezone.utc).isoformat(), 'eligibility': review,
         'controls_sha256': sha(OUT / 'controls.json'), 'source_sha256': sha(ROOT / 'run.py'),
         'runs': [], 'specificity_controls': [], 'repeats': [], 'masks': {}}
    for case in engine.cases:
        cid = case['id']
        if not reviewed[cid]['eligible']:
            continue
        c = phase_case(case, 11)
        original = by_id[cid]['ordinals']['11']['native']
        n = len(original['prompt_token_ids'])
        specs = {'all_positions': {'kind': 'all'}, 'input_only': {'kind': 'input'},
                 'last_input_only': {'kind': 'positions', 'positions': [n-1]}, 'output_only': {'kind': 'output'}}
        d['masks'][cid] = specs
        for scope, spec in specs.items():
            r = engine.run(c, original['prompt'], f'ordinal-11--off-{scope}', spec=spec, target=0., audit=True)
            r['scope'], r['ordinal'] = scope, 11
            d['runs'].append(r)
            print('RAW_OFF', cid, scope, r['assessment']['first_recognized_answer'], 'prefix', json.dumps(r['answer'][:120]), flush=True)
            save(OUT / 'results.json', d)
        for ordinal in [1, 12]:
            c2 = phase_case(case, ordinal)
            baseline = by_id[cid]['ordinals'][str(ordinal)]['native']
            n2 = len(baseline['prompt_token_ids'])
            r = engine.run(c2, baseline['prompt'], f'ordinal-{ordinal}--off-last', spec={'kind': 'positions', 'positions': [n2-1]}, target=0., audit=True)
            r['scope'], r['ordinal'] = 'last_input_only', ordinal
            d['specificity_controls'].append(r)
        for name, baseline in [('native-repeat', original), ('all-off-repeat', next(r for r in d['runs'] if r['case_id'] == cid and r['scope'] == 'all_positions'))]:
            r = engine.run(c, original['prompt'], name, spec=baseline['spec'], target=baseline['target'], alpha=baseline['alpha'], audit=True)
            assert r['steps'] == baseline['steps'] and r['trace'] == baseline['trace'] and r['output_token_ids'] == baseline['output_token_ids']
            r['repeats_name'] = baseline['name']
            d['repeats'].append(r)
        save(OUT / 'results.json', d)
    d.update(status='complete', finished_at_utc=datetime.now(timezone.utc).isoformat(), hooks_remaining=engine.hooks())
    save(OUT / 'results.json', d)
    print('RAW_ABLATIONS_COMPLETE', len(d['runs']), 'eligible-domain ablations', flush=True)
    return d
