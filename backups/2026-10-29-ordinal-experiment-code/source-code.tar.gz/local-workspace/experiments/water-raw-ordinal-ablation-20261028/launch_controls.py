import contextlib
import runpy
import traceback

with open('/workspace/water-raw-ordinal-ablation-20261028/controls.log', 'w', buffering=1) as raw_log:
    with contextlib.redirect_stdout(raw_log), contextlib.redirect_stderr(raw_log):
        try:
            raw_ordinal_ns = runpy.run_path('/workspace/water-raw-ordinal-ablation-20261028/run.py')
            raw_ordinal_engine, raw_ordinal_controls = raw_ordinal_ns['run_controls'](model, tokenizer)
        except BaseException:
            traceback.print_exc()
            raise
