"""Independent audit of raw-prefix capability screening and gate-zero experiments."""
import csv
import hashlib
import json
import math
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
EXPORT = ROOT / 'comparisons/2026-10-28-water-raw-ordinal-ablation/remote-export/water-raw-ordinal-ablation-20261028'
OUT = ROOT / 'results/2026-10-28-water-raw-ordinal-ablation'
PRIOR = ROOT / 'comparisons/2026-10-28-water-eleventh-ablation/remote-export/water-eleventh-ablation-20261028/artifacts/fragments.json'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def bf16(x):
    b = np.ascontiguousarray(x, dtype=np.float32).view(np.uint32)
    b = b + np.uint32(0x7fff) + ((b >> 16) & 1)
    return (b & np.uint32(0xffff0000)).view(np.float32)

def main():
    OUT.mkdir(exist_ok=True)
    primary_controls = json.loads((EXPORT / 'artifacts/controls.json').read_text())
    primary_results = json.loads((EXPORT / 'artifacts/results.json').read_text())
    president_controls = json.loads((EXPORT / 'artifacts/president-controls.json').read_text())
    president_results = json.loads((EXPORT / 'artifacts/president-results.json').read_text())
    for d in [primary_controls, primary_results, president_controls, president_results]:
        assert d['status'] == 'complete' and d['hooks_remaining'] == 0
    for name, expected in primary_controls['source_sha256'].items():
        assert sha(EXPORT / name) == expected
    assert sha(EXPORT / 'run.py') == primary_results['source_sha256']
    assert sha(EXPORT / 'presidents.py') == president_controls['source_sha256'] == president_results['source_sha256']
    assert sha(EXPORT / 'artifacts/controls.json') == president_controls['parent_controls_sha256']
    feature = primary_controls['feature']
    assert (feature['layer'], feature['transform']) == (29, 2375)
    assert sha(EXPORT / 'weights' / feature['file']) == feature['sha256']
    with np.load(EXPORT / 'weights' / feature['file'], allow_pickle=False) as a:
        w = {k: a[k].astype(np.float64) for k in a.files}
    counts = {'runs_audited': 0, 'processed_positions': 0, 'unselected_positions_bit_exact': 0,
              'sampled_vector_files': 0, 'sampled_vector_positions': 0}
    errors = {'max_encoder_absolute_error': 0., 'max_operator_relative_l2_error': 0., 'max_probability_reconstruction_error': 0.}

    def audit(r):
        counts['runs_audited'] += 1
        assert r['hooks_remaining'] == 0
        n = len(r['prompt_token_ids'])
        if r['spec'] is not None:
            assert r['target'] == 0. and r['alpha'] in [0., 1.]
            assert len(r['trace']) == n + len(r['output_token_ids']) - 1
            spec = r['spec']
            for i, t in enumerate(r['trace']):
                chosen = spec['kind'] == 'all' or spec['kind'] == ('input' if i < n else 'output') or (spec['kind'] == 'positions' and i in spec['positions'])
                assert t['position'] == i and t['selected'] == chosen and t['requested_gate'] == 0.
                assert t['token_id'] == (r['prompt_token_ids'][i] if i < n else r['output_token_ids'][i-n])
                if not chosen:
                    assert t['unselected_unchanged'] and t['actual_delta_norm'] == t['intended_delta_norm'] == 0.
                    counts['unselected_positions_bit_exact'] += 1
                counts['processed_positions'] += 1
        for s in r['steps']:
            e = abs(math.exp(s['selected_logit'] - s['logsumexp']) - s['selected_probability'])
            errors['max_probability_reconstruction_error'] = max(errors['max_probability_reconstruction_error'], e)
            assert e < 8e-6
        for v in r['vectors']:
            file = EXPORT / 'artifacts' / v['file']
            assert sha(file) == v['sha256']
            with np.load(file, allow_pickle=False) as a:
                x = {k: a[k] for k in a.files}
            for j, p in enumerate(x['positions']):
                assert x['selected'][0, j] == r['trace'][int(p)]['selected']
            assert np.all(x['fixed'] == 0.)
            raw = x['z'].astype(np.float64) @ w['e'] + w['bias'][0]
            error = float(np.max(np.abs(raw - x['raw'])))
            errors['max_encoder_absolute_error'] = max(errors['max_encoder_absolute_error'], error)
            assert np.allclose(raw, x['raw'], atol=3e-5, rtol=3e-5)
            gate = np.where((raw > w['theta'][0]) & (raw > 0), raw, 0.)
            assert np.allclose(gate, x['gate'], atol=3e-5, rtol=3e-5)
            op = (x['z'].astype(np.float64) @ w['V'] @ w['U']) * w['output_std']
            error = float(np.linalg.norm(op - x['operator']) / max(np.linalg.norm(op), 1e-12))
            errors['max_operator_relative_l2_error'] = max(errors['max_operator_relative_l2_error'], error)
            assert error < 1e-4
            delta = np.where(x['selected'][..., None], np.float32(v['alpha']) * (x['fixed'] - x['gate'])[..., None] * x['operator'], 0.)
            assert np.array_equal(delta, x['intended_delta'])
            assert np.array_equal(bf16(x['native_mlp'] + delta), x['edited_mlp'])
            assert np.array_equal(x['edited_mlp'] - x['native_mlp'], x['actual_delta'])
            assert np.array_equal(x['native_mlp'][~x['selected']], x['edited_mlp'][~x['selected']])
            counts['sampled_vector_files'] += 1
            counts['sampled_vector_positions'] += x['gate'].size

    rows, control_rows, summary, diagnostics = [], [], [], []
    datasets = [('primary', primary_controls, primary_results, 'controls.json', 'eligibility.json'),
                ('president_rephrasing', president_controls, president_results, 'president-controls.json', 'president-eligibility.json')]

    def prob(step, token):
        if str(token) in step['probe_probabilities']:
            return step['probe_probabilities'][str(token)]
        match = next((x['probability'] for x in step['top_tokens'] if x['token_id'] == token), None)
        return match

    for stage, controls, results, control_file, review_file in datasets:
        review = json.loads((EXPORT / review_file).read_text())
        assert results['eligibility'] == review
        assert sha(EXPORT / 'artifacts' / control_file) == review['controls_sha256'] == results['controls_sha256']
        reviewed = {r['case_id']: r for r in review['cases']}
        cases = {c['id']: c for c in controls['cases']}
        by_id = {r['case_id']: r for r in controls['controls']}
        for cid, row in by_id.items():
            e = reviewed[cid]
            assert e['eligible'] == all(e['correct'].values())
            native_answers, last_gates = {}, {}
            for ordinal in ['1', '11', '12']:
                pair = row['ordinals'][ordinal]
                a, b = pair['native'], pair['zero_strength']
                audit(a); audit(b)
                assert a['chat'] == a['prompt'] and b['chat'] == b['prompt']
                assert a['steps'] == b['steps'] and a['output_token_ids'] == b['output_token_ids']
                assert hashlib.sha256(a['answer'].encode()).hexdigest() == pair['answer_sha256'] == e['answer_sha256'][ordinal]
                if e['eligible']:
                    assert a['assessment']['first_recognized_answer'] == cases[cid]['expected'][ordinal]
                last = b['trace'][len(a['prompt_token_ids'])-1]
                native_answers[ordinal] = a['answer']
                last_gates[ordinal] = last['natural_gate']
            control_rows.append({'stage': stage, 'case_id': cid, 'eligible': e['eligible'], 'review_reason': e['review_reason'],
                                 'expected': cases[cid]['expected'], 'native_answers': native_answers, 'last_input_gates': last_gates,
                                 'answer_hashes': e['answer_sha256']})
            condition_rows = [r for r in results['runs'] if r['case_id'] == cid]
            if not e['eligible']:
                assert not condition_rows
            else:
                assert {r['scope'] for r in condition_rows} == {'all_positions', 'input_only', 'last_input_only', 'output_only'}
            entry = {'stage': stage, 'case_id': cid, 'label': cases[cid]['label'], 'eligible': e['eligible'],
                     'review_reason': e['review_reason'], 'expected': cases[cid]['expected'], 'last_input_gates': last_gates,
                     'scope_first_answers': {r['scope']: r['assessment']['first_recognized_answer'] for r in condition_rows},
                     'target_scopes': [r['scope'] for r in condition_rows if r['assessment']['first_matches_target']]}
            if e['eligible']:
                native = row['ordinals']['11']['native']
                off = next(r for r in condition_rows if r['scope'] == 'last_input_only')
                entry['last_input_effective_edits'] = sum(t['actual_delta_norm'] > 0 for t in off['trace'])
                assert entry['last_input_effective_edits'] in [0, 1]
                if last_gates['11'] == 0.:
                    assert off['steps'] == native['steps'] and off['output_token_ids'] == native['output_token_ids']
                    entry['last_input_is_exact_noop'] = True
                else:
                    entry['last_input_is_exact_noop'] = False
                # Conditional branch-token diagnostic, not an entire answer probability.
                twelve = row['ordinals']['12']['native']
                branch = next(i for i, (a, b) in enumerate(zip(native['output_token_ids'], twelve['output_token_ids'])) if a != b)
                prefix = native['output_token_ids'][:branch]
                record = {'case_id': cid, 'position': branch, 'same_actual_prefix_after_ablation': off['output_token_ids'][:branch] == prefix,
                          'native_eleven_branch_token': native['steps'][branch]['token'],
                          'native_twelve_branch_token': twelve['steps'][branch]['token'],
                          'meaning': 'Probability of the first differing token between actual native eleventh/twelfth completion prefixes, conditional on their shared output prefix. Not full-answer or case-summed probability.'}
                if record['same_actual_prefix_after_ablation']:
                    a, b = native['output_token_ids'][branch], twelve['output_token_ids'][branch]
                    record.update(native_P_eleven_branch=prob(native['steps'][branch], a), native_P_twelve_branch=prob(native['steps'][branch], b),
                                  off_P_eleven_branch=prob(off['steps'][branch], a), off_P_twelve_branch=prob(off['steps'][branch], b))
                diagnostics.append(record)
            summary.append(entry)
        for kind, run_list in [('eleventh_ablation', results['runs']), ('specificity_control', results['specificity_controls'])]:
            for r in run_list:
                audit(r)
                assert reviewed[r['case_id']]['eligible'] and r['chat'] == r['prompt']
                original = by_id[r['case_id']]['ordinals'][str(r['ordinal'])]['native']
                n = len(original['prompt_token_ids'])
                spec = {'all_positions': {'kind': 'all'}, 'input_only': {'kind': 'input'},
                        'last_input_only': {'kind': 'positions', 'positions': [n-1]}, 'output_only': {'kind': 'output'}}[r['scope']]
                assert r['spec'] == spec and r['prompt'] == original['prompt']
                if r['scope'] == 'output_only':
                    assert r['steps'][0] == original['steps'][0]
                if kind == 'specificity_control':
                    assert r['assessment']['first_recognized_answer'] == original['assessment']['first_recognized_answer']
                rows.append({'stage': stage, 'kind': kind, 'case_id': r['case_id'], 'ordinal': r['ordinal'], 'scope': r['scope'],
                             'prompt': r['prompt'], 'answer': r['answer'], 'stop': r['stop_reason'], **r['assessment'],
                             'effective_edited_positions': sum(t['actual_delta_norm'] > 0 for t in r['trace']),
                             'first_20_characters': r['answer'][:20]})
        for r in results['repeats']:
            audit(r)
            if r['repeats_name'] == 'ordinal-11--native':
                original = by_id[r['case_id']]['ordinals']['11']['native']
            else:
                original = next(x for x in results['runs'] if x['case_id'] == r['case_id'] and x['name'] == r['repeats_name'])
            assert r['steps'] == original['steps'] and r['trace'] == original['trace'] and r['output_token_ids'] == original['output_token_ids']
    prior = json.loads(PRIOR.read_text())
    old_native = next(r['native'] for r in prior['controls'] if r['case_id'] == 'corrected_eleventh_raw')
    old_off = next(r for r in prior['runs'] if r['case_id'] == 'corrected_eleventh_raw' and r['scope'] == 'native_active_input')
    current_native = next(r['ordinals']['11']['native'] for r in primary_controls['controls'] if r['case_id'] == 'month')
    current_off = next(r for r in primary_results['runs'] if r['case_id'] == 'month' and r['scope'] == 'last_input_only')
    for a, b in [(current_native, old_native), (current_off, old_off)]:
        n = len(a['output_token_ids'])
        assert a['output_token_ids'] == b['output_token_ids'][:n]
        assert [[s[k] for k in ['selected_probability', 'selected_logit', 'logsumexp']] for s in a['steps']] == [[s[k] for k in ['selected_probability', 'selected_logit', 'logsumexp']] for s in b['steps'][:n]]
    validation = {'status': 'passed', 'native_case_families': len(control_rows),
                  'native_ordinal_prompts': 3*len(control_rows), 'eligible_case_families': sum(r['eligible'] for r in summary),
                  'excluded_case_families': sum(not r['eligible'] for r in summary),
                  'eleventh_ablation_conditions': sum(len(r['runs']) for r in [primary_results, president_results]),
                  'first_twelfth_specificity_conditions': sum(len(r['specificity_controls']) for r in [primary_results, president_results]),
                  'all_native_zero_controls_exact': True, 'all_repeats_exact': True,
                  'no_ablations_on_failed_capability_controls': True, 'eligibility_bound_to_native_hashes': True,
                  'month_native_and_one_position_ablation_reproduce_prior_prefix_exactly': True,
                  'sampled_BF16_edits_exact': True, 'hooks_remaining': 0, **counts, **errors}
    for name, d in [('validation.json', validation), ('controls.json', control_rows), ('summary.json', summary), ('responses.json', rows), ('branch-probabilities.json', diagnostics)]:
        (OUT / name).write_text(json.dumps(d, indent=2, ensure_ascii=False) + '\n')
    with (OUT / 'responses.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]), lineterminator='\n'); writer.writeheader(); writer.writerows(rows)
    print(json.dumps({'validation': validation, 'summary': summary, 'branch_diagnostics': diagnostics}, indent=2))


if __name__ == '__main__':
    main()

