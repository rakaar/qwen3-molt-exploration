"""Summarize initial completion effects, active no-change cases and inactive no-ops."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'results/2026-10-28-water-raw-ordinal-ablation'


def main():
    summaries = json.loads((OUT / 'summary.json').read_text())
    rows = json.loads((OUT / 'responses.json').read_text())
    controls = json.loads((OUT / 'controls.json').read_text())
    validation = json.loads((OUT / 'validation.json').read_text())
    diagnostics = json.loads((OUT / 'branch-probabilities.json').read_text())
    eligible = [s for s in summaries if s['eligible']]
    scopes = ['all_positions', 'input_only', 'last_input_only', 'output_only']
    colors = ['#d8dde2', '#c1d9e9', '#299e79', '#e7bc7d']
    matrix = np.zeros((len(eligible), 4), dtype=int)
    values = []
    for i, s in enumerate(eligible):
        cells = []
        for j, scope in enumerate(scopes):
            r = next(r for r in rows if r['case_id'] == s['case_id'] and r['ordinal'] == 11 and r['scope'] == scope)
            matrix[i, j] = 0 if r['effective_edited_positions'] == 0 else (2 if r['first_matches_target'] else (1 if r['first_matches_expected'] else 3))
            cells.append(r['first_recognized_answer'] or '?')
        values.append(cells)
    gates = np.array([[s['last_input_gates'][k] for k in ['1', '11', '12']] for s in eligible])
    fig, axes = plt.subplots(1, 2, figsize=(12.5, 6), gridspec_kw={'width_ratios': [1.2, 3]})
    axes[0].imshow(gates, cmap='Blues', vmin=0, vmax=max(3, gates.max()), aspect='auto')
    axes[0].set_xticks([0, 1, 2], ['First', 'Eleventh', 'Twelfth'])
    axes[0].set_yticks(range(len(eligible)), [s['label'] for s in eligible], fontsize=9)
    axes[0].set_title('Natural gate on final input token', fontsize=11)
    for i in range(len(eligible)):
        for j in range(3):
            axes[0].text(j, i, f'{gates[i,j]:.2f}', ha='center', va='center', fontsize=9, color='white' if gates[i,j]>1.7 else '#182d3b')
    axes[1].imshow(matrix, cmap=ListedColormap(colors), vmin=0, vmax=3, aspect='auto')
    axes[1].set_xticks(range(4), ['All tokens off', 'Input only off', 'Final input off', 'Output only off'], fontsize=9)
    axes[1].set_yticks(range(len(eligible)), ['']*len(eligible))
    axes[1].set_title('Initial eleventh-answer completion after ablation', fontsize=11)
    for i, cells in enumerate(values):
        for j, value in enumerate(cells):
            axes[1].text(j, i, value, ha='center', va='center', fontsize=10, color='white' if matrix[i,j]==2 else '#152631')
    for ax in axes:
        ax.set_yticks(np.arange(-.5, len(eligible)), minor=True)
        ax.grid(which='minor', axis='y', color='white', linewidth=1)
        ax.tick_params(which='minor', length=0)
        for spine in ax.spines.values():
            spine.set_visible(False)
    fig.suptitle('L29–T2375: raw-prefix ablation transfers beyond calendar months', fontsize=14, weight='bold')
    fig.legend(handles=[Patch(color=c, label=t) for c,t in zip(colors,['No actual edit', 'Original answer; active edit', 'Twelfth answer', 'Other completion'])], loc='lower center', bbox_to_anchor=(.5,.08), ncol=4, frameon=False, fontsize=9)
    fig.text(.02,.025,'All rows passed native first/eleventh/twelfth initial-label checks. Labels normalize case; full continuations may be repetitive or incorrect.',fontsize=8.5)
    fig.tight_layout(rect=(.01,.18,1,.91),w_pad=2)
    fig.savefig(OUT/'outcomes.png',dpi=170);fig.savefig(OUT/'outcomes.svg');plt.close(fig)
    switches = [s for s in eligible if 'last_input_only' in s['target_scopes']]
    lines=['# Raw-prefix ordinal ablations — 28 October 2026','',
           '**The month finding generalizes to alphabet letters and Roman numerals in these raw completion prefixes.** Turning off L29–T2375 only at the final input token changes November → December, K → L, and XI → XII. These are initial-completion effects; long raw continuations are not generally coherent or factually reliable.','',
           '![Gate activity and completion outcomes](outcomes.png)','',
           '## Capability controls before interventions','',
           'Ten primary domains were screened with native first, eleventh and twelfth prefixes, each plus an exact zero-strength observer. All three initial labels had to pass manual review before any ablation. Eight passed. The lowercase president and ordered-list prefixes failed. Two adaptive president rephrasings were then tested; neither correctly completed the eleventh-president name, so neither was ablated.','',
           '| Family | Native first / eleventh / twelfth expected labels | Eligible? | Reason |',
           '|---|---|---|---|']
    for s in summaries:
        labels=' / '.join(s['expected'][k] for k in ['1','11','12'])
        lines.append(f"| {s['case_id']} | {labels} | {'yes' if s['eligible'] else 'no'} | {s['review_reason']} |")
    lines+=['','Initial-label correctness is separate from whole-continuation coherence. For example, the native Roman completion begins XI and later confuses the task with the English letter K. All raw continuations and exclusions are retained.','',
            'The prime, square and triangular controls now produce the correct initial eleventh/twelfth values. Their earlier chat-question exclusions do not apply automatically to these new raw-prefix prompts.','',
            '## Ablation outcomes','',
            '| Domain | Native eleventh | Expected twelfth | Gate at last input | All tokens off | Input only off | Last input only off | Output only off |',
            '|---|---|---|---:|---|---|---|---|']
    for s in eligible:
        cells=[str(s['scope_first_answers'][scope]) for scope in scopes]
        lines.append(f"| {s['label']} | {s['expected']['11']} | {s['expected']['12']} | {s['last_input_gates']['11']:.6f} | {' | '.join(cells)} |")
    lines+=['','A gray plot cell means the selected intervention made no actual local MLP edit; this is distinct from removing an active contribution without changing the first label. Integers, primes, squares and triangular numbers have zero natural gate on the final input token in their eleventh prefixes. Their final-token ablation exactly reproduces the native generation. Sodium is an active-gate case that retains its original first label after removal.','',
            'All first- and twelfth-prefix specificity controls retain their original initial labels after final-input ablation. Several twelfth-prefix gates are active; unchanged greedy output does not establish zero confidence effect.','',
            '## Successful single-position conditions','']
    for s in switches:
        c=next(c for c in controls if c['case_id']==s['case_id'])
        r=next(r for r in rows if r['case_id']==s['case_id'] and r['ordinal']==11 and r['scope']=='last_input_only')
        lines += [f"### {s['label']}",'',f"Prompt: `{r['prompt']}`",'',
                  f"Native initial label: **{s['expected']['11']}**. Gate off initial label: **{r['first_recognized_answer']}**. Natural final-token gate: {s['last_input_gates']['11']:.9f}. Only one input position is edited; generated positions receive no edit.",'',
                  '**Native continuation**','','```text',c['native_answers']['11'],'```','',
                  '**Final-input ablation continuation**','','```text',r['answer'],'```','']
    lines+=['## Conditional probability diagnostics','',
            'For each eligible domain, compare the first differing token in the actual native eleventh and twelfth initial completions. Probabilities are compared only if the ablated generation shares the preceding native output prefix. This is a conditional branch-token diagnostic, not a full-answer probability or a sum across answer spellings. Exact token strings, positions and values are in branch-probabilities.json.','',
            '| Case | Native eleventh branch token | Native twelfth branch token | Native P(twelfth branch) | Ablated P(twelfth branch) |',
            '|---|---|---|---:|---:|']
    for d in diagnostics:
        a,b=d.get('native_P_twelve_branch'),d.get('off_P_twelve_branch')
        lines.append(f"| {d['case_id']} | {repr(d['native_eleven_branch_token'])} | {repr(d['native_twelve_branch_token'])} | {f'{100*a:.6f}%' if a is not None else 'unavailable'} | {f'{100*b:.6f}%' if b is not None else 'unavailable'} |")
    lines+=['','## Method, checks and limits','',
            'Same pinned native BF16 Qwen3-4B and FP32 MOLT layer-29 slice as the previous replication. Raw text only, no chat/BOS tokens, greedy decoding, 64 generated tokens, eager attention, TF32 off, fresh cache per run. Each selected native MLP output receives `-natural_gate * ((z @ V) @ U) * output_std`, FP32 then one BF16 cast. Native MLP remainder retained; all other features remain native. No high fixed gates or trained weights.','',
            f"Independent CPU audit passed: {validation['runs_audited']} runs, {validation['sampled_vector_files']} saved vector files / {validation['sampled_vector_positions']} sampled positions, {validation['processed_positions']} processed-position checks. Encoder, gate, operator and exact BF16 edits reconstructed. Native/zero-strength controls and repeated native/all-off runs match exactly. Hooks removed. Native and one-position-ablated month completions exactly reproduce the previous experiment over the shared generated prefix.",'',
            'These selected raw-prefix results establish effects beyond month names; they do not establish a universal ordinal operation or an exclusive interpretation of the gate. The input-dependent operator and native answer margins differ across domains. No active norm-matched other-transform controls or broad paraphrase study was performed. Inactive-gate cases are no-ops, not evidence that removing an active feature failed.','',
            'Ground truth for mathematical sequences, alphabet indices and the explicit list was checked independently in ground-truth.json. Expected presidential and element names were checked against primary sources: [US Senate, Taylor as 12th president](https://www.inaugural.senate.gov/16th-inaugural-ceremonies/) and [Royal Society of Chemistry, magnesium atomic number 12](https://periodic-table.rsc.org/element/12/magnesium).','',
            '[All ablated continuations](responses.csv) · [Capability controls](controls.json) · [Conditional branch probabilities](branch-probabilities.json) · [Validation](validation.json)','']
    (OUT/'README.md').write_text('\n'.join(lines))
    print(json.dumps({'last_input_switches':[s['case_id'] for s in switches],'eligible':len(eligible),'excluded_families':len(summaries)-len(eligible)}))


if __name__=='__main__':
    main()
