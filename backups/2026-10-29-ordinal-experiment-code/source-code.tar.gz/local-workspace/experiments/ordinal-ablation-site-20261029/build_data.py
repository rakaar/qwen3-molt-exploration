"""Export only the user-authorized selected examples, with measured token gates."""
import hashlib
import codecs
import json
import re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'results/2026-10-29-ordinal-gate-ablation'
OUT.mkdir(exist_ok=True)
tokenizer_path=Path(__file__).parent/'tokenizer.json'
assert hashlib.sha256(tokenizer_path.read_bytes()).hexdigest()=='aeb13307a71acd8fe81861d94ad54ab689df773318809eed3cbe794b4492dae4'
tokenizer=json.loads(tokenizer_path.read_text())
vocab={i:s for s,i in tokenizer['model']['vocab'].items()}
added={t['id']:t['content'] for t in tokenizer['added_tokens']}
bs=list(range(33,127))+list(range(161,173))+list(range(174,256))
cs=bs.copy(); extra=0
for b in range(256):
    if b not in bs:
        bs.append(b);cs.append(256+extra);extra+=1
char_bytes={chr(c):b for b,c in zip(bs,cs)}


def display_tokens(ids):
    """Keep byte-fragment token IDs, assigning each character where UTF-8 completes."""
    decoder=codecs.getincrementaldecoder('utf-8')(errors='replace')
    result=[]
    for i,token_id in enumerate(ids):
        if token_id in added:
            text=decoder.decode(b'',final=True)+added[token_id]
            decoder=codecs.getincrementaldecoder('utf-8')(errors='replace')
        else:
            raw=bytes(char_bytes[c] for c in vocab[token_id])
            text=decoder.decode(raw,final=i==len(ids)-1)
        result.append(text)
    return result


def load(relative):
    path=ROOT/relative
    return json.loads(path.read_text()),hashlib.sha256(path.read_bytes()).hexdigest()


def row_sha(row):
    return hashlib.sha256(json.dumps(row,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()


def package(run,trace_source,word,edited=False):
    n=len(run['prompt_token_ids']);traces={t['position']:t for t in trace_source['trace']}
    def token(pos,token_id,text):
        t=traces.get(pos);selected=bool(edited and t and t['selected'])
        return {'position':pos,'token_id':token_id,'text':text,'natural_gate':t['natural_gate'] if t else None,
                'gate_after_edit':0. if selected else t['natural_gate'] if t else None,'edited':selected,
                'actual_delta_norm':t['actual_delta_norm'] if selected else 0.}
    prompt=[token(i,iid,traces[i]['token']) for i,iid in enumerate(run['prompt_token_ids'])]
    response=[token(n+i,iid,text) for i,(iid,text) in enumerate(zip(run['output_token_ids'],display_tokens(run['output_token_ids'])))]
    for i,t in enumerate(response):
        t['raw_token_text']=run['steps'][i]['token']
        t['byte_fragment']=not bool(t['text'])
    assert ''.join(t['text'] for t in prompt)==run['prompt']
    assert ''.join(t['text'] for t in response)==run['answer']
    match=re.match(r'\s*'+re.escape(word)+r'(?![A-Za-z])',run['answer'],re.I)
    assert match,(word,run['answer'][:25])
    chars=0;answer_tokens=[]
    for t in response:
        chars+=len(t['text']);answer_tokens.append(t)
        if chars>=match.end():break
    return {'prompt_text':run['prompt'],'answer_word':word,'full_response':run['answer'],'stop_reason':run['stop_reason'],
            'prompt':prompt,'response':response,'answer_token_count':len(answer_tokens),'source_record_sha256':row_sha(run)}


def example(id,title,group,native,observed,off,original,target,feature,notes,sources,adjacent):
    assert native['output_token_ids']==observed['output_token_ids'] and native['steps']==observed['steps']
    assert all(t['actual_delta_norm']==0 for t in observed['trace'])
    selected=[t for t in off['trace'] if t['selected']]
    assert len(selected)==1 and selected[0]['phase']=='input' and selected[0]['natural_gate']>0
    assert off['spec']['kind']=='positions' and off['target']==0 and off['alpha']==1
    assert all(t['actual_delta_norm']==0 for t in off['trace'] if t['phase']=='output')
    edit=selected[0]
    return {'id':id,'title':title,'group':group,'feature':feature,'original':original,'target':target,'notes':notes,
            'native':package(native,observed,original),'off':package(off,off,target,True),
            'edit':{'position':edit['position'],'token':edit['token'],'natural_gate':edit['natural_gate'],'target_gate':0.,'actual_delta_norm':edit['actual_delta_norm']},
            'native_next_ordinal_control':{'prompt_text':adjacent['prompt'],'full_response':adjacent['answer'],'source_record_sha256':row_sha(adjacent)},'source_file_sha256':sources}


base='comparisons/2026-10-28-water-raw-ordinal-ablation/remote-export/water-raw-ordinal-ablation-20261028/artifacts/'
ctl,ctlsha=load(base+'controls.json');res,ressha=load(base+'results.json')
frag,fragsha=load('comparisons/2026-10-28-water-eleventh-ablation/remote-export/water-eleventh-ablation-20261028/artifacts/fragments.json')
examples=[]
control=next(x for x in frag['controls'] if x['case_id']=='exact_elventh_raw')
off=next(x for x in frag['runs'] if x['case_id']=='exact_elventh_raw' and x['name']=='fragment-off--native_active_input')
examples.append(example('month-original','Month · original prefix','eleven',control['native'],control['zero_strength'],off,'November','December','L29–T2375',
    'The original supplied prefix spells eleventh as “elventh”. This is a second month wording, not a fourth independent task family. The native twelfth-month check uses the corrected spelling shown below.',{'fragments.json':fragsha,'corrected_controls.json':ctlsha},next(x for x in ctl['controls'] if x['case_id']=='month')['ordinals']['12']['native']))
for cid,title,original,target in [('month','Month · corrected prefix','November','December'),('alphabet','English alphabet','K','L'),('roman','Roman numerals','XI','XII')]:
    row=next(x for x in ctl['controls'] if x['case_id']==cid)
    off=next(x for x in res['runs'] if x['case_id']==cid and x['scope']=='last_input_only')
    examples.append(example(cid,title,'eleven',row['ordinals']['11']['native'],row['ordinals']['11']['zero_strength'],off,original,target,'L29–T2375',
        'The native model also gives the correct first and twelfth initial answers. Only the initial completion is claimed; longer raw continuations can contain errors.',{'controls.json':ctlsha,'results.json':ressha},row['ordinals']['12']['native']))
c4,c4sha=load('experiments/t2397-cross-domain-ablation-20261028/artifacts/controls.json');r4,r4sha=load('experiments/t2397-cross-domain-ablation-20261028/artifacts/results.json')
row=next(x for x in c4['controls'] if x['case_id']=='alphabet')
off=next(x for x in r4['runs'] if x['case_id']=='alphabet' and x['ordinal']==4 and x['scope']=='last_input_only')
examples.append(example('alphabet-four','English alphabet','four',row['ordinals']['4']['native'],row['ordinals']['4']['zero_strength'],off,'D','E','L29–T2397',
    'This is the exact lowercase “english” prefix. Capitalizing English made the native fourth-letter answer wrong in a separate check, so the effect is prompt-sensitive.',{'controls.json':c4sha,'results.json':r4sha},row['ordinals']['5']['native']))
data={'title':'Single-token input ablations and ordinal answers','model':'Qwen3-4B','layer_and_token_indices':'zero-based',
      'base_revision':'1cfa9a7208912126459214e8b04321603b3df60c','molt_revision':'081ce901b090b64aeecf9bc8709b57c10411e32a',
      'decode':'greedy','format':'raw completion prefixes; no chat template','precision':'BF16 base; FP32 MOLT contribution; one final BF16 rounding',
      'heatmap_scale':[0,3],'examples':examples,'counts':{'eleven_to_twelve_prefixes':4,'eleven_to_twelve_task_families':3,'four_to_five_prefixes':1,'two_to_three_confirmed':0},
      'display_notes':['Each gate is evaluated while processing its displayed token and can affect later predictions.','Only the outlined final input token is edited. Generated tokens remain unedited.','The edited column is deliberately neutral; neutral color does not mean every other gate was zero. Actual natural values remain available for each measured token.','The last emitted token has no recorded gate because it was not processed in a subsequent forward step. It is marked not measured, never zero.'],
      'limits':['Selected initial-completion effects, not a universal increment operation.','The two month prefixes are variants of one task family.','No confirmed 2-to-3 result. Other tested active cases sometimes retain their initial answer; inactive cases are no-ops.','Full raw continuations are often repetitive or factually wrong.','No active norm-matched unrelated-transform control or broad paraphrase validation.']}
(OUT/'data.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
validation={'examples':len(examples),'single_input_token_per_example':True,'generated_token_edits':0,'native_zero_exact':True,'unmeasured_terminal_gates_are_null':True,'examples_by_group':data['counts'],
            'data_sha256':hashlib.sha256((OUT/'data.json').read_bytes()).hexdigest()}
(OUT/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
print(json.dumps(validation,indent=2))
