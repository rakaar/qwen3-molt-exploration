"""Audit gate-zero arithmetic and distinguish raw completion from chat answers."""
import csv
import hashlib
import json
import math
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
EXPORT = ROOT / 'comparisons/2026-10-28-water-eleventh-ablation/remote-export/water-eleventh-ablation-20261028'
OUT = ROOT / 'results/2026-10-28-water-eleventh-ablation'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def bf16(x):
    b = np.ascontiguousarray(x, dtype=np.float32).view(np.uint32)
    b = b + np.uint32(0x7fff) + ((b >> 16) & 1)
    return (b & np.uint32(0xffff0000)).view(np.float32)


def main():
    OUT.mkdir(exist_ok=True)
    question = json.loads((EXPORT / 'artifacts/results.json').read_text())
    fragments = json.loads((EXPORT / 'artifacts/fragments.json').read_text())
    assert question['status'] == fragments['status'] == 'complete'
    assert question['hooks_remaining'] == fragments['hooks_remaining'] == 0
    assert fragments['parent_question_results_sha256'] == sha(EXPORT / 'artifacts/results.json')
    for d in [question, fragments]:
        for name, expected in d['source_sha256'].items():
            assert sha(EXPORT / name) == expected, name
    feature = question['feature']
    assert fragments.get('feature', feature) == feature
    assert (feature['layer'], feature['transform']) == (29, 2375)
    assert sha(EXPORT / 'weights' / feature['file']) == feature['sha256']
    with np.load(EXPORT / 'weights' / feature['file'], allow_pickle=False) as a:
        w = {k: a[k].astype(np.float64) for k in a.files}
    counts = {'runs_audited': 0, 'processed_positions': 0, 'unselected_positions_bit_exact': 0,
              'sampled_vector_files': 0, 'sampled_vector_positions': 0}
    errors = {'max_encoder_absolute_error': 0., 'max_operator_relative_l2_error': 0., 'max_probability_reconstruction_error': 0.}

    def audit(r):
        counts['runs_audited'] += 1
        assert r['hooks_remaining'] == 0
        n = len(r['prompt_token_ids'])
        if r['spec'] is not None:
            assert r['target'] == 0. and r['alpha'] in [0., 1.]
            assert len(r['trace']) == n + len(r['output_token_ids']) - 1
            spec = r['spec']
            for i, t in enumerate(r['trace']):
                chosen = spec['kind'] == 'all' or spec['kind'] == ('input' if i < n else 'output') or (spec['kind'] == 'positions' and i in spec['positions'])
                assert t['position'] == i and t['selected'] == chosen and t['requested_gate'] == 0.
                assert t['token_id'] == (r['prompt_token_ids'][i] if i < n else r['output_token_ids'][i-n])
                if not chosen:
                    assert t['unselected_unchanged'] and t['actual_delta_norm'] == t['intended_delta_norm'] == 0.
                    counts['unselected_positions_bit_exact'] += 1
                counts['processed_positions'] += 1
        for s in r['steps']:
            e = abs(math.exp(s['selected_logit'] - s['logsumexp']) - s['selected_probability'])
            errors['max_probability_reconstruction_error'] = max(errors['max_probability_reconstruction_error'], e)
            assert e < 8e-6
        for v in r['vectors']:
            file = EXPORT / 'artifacts' / v['file']
            assert sha(file) == v['sha256']
            with np.load(file, allow_pickle=False) as a:
                x = {k: a[k] for k in a.files}
            for j, p in enumerate(x['positions']):
                assert x['selected'][0, j] == r['trace'][int(p)]['selected']
            assert np.all(x['fixed'] == 0.)
            raw = x['z'].astype(np.float64) @ w['e'] + w['bias'][0]
            error = float(np.max(np.abs(raw - x['raw'])))
            errors['max_encoder_absolute_error'] = max(errors['max_encoder_absolute_error'], error)
            assert np.allclose(raw, x['raw'], atol=3e-5, rtol=3e-5)
            gate = np.where((raw > w['theta'][0]) & (raw > 0), raw, 0.)
            assert np.allclose(gate, x['gate'], atol=3e-5, rtol=3e-5)
            op = (x['z'].astype(np.float64) @ w['V'] @ w['U']) * w['output_std']
            error = float(np.linalg.norm(op - x['operator']) / max(np.linalg.norm(op), 1e-12))
            errors['max_operator_relative_l2_error'] = max(errors['max_operator_relative_l2_error'], error)
            assert error < 1e-4
            delta = np.where(x['selected'][..., None], np.float32(v['alpha']) * (x['fixed'] - x['gate'])[..., None] * x['operator'], 0.)
            assert np.array_equal(delta, x['intended_delta'])
            assert np.array_equal(bf16(x['native_mlp'] + delta), x['edited_mlp'])
            assert np.array_equal(x['edited_mlp'] - x['native_mlp'], x['actual_delta'])
            assert np.array_equal(x['native_mlp'][~x['selected']], x['edited_mlp'][~x['selected']])
            counts['sampled_vector_files'] += 1
            counts['sampled_vector_positions'] += x['gate'].size

    rows, controls = [], []
    all_data = [('questions', question), ('completion_prefixes', fragments)]
    case_metadata = {c['id']: c for c in fragments['cases']}
    for stage, data in all_data:
        native_by_id = {}
        for row in data['controls']:
            a, b = row['native'], row['zero_strength']
            audit(a); audit(b)
            assert a['steps'] == b['steps'] and a['output_token_ids'] == b['output_token_ids']
            assert row['eligible']
            native_by_id[row['case_id']] = a
            controls.append({'stage': stage, 'case_id': row['case_id'], 'prompt': a['prompt'], 'native_answer': a['answer'],
                             'stop': a['stop_reason'], 'first_month': a['assessment']['first_month_mentioned'],
                             'active_positions': row['native_active_positions'], 'aliases': row['aliases'], 'empty_scopes': row['empty_scopes']})
        if 'twelfth_knowledge_control' in data:
            audit(data['twelfth_knowledge_control'])
            assert data['twelfth_knowledge_control']['assessment']['first_month_mentioned'] == 'December'
        for r in data['runs']:
            audit(r)
            control = next(c for c in data['controls'] if c['case_id'] == r['case_id'])
            assert r['spec'] == control['specifications'][r['scope']]
            assert r['prompt'] == control['native']['prompt']
            if stage == 'completion_prefixes' and case_metadata[r['case_id']]['prompt_format'] == 'raw':
                assert r['chat'] == r['prompt']
            if r['scope'] in ['output_only', 'native_active_output']:
                assert r['steps'][0] == native_by_id[r['case_id']]['steps'][0]
            rows.append({'stage': stage, 'case_id': r['case_id'], 'scope': r['scope'], 'prompt': r['prompt'],
                         'answer': r['answer'], 'stop': r['stop_reason'], **r['assessment'],
                         'effective_input_edits': sum(t['phase'] == 'input' and t['actual_delta_norm'] > 0 for t in r['trace']),
                         'effective_output_edits': sum(t['phase'] == 'output' and t['actual_delta_norm'] > 0 for t in r['trace'])})
        for r in data['repeats']:
            audit(r)
            original = native_by_id[r['case_id']] if r['repeats_name'] in ['native', 'fragment-native'] else next(x for x in data['runs'] if x['case_id'] == r['case_id'] and x['name'] == r['repeats_name'])
            assert r['steps'] == original['steps'] and r['trace'] == original['trace'] and r['output_token_ids'] == original['output_token_ids']
    assert question['canonical_native_matches_previous_exactly']
    probabilities = []
    for row in fragments['controls']:
        if not row['case_id'].endswith('_raw'):
            continue
        native = row['native']
        off = next(r for r in fragments['runs'] if r['case_id'] == row['case_id'] and r['scope'] == 'native_active_input')
        all_off = next(r for r in fragments['runs'] if r['case_id'] == row['case_id'] and r['scope'] == 'all_positions')
        assert native['steps'][0]['token'] == ' november' and off['steps'][0]['token'] == ' december'
        assert off['steps'][0] == all_off['steps'][0]
        active_in = [t for t in row['native_active_positions'] if t['phase'] == 'input']
        assert len(active_in) == 1 and active_in[0]['position'] == 7 and active_in[0]['token'] == ' is'
        assert off['spec'] == {'kind': 'positions', 'positions': [7]}
        assert sum(t['actual_delta_norm'] > 0 for t in off['trace']) == 1
        for condition, run in [('native', native), ('only_final_is_off', off)]:
            top = {x['token']: x['probability'] for x in run['steps'][0]['top_tokens']}
            tokens = [' november', ' November', ' december', ' December']
            assert all(t in top for t in tokens)
            probabilities.append({'case_id': row['case_id'], 'prompt': native['prompt'], 'condition': condition,
                                  'greedy_first_token': run['steps'][0]['token'],
                                  'natural_gate_at_final_is': active_in[0]['natural_gate'],
                                  'P_November_two_case_variants': top[' november'] + top[' November'],
                                  'P_December_two_case_variants': top[' december'] + top[' December'],
                                  'individual_token_probabilities': {t: top[t] for t in tokens}})
    validation = {'status': 'passed', 'question_ablation_conditions': len(question['runs']),
                  'completion_prefix_ablation_conditions': len(fragments['runs']),
                  'native_prompt_variants': len(controls), 'all_zero_strength_controls_exact': True,
                  'all_native_and_all_off_repeats_exact': True, 'canonical_question_matches_previous_native_exactly': True,
                  'raw_completion_single_final_is_position_sufficient': True, 'no_generation_positions_edited_in_single_is_condition': True,
                  'sampled_BF16_edits_exact': True, 'hooks_remaining': 0, **counts, **errors}
    for name, data in [('validation.json', validation), ('responses.json', rows), ('controls.json', controls), ('next-token-probabilities.json', probabilities)]:
        (OUT / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')
    with (OUT / 'responses.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]), lineterminator='\n'); writer.writeheader(); writer.writerows(rows)
    print(json.dumps({'validation': validation, 'probabilities': probabilities}, indent=2))


if __name__ == '__main__':
    main()
