"""Private report for the reproduced raw-prefix November-to-December ablation."""
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'results/2026-10-28-water-eleventh-ablation'


def main():
    probs = json.loads((OUT / 'next-token-probabilities.json').read_text())
    controls = json.loads((OUT / 'controls.json').read_text())
    rows = json.loads((OUT / 'responses.json').read_text())
    validation = json.loads((OUT / 'validation.json').read_text())
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.8), sharey=True)
    colors = ['#477caa', '#d78c3a', '#dfe3e8']
    for ax, cid, title in zip(axes, ['exact_elventh_raw', 'corrected_eleventh_raw'], ['Exact user prefix: elventh', 'Corrected spelling: eleventh']):
        subset = [p for p in probs if p['case_id'] == cid]
        n = np.array([p['P_November_two_case_variants'] for p in subset]) * 100
        d = np.array([p['P_December_two_case_variants'] for p in subset]) * 100
        rest = 100 - n - d
        for height, bottom, color, label in [(n, np.zeros(2), colors[0], 'November'), (d, n, colors[1], 'December'), (rest, n+d, colors[2], 'Other tokens')]:
            ax.bar([0, 1], height, bottom=bottom, width=.58, color=color, label=label)
            if label != 'Other tokens':
                for i, (h, b) in enumerate(zip(height, bottom)):
                    ax.text(i, b+h/2, f'{h:.1f}%', ha='center', va='center', fontsize=11, color='white')
        ax.set_xticks([0, 1], ['Native', 'Only final “ is” gate off'])
        ax.set_ylim(0, 100)
        ax.set_title(title, fontsize=11, weight='bold')
        ax.set_axisbelow(True); ax.grid(axis='y', alpha=.18)
        for spine in ax.spines.values():
            spine.set_visible(False)
    axes[0].set_ylabel('Next-token probability (%)')
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, ncol=3, loc='lower center', bbox_to_anchor=(.5, .065), frameon=False)
    fig.suptitle('L29–T2375 ablation: November → December in raw completion', fontsize=14, weight='bold')
    fig.text(.02, .015, 'Month bars sum lowercase and initial-capital single tokens with a leading space. No generated token is forced.', fontsize=9)
    fig.tight_layout(rect=(.01, .16, 1, .91))
    fig.savefig(OUT / 'next-token-probabilities.png', dpi=170)
    fig.savefig(OUT / 'next-token-probabilities.svg')
    plt.close(fig)
    lines = ['# L29–T2375 gate-off replication — 28 October 2026', '',
             '**Reproduced for the exact raw completion prefix supplied by the user.**', '',
             '```text', 'Prompt: the elventh month of the year is', 'Native next token:     " november"',
             'Gate off at final is: " december"', '```', '',
             'The only input token on which this feature naturally activates is the final ` is`, absolute position 7 (zero-based). Its natural gate is 1.124044418334961. Subtracting just this one natural contribution, with no edits at any generated position, changes the immediate completion to December. The corrected-spelling prefix also reproduces the switch, with natural gate 1.1585536003112793.', '',
             '![Next-token probabilities](next-token-probabilities.png)', '',
             '## Exact next-token measurements', '',
             'The probability columns sum two single-token strings for each month: lowercase and initial-capital forms, each with a leading space. They are not full-sequence probabilities and do not include abbreviations, all-caps forms or later tokens.', '',
             '| Prefix | Condition | P(November variants) | P(December variants) | Greedy next token |',
             '|---|---|---:|---:|---|']
    for p in probs:
        lines.append(f"| `{p['prompt']}` | {p['condition']} | {100*p['P_November_two_case_variants']:.6f}% | {100*p['P_December_two_case_variants']:.6f}% | {repr(p['greedy_first_token'])} |")
    lines += ['', 'Individual token IDs/probabilities and the natural gate at the selected position are retained in next-token-probabilities.json and the private raw export.', '',
              '## Prompt format and controls', '',
              'The initial test used four chat questions: the eleventh month, a month-name-only instruction, numeric 11th, and the spelling elventh. Every native answer was November; a separate native twelfth-month question correctly answered December. All 30 gate-zero ablations on these question prompts still answered November.', '',
              'The user then supplied the exact completion prefix. We predeclared its raw form and chat-wrapped form, and the corresponding corrected-spelling forms. Raw input means exactly the supplied UTF-8 text, encoded without added BOS/chat tokens. Chat forms use the same user-role template as the earlier experiments, thinking disabled.', '',
              '| Prefix / format | Native first month | All-position gate off | Only active input position off | Output-only gate off |',
              '|---|---|---|---|---|']
    for c in controls:
        if c['stage'] != 'completion_prefixes':
            continue
        cid = c['case_id']
        subset = [r for r in rows if r['case_id'] == cid]
        values = [next(r['first_month_mentioned'] for r in subset if r['scope'] == scope) for scope in ['all_positions', 'native_active_input', 'output_only']]
        lines.append(f"| {cid} | {c['first_month']} | {' | '.join(values)} |")
    lines += ['',
              'For raw prompts, native-active-input and answer-predecessor-only are identical masks: only position 7 is selected. Other input positions have zero natural gate. This explains why all-position and input-only ablation have the same next-token distribution as the one-position intervention. Output-only ablation begins after the first completion token has already been emitted and leaves that first token unchanged.', '',
              '## Completion-level success and longer text', '',
              'The raw-prefix next-month switch is reproduced. Raw native generations themselves continue into repeated calendar lists and hit the 128-token budget; ablated continuations also contain incorrect later month claims. This is an initial completion effect, not evidence of a coherent EOS-terminated December answer to a chat question. Full continuations are retained below.', '']
    for cid in ['exact_elventh_raw', 'corrected_eleventh_raw']:
        c = next(c for c in controls if c['case_id'] == cid)
        r = next(r for r in rows if r['case_id'] == cid and r['scope'] == 'native_active_input')
        lines += [f'### {cid}', '', '**Native continuation**', '', '```text', c['native_answer'], '```', '',
                  '**Only final ` is` contribution removed**', '', '```text', r['answer'], '```', '']
    lines += ['## Method and validation', '',
              'Pinned native BF16 Qwen3-4B revision `1cfa9a7208912126459214e8b04321603b3df60c`; FP32 MOLT slice from `georglange/qwen3-4b-molt@081ce901b090b64aeecf9bc8709b57c10411e32a`, layer 29, transform 2375. Eager attention, TF32 off, greedy decoding, thinking disabled, 128-token budget, fresh cache for every run. Feature weights were hash-verified.', '',
              'At each selected layer-29 position, subtract `natural_gate * ((z @ V) @ U) * output_std` from the native MLP output; calculate in FP32, then cast once to BF16. The native MLP remainder and all other features remain. No negative fixed gate, amplification, forced answer tokens, or weight training. This is an estimated MOLT-contribution edit to native Qwen rather than full-MLP MOLT reconstruction.', '',
              f"Independent CPU audit passed for {validation['sampled_vector_files']} saved vector files / {validation['sampled_vector_positions']} sampled positions. Encoder, gate, low-rank operator and exact BF16 edit were reconstructed; {validation['processed_positions']} processed positions were checked, including {validation['unselected_positions_bit_exact']} unselected local outputs checked unchanged. Native/zero-strength controls and native/all-off repeats matched exactly. Hooks were removed. The canonical native question also exactly reproduced the preceding experiment.", '',
              'All 8 prompt variants passed their native November check; the native twelfth-month control passed its December check. Raw eligibility evaluates the first month completion without requiring EOS from an open-ended continuation. Scope selection used each exact native trace before ablation. Empty and duplicate masks were recorded explicitly. These are deterministic selected-prompt conditions, not independent samples or a success-rate estimate.', '',
              'This supports a causal contribution to November-vs-December prediction in these raw prefixes. It does not establish an exclusive month feature, a general ordinal operation, or generalization to other models/templates. No active norm-matched other-transform control was run.', '',
              '[Every ablated continuation](responses.csv) · [Native controls and active positions](controls.json) · [Exact probabilities](next-token-probabilities.json) · [Validation](validation.json)', '']
    (OUT / 'README.md').write_text('\n'.join(lines))
    print('Report and probability plots written.')


if __name__ == '__main__':
    main()
