"""Native controls, then gate-zero ablations of L29-T2375."""
import hashlib
import json
import runpy
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'artifacts'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(d):
    p = OUT / 'results.tmp'
    p.write_text(json.dumps(d, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    p.replace(OUT / 'results.json')


def replicate(model, tokenizer):
    assert not (OUT / 'results.json').exists(), 'Inspect saved results before repeating.'
    ns = runpy.run_path(str(ROOT / 'engine.py'))
    engine = ns['Selective'](model, tokenizer)
    protocol = engine.protocol
    d = {'status': 'running', 'started_at_utc': datetime.now(timezone.utc).isoformat(),
         'protocol': protocol, 'feature': engine.feature, 'controls': [], 'runs': [], 'repeats': [],
         'source_sha256': {n: sha(ROOT / n) for n in ['engine.py', 'run.py', 'protocol.json', 'cases.json', 'plan.json']}}
    # Native capability is verified on every variant before applying any ablation.
    for case in engine.cases:
        native = engine.run(case, case['prompt'], 'native')
        zero = engine.run(case, case['prompt'], 'zero_strength', spec={'kind': 'all'}, target=0., alpha=0., audit=True)
        assert native['output_token_ids'] == zero['output_token_ids'] and native['steps'] == zero['steps']
        eligible = native['assessment']['first_month_mentioned'] == 'November' and native['stop_reason'] == 'eos'
        row = {'case_id': case['id'], 'native': native, 'zero_strength': zero, 'eligible': eligible,
               'native_answer_sha256': hashlib.sha256(native['answer'].encode()).hexdigest()}
        d['controls'].append(row)
        save(d)
        print('NATIVE', case['id'], json.dumps(native['answer']), 'eligible', eligible, flush=True)
    case = {'id': 'twelfth_knowledge', 'original_expected': 'November', 'target_expected': 'December'}
    control = engine.run(case, 'What is the twelfth month of the year?', 'native_twelfth')
    assert control['assessment']['first_month_mentioned'] == 'December' and control['stop_reason'] == 'eos'
    d['twelfth_knowledge_control'] = control
    # Match the canonical native run to the already verified preceding experiment.
    previous = json.loads(Path('/workspace/water-selective-20261028/artifacts/results.json').read_text())
    old = next(r['eleventh'] for r in previous['controls'] if r['case_id'] == 'month')
    native = d['controls'][0]['native']
    assert native['output_token_ids'] == old['output_token_ids']
    assert [[s[k] for k in ['selected_probability', 'selected_logit', 'logsumexp']] for s in native['steps']] == [[s[k] for k in ['selected_probability', 'selected_logit', 'logsumexp']] for s in old['steps']]
    d['canonical_native_matches_previous_exactly'] = True
    save(d)
    for case in engine.cases:
        row = next(r for r in d['controls'] if r['case_id'] == case['id'])
        if not row['eligible']:
            continue
        native, observed = row['native'], row['zero_strength']
        n = len(native['prompt_token_ids'])
        active_in = [t['position'] for t in observed['trace'] if t['phase'] == 'input' and t['natural_gate'] > 0]
        active_out = [t['position'] for t in observed['trace'] if t['phase'] == 'output' and t['natural_gate'] > 0]
        month_ids = tokenizer.encode('November', add_special_tokens=False)
        assert len(month_ids) == 1
        answer_index = native['output_token_ids'].index(month_ids[0])
        end = next(t['position'] for t in observed['trace'] if t['token'] == '<|im_end|>')
        assert ''.join(t['token'] for t in observed['trace'][3:end]) == case['prompt']
        specs = {'all_positions': {'kind': 'all'}, 'input_only': {'kind': 'input'},
                 'query_only': {'kind': 'positions', 'positions': list(range(3, end))}, 'output_only': {'kind': 'output'},
                 'native_active_input': {'kind': 'positions', 'positions': active_in},
                 'native_active_output': {'kind': 'positions', 'positions': active_out},
                 'native_active_union': {'kind': 'positions', 'positions': active_in + active_out},
                 'answer_predecessor_only': {'kind': 'positions', 'positions': [n + answer_index - 1]}}
        unique, aliases, empty = {}, {}, []
        for name, spec in specs.items():
            if spec.get('positions') == []:
                empty.append(name)
                continue
            prior = next((k for k, v in unique.items() if spec == v), None)
            if prior:
                aliases[name] = prior
            else:
                unique[name] = spec
        row.update(specifications=unique, aliases=aliases, empty_scopes=empty, native_answer_token_index=answer_index,
                   native_active_positions=[{k: t[k] for k in ['position', 'phase', 'token_id', 'token', 'natural_gate']} for t in observed['trace'] if t['natural_gate'] > 0])
        for scope, spec in unique.items():
            run = engine.run(case, case['prompt'], f'off--{scope}', spec=spec, target=0., audit=True)
            run['scope'] = scope
            d['runs'].append(run)
            print('OFF', case['id'], scope, json.dumps(run['answer']), run['stop_reason'], flush=True)
            save(d)
        all_off = next(r for r in d['runs'] if r['case_id'] == case['id'] and r['scope'] == 'all_positions')
        for name, original in [('native_repeat', native), ('all_off_repeat', all_off)]:
            repeat = engine.run(case, case['prompt'], name, spec=original['spec'], target=original['target'], alpha=original['alpha'], audit=True)
            assert repeat['output_token_ids'] == original['output_token_ids'] and repeat['steps'] == original['steps'] and repeat['trace'] == original['trace']
            repeat['repeats_name'] = original['name']
            d['repeats'].append(repeat)
    d.update(status='complete', finished_at_utc=datetime.now(timezone.utc).isoformat(), hooks_remaining=engine.hooks())
    save(d)
    print('ELEVENTH_OFF_COMPLETE', len(d['runs']), 'ablation conditions; hooks', engine.hooks(), flush=True)
    return engine, d
