"""Replication using the user's exact completion prefix, supplied after pass one."""
import hashlib
import json
import runpy
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'artifacts'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(d):
    temp = OUT / 'fragments.tmp'
    temp.write_text(json.dumps(d, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    temp.replace(OUT / 'fragments.json')


def run_fragments(model, tokenizer):
    assert not (OUT / 'fragments.json').exists()
    ns = runpy.run_path(str(ROOT / 'engine_fragment.py'))
    engine = ns['Selective'](model, tokenizer)
    cases = []
    for form, prompt in [('exact_elventh', 'the elventh month of the year is'),
                         ('corrected_eleventh', 'the eleventh month of the year is')]:
        for fmt in ['raw', 'chat']:
            cases.append({'id': f'{form}_{fmt}', 'prompt': prompt, 'prompt_format': fmt,
                          'original_expected': 'November', 'target_expected': 'December'})
    d = {'status': 'running', 'started_at_utc': datetime.now(timezone.utc).isoformat(),
         'parent_question_results_sha256': sha(OUT / 'results.json'),
         'source_sha256': {n: sha(ROOT / n) for n in ['fragments.py', 'engine_fragment.py', 'protocol.json']},
         'user_supplied_exact_prefix': 'the elventh month of the year is', 'cases': cases,
         'protocol': {'gate_target': 0., 'alpha': 1., 'enable_thinking': False, 'max_new_tokens': 128,
                      'scopes': ['all_positions', 'input_only', 'output_only', 'native_active_input', 'native_active_output', 'native_active_union', 'answer_predecessor_only'],
                      'native_capability': 'Raw completion eligibility requires November as the first month mentioned; do not require EOS for an open-ended text continuation. Chat eligibility also requires an EOS-terminated native answer.',
                      'success': 'Report immediate month completion and full continuation separately. A November-to-December first-month switch under the exact prefix reproduces the lexical completion effect; coherence/EOS are additional outcomes.',
                      'scope_selection': 'Native-active masks and answer predecessor chosen from that exact variant native zero-strength trace before ablation. No output forcing; generated offsets fixed from native baseline.'},
         'controls': [], 'runs': [], 'repeats': []}
    for case in cases:
        engine.protocol['prompt_format'] = case['prompt_format']
        native = engine.run(case, case['prompt'], 'fragment-native')
        observed = engine.run(case, case['prompt'], 'fragment-zero', spec={'kind': 'all'}, target=0., alpha=0., audit=True)
        assert native['steps'] == observed['steps'] and native['output_token_ids'] == observed['output_token_ids']
        eligible = native['assessment']['first_month_mentioned'] == 'November' and (case['prompt_format'] == 'raw' or native['stop_reason'] == 'eos')
        row = {'case_id': case['id'], 'native': native, 'zero_strength': observed, 'eligible': eligible}
        d['controls'].append(row)
        print('FRAGMENT_NATIVE', case['id'], json.dumps(native['answer']), native['stop_reason'], 'eligible', eligible, flush=True)
        save(d)
    for case in cases:
        engine.protocol['prompt_format'] = case['prompt_format']
        row = next(r for r in d['controls'] if r['case_id'] == case['id'])
        if not row['eligible']:
            continue
        native, observed = row['native'], row['zero_strength']
        n = len(native['prompt_token_ids'])
        active_in = [t['position'] for t in observed['trace'] if t['phase'] == 'input' and t['natural_gate'] > 0]
        active_out = [t['position'] for t in observed['trace'] if t['phase'] == 'output' and t['natural_gate'] > 0]
        # The native month can be a leading-space token in a raw continuation.
        answer_index = next(i for i, s in enumerate(native['steps']) if s['token'].strip().casefold() == 'november')
        specs = {'all_positions': {'kind': 'all'}, 'input_only': {'kind': 'input'}, 'output_only': {'kind': 'output'},
                 'native_active_input': {'kind': 'positions', 'positions': active_in},
                 'native_active_output': {'kind': 'positions', 'positions': active_out},
                 'native_active_union': {'kind': 'positions', 'positions': active_in + active_out},
                 'answer_predecessor_only': {'kind': 'positions', 'positions': [n + answer_index - 1]}}
        unique, aliases, empty = {}, {}, []
        for name, spec in specs.items():
            if spec.get('positions') == []:
                empty.append(name)
                continue
            prior = next((k for k, v in unique.items() if v == spec), None)
            if prior:
                aliases[name] = prior
            else:
                unique[name] = spec
        row.update(specifications=unique, aliases=aliases, empty_scopes=empty, native_answer_token_index=answer_index,
                   native_active_positions=[{k: t[k] for k in ['position', 'phase', 'token', 'token_id', 'natural_gate']} for t in observed['trace'] if t['natural_gate'] > 0])
        for scope, spec in unique.items():
            run = engine.run(case, case['prompt'], f'fragment-off--{scope}', spec=spec, target=0., audit=True)
            run['scope'] = scope
            d['runs'].append(run)
            print('FRAGMENT_OFF', case['id'], scope, json.dumps(run['answer']), run['stop_reason'], flush=True)
            save(d)
        all_off = next(r for r in d['runs'] if r['case_id'] == case['id'] and r['scope'] == 'all_positions')
        for name, original in [('fragment-native-repeat', native), ('fragment-all-off-repeat', all_off)]:
            r = engine.run(case, case['prompt'], name, spec=original['spec'], target=original['target'], alpha=original['alpha'], audit=True)
            assert r['steps'] == original['steps'] and r['trace'] == original['trace'] and r['output_token_ids'] == original['output_token_ids']
            r['repeats_name'] = original['name']
            d['repeats'].append(r)
    d.update(status='complete', finished_at_utc=datetime.now(timezone.utc).isoformat(), hooks_remaining=engine.hooks())
    save(d)
    print('FRAGMENTS_COMPLETE', len(d['runs']), 'conditions', flush=True)
    return engine, d
