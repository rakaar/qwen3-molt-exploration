"""Categorical decoded-name outcomes, without treating James as a Polk probability."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'results/2026-10-28-water-president'


def main():
    rows=json.loads((OUT/'summary.json').read_text())
    plt.rcParams.update({'font.family':'DejaVu Sans','svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(2,1,figsize=(11,6.6),sharex=True)
    labels=['Washington first','Polk first (target)','Other president','No recognized president']
    colors=['#3375b4','#c16929','#796bb0','#777e82']
    for ax,variant,title in zip(axes,['original_question','name_only'],['Original question','Question + answer with only the name']):
        for r in rows:
            if r['variant']!=variant or not r['condition'].startswith('fixed_') or r['fixed_gate'] is None or r['fixed_gate']<2 or r['alpha']!=1:continue
            name=r['first_named_president'];category=0 if name=='George Washington' else 1 if name=='James K. Polk' else 3 if name is None else 2
            ax.scatter(r['fixed_gate'],category,color=colors[category],s=19,zorder=3)
        ax.set_yticks(range(4),labels,fontsize=9)
        ax.set_ylim(3.45,-.45);ax.grid(alpha=.13);ax.set_title(title,loc='left',fontsize=11,pad=8)
    axes[-1].set_xlim(1,91);axes[-1].set_xlabel('Fixed L29–T2375 gate value at all processed input/output positions')
    fig.suptitle('First US president → eleventh president?',x=.02,ha='left',fontsize=16,y=.98)
    fig.text(.02,.02,'Qwen3-4B · Greedy, thinking off · 28 October 2026\nEach point is one deterministic generation. Full outputs and explicit-eleventh native knowledge control are retained.',fontsize=8.5,color='#555')
    fig.subplots_adjust(left=.23,right=.98,top=.86,bottom=.15,hspace=.54)
    for suffix in ['png','svg']:fig.savefig(OUT/f'outcomes.{suffix}',dpi=170,facecolor='white')
    plt.close(fig)
    print('Saved outcomes.png and .svg')


if __name__=='__main__':main()
