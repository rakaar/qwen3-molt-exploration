"""Audit all-token gate replacement and report decoded president identities."""
import csv
import hashlib
import json
import math
import re
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
EXPORT = ROOT / 'comparisons/2026-10-28-water-president/remote-export/water-president-20261028'
OUT = ROOT / 'results/2026-10-28-water-president'


def bf16_round(x):
    bits = np.ascontiguousarray(x, dtype=np.float32).view(np.uint32)
    bits = bits + np.uint32(0x7FFF) + ((bits >> 16) & 1)
    return (bits & np.uint32(0xFFFF0000)).view(np.float32)


def main():
    OUT.mkdir(exist_ok=True)
    rows, baselines, counts = [], {}, {}
    n_vectors = n_vector_positions = n_trace_positions = n_runs = 0
    errors = {'max_raw_gate_absolute_error': 0., 'max_operator_relative_l2_error': 0.,
              'max_probability_reconstruction_error': 0.}
    for variant, folder in [('original_question', EXPORT), ('name_only', EXPORT / 'name-only'),
                            ('eleventh_knowledge_control', EXPORT / 'ordinal-control')]:
        data = json.loads((folder / 'artifacts/results.json').read_text())
        assert data['status'] == 'complete' and data['hooks_remaining'] == 0
        assert data['only_edited_feature'] == {'layer': 29, 'transform': 2375}
        for name, expected in data['source_sha256'].items():
            assert hashlib.sha256((folder / name).read_bytes()).hexdigest() == expected
        file = folder / 'weights' / data['feature']['file']
        assert hashlib.sha256(file.read_bytes()).hexdigest() == data['feature']['sha256']
        with np.load(file, allow_pickle=False) as a:
            w = {k: a[k].astype(np.float64) for k in a.files}
        by_name = {r['name']: r for r in data['runs']}
        native, zero, repeat = [by_name[n] for n in ['native', 'zero_control', 'native_repeat']]
        assert native['steps'] == zero['steps'] == repeat['steps']
        assert native['output_token_ids'] == zero['output_token_ids'] == repeat['output_token_ids']
        assert native['first_named_president'] == data['protocol']['expected_native_president']
        baselines[variant] = {'prompt': data['protocol']['prompt'], 'answer': native['answer'],
                             'first_named_president': native['first_named_president'],
                             'stop_reason': native['stop_reason']}
        name_slot = next((i for i, s in enumerate(native['steps']) if 'George' in s['token']), None)
        for run in data['runs']:
            n_runs += 1
            assert run['hooks_remaining'] == 0
            if run['fixed_gate'] is not None:
                expected_count = len(data['prompt_token_ids']) + len(run['output_token_ids']) - 1
                assert len(run['trace']) == expected_count
                assert [x['position'] for x in run['trace']] == list(range(expected_count))
                for t in run['trace']:
                    if t['phase'] == 'input':
                        assert t['token_id'] == data['prompt_token_ids'][t['position']]
                    else:
                        assert t['token_id'] == run['output_token_ids'][t['position']-len(data['prompt_token_ids'])]
                    assert t['fixed_gate'] == run['fixed_gate'] and t['alpha'] == run['alpha']
                n_trace_positions += expected_count
            for step in run['steps']:
                discrepancies = [abs(math.exp(step['selected_logit']-step['logsumexp'])-step['selected_probability'])]
                for prefix in ['George', 'James']:
                    p = sum(math.exp(x-step['logsumexp']) for x in step['name_prefix_logits'][prefix])
                    discrepancies.append(abs(p-step['name_prefix_probability_mass'][prefix]))
                assert max(discrepancies) < 8e-6
                errors['max_probability_reconstruction_error'] = max(errors['max_probability_reconstruction_error'], *discrepancies)
            for v in run['vectors']:
                path = folder / 'artifacts' / v['file']
                assert hashlib.sha256(path.read_bytes()).hexdigest() == v['sha256']
                with np.load(path, allow_pickle=False) as a:
                    x = {k: a[k] for k in a.files}
                raw = x['z'].astype(np.float64) @ w['e'] + w['bias'][0]
                error = float(np.max(np.abs(raw-x['raw'])))
                errors['max_raw_gate_absolute_error'] = max(errors['max_raw_gate_absolute_error'], error)
                assert np.allclose(raw, x['raw'], atol=3e-5, rtol=3e-5)
                gate = np.where((raw > w['theta'][0]) & (raw > 0), raw, 0.)
                assert np.allclose(gate, x['gate'], atol=3e-5, rtol=3e-5)
                operator = (x['z'].astype(np.float64) @ w['V'] @ w['U']) * w['output_std']
                error = float(np.linalg.norm(operator-x['operator'])/max(np.linalg.norm(operator),1e-12))
                errors['max_operator_relative_l2_error'] = max(errors['max_operator_relative_l2_error'], error)
                assert error < 1e-4
                delta = np.float32(v['alpha']) * (np.float32(v['target'])-x['gate'])[...,None] * x['operator']
                assert np.array_equal(delta, x['intended_delta'])
                assert np.array_equal(bf16_round(x['native_mlp']+delta), x['edited_mlp'])
                assert np.array_equal(x['edited_mlp']-x['native_mlp'],x['actual_delta'])
                n_vectors += 1
                n_vector_positions += x['gate'].size
            common = name_slot is not None and len(run['steps']) > name_slot and run['output_token_ids'][:name_slot] == native['output_token_ids'][:name_slot]
            masses = run['steps'][name_slot]['name_prefix_probability_mass'] if common else None
            rows.append({'variant': variant, 'prompt': data['protocol']['prompt'], 'condition': run['name'],
                         'fixed_gate': run['fixed_gate'], 'alpha': run['alpha'], 'answer': run['answer'],
                         'stop_reason': run['stop_reason'], 'first_named_president': run['first_named_president'],
                         'Polk_mentioned': run['Polk_mentioned'], 'clean_Polk_answer': run['clean_Polk_answer'],
                         'eleven_marker_present': run['eleven_marker_present'], 'November_present': run['November_present'],
                         'same_native_prefix_at_name_slot': common,
                         'P_George_prefix_at_same_native_prefix': masses['George'] if common else None,
                         'P_James_prefix_at_same_native_prefix': masses['James'] if common else None})
        sweep = [r for r in rows if r['variant'] == variant and r['condition'].startswith('fixed_')
                 and r['fixed_gate'] is not None and r['fixed_gate'] >= 2 and r['alpha'] == 1]
        expected_values = [] if variant == 'eleventh_knowledge_control' else list(range(2,91))
        assert sorted(r['fixed_gate'] for r in sweep) == expected_values
        if 'first_Polk_success_repeat' in by_name:
            repeated = by_name['first_Polk_success_repeat']
            original = by_name[f"fixed_{int(repeated['fixed_gate'])}"]
            assert original['output_token_ids'] == repeated['output_token_ids']
            assert original['steps'] == repeated['steps'] and original['trace'] == repeated['trace']
        if sweep:
            counts[variant] = {'tested_strengths': len(sweep),
                               'Washington_first': sum(r['first_named_president']=='George Washington' for r in sweep),
                               'Polk_first': sum(r['first_named_president']=='James K. Polk' for r in sweep),
                               'other_named_president_first': sum(r['first_named_president'] not in [None,'George Washington','James K. Polk'] for r in sweep),
                               'no_recognized_president': sum(r['first_named_president'] is None for r in sweep),
                               'Polk_mentioned_anywhere': sum(r['Polk_mentioned'] for r in sweep),
                               'clean_Polk_answers': sum(r['clean_Polk_answer'] for r in sweep),
                               'eleven_markers': sum(r['eleven_marker_present'] for r in sweep),
                               'November_mentions': sum(r['November_present'] for r in sweep)}
    validation = {'status': 'passed', 'runs_audited': n_runs, 'sweep_prompt_formats': 2,
                  'integer_strengths_per_format': 89, 'total_intervention_comparisons': 178,
                  'cpu_vector_files_audited': n_vectors, 'saved_vector_token_positions_audited': n_vector_positions,
                  'processed_position_coverage_checks': n_trace_positions, 'zero_controls_exact': True,
                  'native_repeats_exact': True, 'BF16_edits_exact': True, 'hooks_remaining': 0,
                  'only_edited_feature': {'layer':29,'transform':2375}, **errors}
    for name, data in [('validation.json',validation),('summary.json',rows),('outcomes.json',{'counts':counts,'baselines':baselines})]:
        (OUT/name).write_text(json.dumps(data,indent=2)+'\n')
    with (OUT/'sweep.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');writer.writeheader();writer.writerows(rows)
    total_polk_first=sum(c['Polk_first'] for c in counts.values())
    total_polk_any=sum(c['Polk_mentioned_anywhere'] for c in counts.values())
    lead=(f'No Washington-to-Polk answer switch was found in the 178 fixed-gate comparisons. '
          f'Polk was mentioned anywhere in {total_polk_any} responses. The native explicit-eleventh control correctly names Polk. '
          'This result is limited to these two question formats and strengths 2–90.' if total_polk_first==0 else
          f'Polk is the first named president in {total_polk_first} of 178 fixed-gate comparisons. '
          'Complete outputs and clean-answer classifications below distinguish identity changes from degraded continuations.')
    lines=['# L29–T2375: first versus eleventh US president — 28 October 2026','',lead,'',
           'Same pinned Qwen3-4B/MOLT and all-token fixed gate replacement as the January/November experiment. Only L29–T2375 was manipulated. Thinking disabled, greedy decoding, maximum 64 generated tokens. Each of two fixed prompt formats was tested at every integer gate from 2 through 90.','',
           'At every processed input and output token, subtract the estimated current natural contribution and add the fixed-gate contribution: `(fixed_gate - natural_gate) * ((z @ V) @ U) * output_std`. FP32 edit, BF16 cast once, native remainder retained. Every chat-template input token and every processed autoregressive token is included.','',
           '## Native knowledge controls','']
    for label,base in baselines.items():
        lines += [f"- {label}: `{base['prompt']}` → first named president **{base['first_named_president']}**."]
    lines += ['', '## Outcomes across the 89 strengths per question format','',
              '| Format | Washington first | Polk first | Other president first | No recognized president | Polk anywhere | Clean Polk answer |',
              '|---|---:|---:|---:|---:|---:|---:|']
    for variant,c in counts.items():
        lines.append(f"| {variant} | {c['Washington_first']} | {c['Polk_first']} | {c['other_named_president_first']} | {c['no_recognized_president']} | {c['Polk_mentioned_anywhere']} | {c['clean_Polk_answers']} |")
    lines += ['', 'The target is James K. Polk, the eleventh president. A later mention of Polk after an initial Washington answer is not an identity switch. Eleven/eleventh/11 markers, November text and unrecognized names are recorded separately. Full outputs, including failed and truncated generations, are retained. Clean-answer classification is deliberately restricted to complete exact-name or simple complete-sentence answers after Markdown normalization; positive cases require manual review.','',
              '## Representative full outputs','']
    for variant in counts:
        lines += [f'### {variant}','']
        for condition in ['native','fixed_2','fixed_30','fixed_57','fixed_90']:
            r=next(x for x in rows if x['variant']==variant and x['condition']==condition)
            lines += [f"**{condition}** · stop: {r['stop_reason']} · first president: {r['first_named_president']}",'','```text',r['answer'],'```','']
    lines += ['## Verification and interpretation limits','',
              f"Independent CPU audit: {n_vectors} saved vector files ({n_vector_positions} token positions), exact BF16 edit reconstruction, {n_trace_positions} coverage checks, exact zero controls and native repeats. All hooks removed.",'',
              'George/James probabilities in the CSV are single-token prefix masses at an identical native prefix, when that prefix is shared. P(James) is not the probability of James K. Polk; James Madison and James Monroe share the first name. Decoded full names determine the reported outcome.','',
              'This is a selected feature, two prompt formats and the tested strength range. A negative transfer result would not establish that the feature only affects months. No other-feature norm-matched controls or full-layer reconstruction study was run. Native baseline ancillary claims are also fallible: its April 15 inauguration date is wrong (Washington was inaugurated April 30, 1789). Names were the predefined outcome here.','',
              'Historical references: [Washington inauguration](https://www.inaugural.senate.gov/1st-inaugural-ceremonies/) · [Polk as eleventh president](https://www.inaugural.senate.gov/15th-inaugural-ceremonies/).','',
              '[All exact responses](sweep.csv) · [Validation](validation.json) · [Outcome figure](outcomes.png)','']
    (OUT/'README.md').write_text('\n'.join(lines))
    print(json.dumps({'validation':validation,'counts':counts},indent=2))


if __name__=='__main__':main()
