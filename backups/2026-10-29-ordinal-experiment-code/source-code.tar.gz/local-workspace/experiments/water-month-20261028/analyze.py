"""Independent CPU audit of the fixed-gate sweep and deterministic repetitions."""
import csv
import hashlib
import json
import math
import re
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
EXPORT = ROOT / 'comparisons/2026-10-28-water-month/remote-export/water-month-20261028'
OUT = ROOT / 'results/2026-10-28-water-month'


def bf16_round(x):
    words = np.ascontiguousarray(x, dtype=np.float32).view(np.uint32)
    rounded = words + np.uint32(0x7FFF) + ((words >> 16) & 1)
    return (rounded & np.uint32(0xFFFF0000)).view(np.float32)


def main():
    OUT.mkdir(exist_ok=True)
    main_data = json.loads((EXPORT / 'artifacts/results.json').read_text())
    repeated = json.loads((EXPORT / 'repeat/artifacts/results.json').read_text())
    assert main_data['status'] == repeated['status'] == 'complete'
    assert main_data['only_edited_feature'] == repeated['only_edited_feature'] == {'layer': 29, 'transform': 2375}
    assert main_data['protocol']['fixed_gate_values'] == list(range(2, 91))
    assert repeated['protocol']['fixed_gate_values'] == [56, 57]
    vector_count = position_count = processed_edited_positions = 0
    errors = {'max_gate_score_absolute_error': 0., 'max_operator_relative_l2_error': 0.,
              'max_probability_reconstruction_error': 0.}
    for folder, data in [(EXPORT, main_data), (EXPORT / 'repeat', repeated)]:
        for name, expected in data['source_sha256'].items():
            assert hashlib.sha256((folder / name).read_bytes()).hexdigest() == expected
        feature = data['feature']
        file = folder / 'weights' / feature['file']
        assert hashlib.sha256(file.read_bytes()).hexdigest() == feature['sha256']
        assert feature['whole_checkpoint_lfs_sha256'] == '3b89660603200ca2f9eabd898f144eacc14c4e183bc148681e414b5f35db7581'
        with np.load(file, allow_pickle=False) as arrays:
            weights = {k: arrays[k].astype(np.float64) for k in arrays.files}
        native = next(r for r in data['runs'] if r['name'] == 'native')
        zero = next(r for r in data['runs'] if r['name'] == 'zero_control')
        assert native['steps'] == zero['steps'] and native['output_token_ids'] == zero['output_token_ids']
        assert native['first_month_mentioned'] == 'january'
        for run in data['runs']:
            assert run['hooks_remaining'] == 0
            if run['fixed_gate'] is not None:
                count = len(data['prompt_token_ids']) + len(run['output_token_ids']) - 1
                assert len(run['trace']) == count
                assert [t['position'] for t in run['trace']] == list(range(count))
                for t in run['trace']:
                    if t['phase'] == 'input':
                        assert t['token_id'] == data['prompt_token_ids'][t['position']]
                    else:
                        j = t['position'] - len(data['prompt_token_ids'])
                        assert t['token_id'] == run['output_token_ids'][j]
                    assert t['fixed_gate'] == run['fixed_gate'] and t['alpha'] == run['alpha']
                processed_edited_positions += count
            for step in run['steps']:
                checks = [abs(math.exp(step['selected_logit'] - step['logsumexp']) - step['selected_probability'])]
                for month in ['January', 'November']:
                    mass = sum(math.exp(x-step['logsumexp']) for x in step['target_month_logits'][month])
                    checks.append(abs(mass-step['month_probability_mass'][month]))
                errors['max_probability_reconstruction_error'] = max(errors['max_probability_reconstruction_error'], *checks)
                assert max(checks) < 8e-6
            for vector in run['vectors']:
                path = folder / 'artifacts' / vector['file']
                assert hashlib.sha256(path.read_bytes()).hexdigest() == vector['sha256']
                with np.load(path, allow_pickle=False) as arrays:
                    x = {k: arrays[k] for k in arrays.files}
                raw = x['z'].astype(np.float64) @ weights['e'] + weights['bias'][0]
                error = float(np.max(np.abs(raw - x['raw'])))
                errors['max_gate_score_absolute_error'] = max(errors['max_gate_score_absolute_error'], error)
                assert np.allclose(raw, x['raw'], atol=3e-5, rtol=3e-5)
                gate = np.where((raw > weights['theta'][0]) & (raw > 0), raw, 0.)
                assert np.allclose(gate, x['gate'], atol=3e-5, rtol=3e-5)
                operator = (x['z'].astype(np.float64) @ weights['V'] @ weights['U']) * weights['output_std']
                error = float(np.linalg.norm(operator-x['operator']) / max(np.linalg.norm(operator), 1e-12))
                errors['max_operator_relative_l2_error'] = max(errors['max_operator_relative_l2_error'], error)
                assert error < 1e-4
                delta = np.float32(vector['alpha']) * (np.float32(vector['target']) - x['gate'])[..., None] * x['operator']
                assert np.array_equal(delta, x['intended_delta'])
                assert np.array_equal(bf16_round(x['native_mlp'] + delta), x['edited_mlp'])
                assert np.array_equal(x['edited_mlp']-x['native_mlp'], x['actual_delta'])
                vector_count += 1
                position_count += x['gate'].size
    by_name = {r['name']: r for r in main_data['runs']}
    for run in repeated['runs']:
        previous = by_name[run['name']]
        assert previous['output_token_ids'] == run['output_token_ids']
        assert previous['steps'] == run['steps'] and previous['trace'] == run['trace']
    native = by_name['native']
    slot = next(i for i, s in enumerate(native['steps']) if 'January' in s['token'])
    prefix = ''.join(s['token'] for s in native['steps'][:slot])
    rows = []
    for run in main_data['runs']:
        same_prefix = run['output_token_ids'][:slot] == native['output_token_ids'][:slot]
        scores = run['steps'][slot]['month_probability_mass'] if same_prefix and len(run['steps']) > slot else None
        normalized = ' '.join(run['answer'].replace('**', '').lower().split())
        clean = bool(re.fullmatch(r'(?:november|the first month of the year is november)[.!]?', normalized))
        rows.append({'name': run['name'], 'fixed_gate': run['fixed_gate'], 'alpha': run['alpha'],
                     'answer': run['answer'], 'stop_reason': run['stop_reason'],
                     'first_month_mentioned': run['first_month_mentioned'],
                     'clean_November_answer_after_markdown_normalization': clean,
                     'same_native_prefix_at_month_slot': same_prefix,
                     'month_prefix': prefix if same_prefix else None,
                     'p_January_at_same_prefix': scores['January'] if scores else None,
                     'p_November_at_same_prefix': scores['November'] if scores else None,
                     'natural_active_positions': sum(t['natural_gate'] > 0 for t in run['trace']),
                     'actual_nonzero_edit_positions': sum(t['actual_delta_norm'] > 0 for t in run['trace'])})
    sweep = [r for r in rows if r['fixed_gate'] is not None and r['fixed_gate'] >= 2 and r['alpha'] == 1]
    assert len(sweep) == 89
    november = [r['fixed_gate'] for r in sweep if r['first_month_mentioned'] == 'november']
    assert november == list(range(57, 91))
    assert all(r['first_month_mentioned'] == 'january' for r in sweep if r['fixed_gate'] < 57)
    validation = {'status': 'passed', 'primary_runs': len(main_data['runs']), 'repetition_runs': len(repeated['runs']),
                  'integer_gates_tested': 89, 'cpu_vector_files_audited': vector_count,
                  'saved_vector_token_positions_audited': position_count,
                  'processed_position_coverage_checks': processed_edited_positions,
                  'zero_controls_exact': True, 'native_repeat_exact': True,
                  'gate_56_57_tokens_scores_traces_repeat_exact': True, 'BF16_edits_exact': True,
                  'only_edited_feature': {'layer': 29, 'transform': 2375}, 'hooks_remaining': 0,
                  'lowest_tested_integer_with_November_first': 57,
                  'November_first_integer_values': november,
                  'clean_November_responses_after_markdown_normalization': sum(r['clean_November_answer_after_markdown_normalization'] for r in sweep),
                  **errors}
    (OUT / 'validation.json').write_text(json.dumps(validation, indent=2)+'\n')
    (OUT / 'summary.json').write_text(json.dumps(rows, indent=2)+'\n')
    with (OUT / 'sweep.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator='\n')
        writer.writeheader();writer.writerows(rows)
    lines = ['# L29–T2375: first month → November — 28 October 2026', '',
             'The described January-to-November shift in the first stated month was reproduced with fixed gate 57, applied at every processed input and autoregressive output token. The generated continuation is degraded, hallucinates a calendar, attempts self-correction and reaches the 64-token limit. This is not a clean, coherent one-word November answer.', '',
             '## Feature evidence', '',
             'The live activation dashboard labels L29–T2375 High-Activation "Water" Token (rank 32). It also shows gate 1.375 on punctuation immediately preceding 11 in two numbered-list examples, and gate 3.063 on the comma immediately before November in a month list. Saved source examples and token positions are retained in the private evidence folder. The label is a gate-activation hypothesis, not a causal output description.', '',
             '## Protocol', '', 'Prompt: `' + main_data['protocol']['prompt'] + '`.', '',
             'Same pinned native Qwen3-4B and MOLT checkpoint as the CH work. Native weights BF16; gate/operator FP32; TF32 off; eager attention; thinking disabled; greedy decoding; maximum 64 generated tokens. Test every integer from 2 to 90, with an unhooked baseline, exact zero-strength control and fixed-zero gate control.', '',
             'At layer 29, edit the native MLP output by `(fixed_gate - natural_gate) * ((z @ V) @ U) * output_std` for every processed position, including special/chat-template input tokens and every decoded prefix token. The natural gate and operator are recomputed from the current residual. This replaces the estimated gate contribution while retaining the native remainder; it is not additive multiplication of the existing gate. The final emitted token is not processed again after EOS or the token limit, because no further prediction is requested.', '',
             '## Transition at an identical native prefix', '', 'Common prefix: `' + prefix + '`.', '',
             '| Condition | January % | November % | First stated month | Stop |', '|---|---:|---:|---|---|']
    for name in ['native', 'fixed_30', 'fixed_55', 'fixed_56', 'fixed_57', 'fixed_58', 'fixed_60']:
        r = next(x for x in rows if x['name'] == name)
        lines.append(f"| {name} | {100*r['p_January_at_same_prefix']:.6f} | {100*r['p_November_at_same_prefix']:.6f} | {r['first_month_mentioned']} | {r['stop_reason']} |")
    lines += ['', 'Native response:', '', '> ' + native['answer'], '', 'Fixed gate 57, complete recorded response:', '', '```text', by_name['fixed_57']['answer'], '```', '',
              'Values 2–56 retain January as the first month mentioned; 57–90 mention November first. All November-first runs hit the 64-token limit. Stronger values produce increasingly garbled continuations. The transition was repeated exactly, including tokens, recorded probabilities and intervention traces.', '',
              '57 is the lowest successful integer tested for the first-mentioned-month criterion on this prompt, not a global minimum over continuous strengths or prompts. No coherent clean November answer was found after removing Markdown formatting. The friend’s exact original prompt and implementation were not supplied; this reproduces the described procedure with all choices recorded.', '',
              f"Validation: {vector_count} vector files independently reconstructed on CPU, including the gate-57 month-decision step in the repetition. All BF16 edits and all processed-position coverage checks passed. Hooks removed.", '',
              '[All responses and probabilities](sweep.csv) · [Validation](validation.json) · [Probability plot](month-probabilities.png)', '']
    (OUT / 'README.md').write_text('\n'.join(lines))
    print(json.dumps(validation, indent=2))


if __name__ == '__main__':
    main()
