"""Fixed scalar gate replacement at every processed prompt and generation token."""
import hashlib
import json
import platform
import re
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
import transformers

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'artifacts'
MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August',
          'September', 'October', 'November', 'December']


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    temp.replace(path)


def run_experiment(model, tokenizer):
    OUT.mkdir(exist_ok=True)
    assert not (OUT / 'results.json').exists(), 'Inspect an earlier run before retrying.'
    protocol = json.loads((ROOT / 'protocol.json').read_text())
    manifest = json.loads((ROOT / 'weights/manifest.json').read_text())
    feature = manifest['features'][0]
    assert len(manifest['features']) == 1 and (feature['layer'], feature['transform']) == (29, 2375)
    assert manifest['revision'] == protocol['molt_revision']
    assert sha(ROOT / 'weights' / feature['file']) == feature['sha256']
    with np.load(ROOT / 'weights' / feature['file'], allow_pickle=False) as arrays:
        weights = {k: torch.from_numpy(arrays[k].copy()).float().cuda() for k in arrays.files}
    assert weights['U'].shape == (32, 2560) and weights['V'].shape == (2560, 32)
    assert all(torch.isfinite(x).all() for x in weights.values())
    assert torch.__version__ == protocol['runtime']['torch']
    assert transformers.__version__ == protocol['runtime']['transformers']
    assert not model.training and next(model.parameters()).dtype == torch.bfloat16
    assert sum(len(m._forward_hooks) + len(m._forward_pre_hooks) for m in model.modules()) == 0
    torch.set_num_threads(4)
    torch.manual_seed(0)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    chat = tokenizer.apply_chat_template([{'role': 'user', 'content': protocol['prompt']}],
                                         tokenize=False, add_generation_prompt=True, enable_thinking=False)
    prompt_ids = tokenizer.encode(chat, add_special_tokens=False)
    month_ids = {}
    for month in MONTHS:
        variants = [tokenizer.encode(x, add_special_tokens=False) for x in [month, ' ' + month]]
        assert all(len(x) == 1 for x in variants), (month, variants)
        month_ids[month] = sorted({x[0] for x in variants})
    eos = model.generation_config.eos_token_id
    eos = set(eos if isinstance(eos, list) else [eos])
    block = model.model.layers[29]
    attention_functions = [b.self_attn.forward for b in model.model.layers]
    started = time.monotonic()
    result = {'status': 'running', 'started_at_utc': datetime.now(timezone.utc).isoformat(),
              'protocol': protocol, 'feature': feature, 'chat': chat, 'prompt_token_ids': prompt_ids,
              'prompt_tokens': [tokenizer.decode([i]) for i in prompt_ids], 'month_token_ids': month_ids,
              'source_sha256': {'run.py': sha(ROOT / 'run.py'), 'protocol.json': sha(ROOT / 'protocol.json')},
              'runtime': {'torch': torch.__version__, 'transformers': transformers.__version__,
                          'python': platform.python_version(), 'gpu': torch.cuda.get_device_name(),
                          'native_dtype': 'BF16', 'molt_dtype': 'FP32'}, 'runs': []}

    def deadline():
        assert time.monotonic() - started < protocol['max_runtime_minutes'] * 60

    @torch.inference_mode()
    def run(name, target=None, alpha=1., audit=False):
        deadline()
        state = {'step': 0, 'prefix_ids': list(prompt_ids)}
        handles, trace, vectors, scores, generated = [], [], [], [], []

        def observe(_module, inputs):
            residual = inputs[0].detach().float()
            z = (residual - weights['input_mean']) / weights['input_std']
            raw = F.linear(z, weights['e'].reshape(1, -1), weights['bias']).squeeze(-1)
            independent = (z * weights['e']).sum(-1) + weights['bias'][0]
            assert torch.allclose(raw, independent, atol=3e-5, rtol=3e-5)
            gate = torch.where((raw > weights['theta'][0]) & (raw > 0), raw, 0.)
            operator = (z @ weights['V'] @ weights['U']) * weights['output_std']
            state.update(z=z, raw=raw, gate=gate, operator=operator)

        def edit(_module, _inputs, output):
            count = len(prompt_ids) if state['step'] == 0 else 1
            assert output.shape == (1, count, 2560)
            delta = float(alpha) * (float(target) - state['gate']).unsqueeze(-1) * state['operator']
            assert torch.isfinite(delta).all()
            changed = (output.float() + delta).to(output.dtype)
            assert torch.isfinite(changed).all()
            actual = changed.float() - output.float()
            if alpha == 0.:
                assert torch.equal(changed, output)
            positions = list(range(len(prompt_ids))) if state['step'] == 0 else [len(prompt_ids) + state['step'] - 1]
            token_ids = prompt_ids if state['step'] == 0 else [state['prefix_ids'][-1]]
            for j, (position, token) in enumerate(zip(positions, token_ids)):
                trace.append({'phase': 'input' if state['step'] == 0 else 'output', 'position': position,
                              'token_id': token, 'token': tokenizer.decode([token]),
                              'raw': float(state['raw'][0, j]), 'natural_gate': float(state['gate'][0, j]),
                              'fixed_gate': target, 'alpha': alpha,
                              'operator_norm': float(state['operator'][0, j].norm()),
                              'intended_delta_norm': float(delta[0, j].norm()),
                              'actual_delta_norm': float(actual[0, j].norm()),
                              'native_mlp_norm': float(output[0, j].float().norm())})
            if audit and state['step'] in protocol['audit_vector_steps']:
                file = f"{name}--step-{state['step']}.npz"
                np.savez_compressed(OUT / file, positions=np.array(positions),
                                    z=state['z'].cpu().numpy(), raw=state['raw'].cpu().numpy(),
                                    gate=state['gate'].cpu().numpy(), operator=state['operator'].cpu().numpy(),
                                    native_mlp=output.float().cpu().numpy(), edited_mlp=changed.float().cpu().numpy(),
                                    intended_delta=delta.cpu().numpy(), actual_delta=actual.cpu().numpy())
                vectors.append({'file': file, 'sha256': sha(OUT / file), 'target': target, 'alpha': alpha})
            return changed

        if target is not None:
            handles = [block.post_attention_layernorm.register_forward_pre_hook(observe),
                       block.mlp.register_forward_hook(edit)]
        ids = torch.tensor([prompt_ids], device='cuda')
        mask, cache = torch.ones_like(ids), None
        stop = 'token_limit'
        try:
            for step in range(protocol['max_new_tokens']):
                deadline()
                state['step'] = step
                pred = model(input_ids=ids, attention_mask=mask, past_key_values=cache, use_cache=True)
                cache = pred.past_key_values
                logits = pred.logits[0, -1].float()
                assert torch.isfinite(logits).all()
                lp = logits.log_softmax(-1)
                prob = lp.exp()
                greedy = int(logits.argmax())
                values, indices = prob.topk(6)
                scores.append({'position': step, 'token_id': greedy, 'token': tokenizer.decode([greedy]),
                               'selected_probability': float(prob[greedy]),
                               'selected_logit': float(logits[greedy]),
                               'month_probability_mass': {m: float(prob[ids].sum()) for m, ids in month_ids.items()},
                               'target_month_logits': {m: [float(logits[i]) for i in month_ids[m]]
                                                       for m in ['January', 'November']},
                               'logsumexp': float(logits.logsumexp(-1)),
                               'top_tokens': [{'token_id': int(i), 'token': tokenizer.decode([int(i)]),
                                               'probability': float(v)} for i, v in zip(indices, values)]})
                generated.append(greedy)
                state['prefix_ids'].append(greedy)
                if greedy in eos:
                    stop = 'eos'
                    break
                ids = torch.tensor([[greedy]], device='cuda')
                mask = torch.cat([mask, torch.ones_like(ids)], dim=1)
            assert all(b.self_attn.forward == f for b, f in zip(model.model.layers, attention_functions))
        finally:
            for handle in handles:
                handle.remove()
        assert sum(len(m._forward_hooks) + len(m._forward_pre_hooks) for m in model.modules()) == 0
        if target is not None:
            assert len(trace) == len(prompt_ids) + len(generated) - 1
            assert [x['position'] for x in trace] == list(range(len(trace)))
        answer = tokenizer.decode(generated, skip_special_tokens=True)
        months = re.findall(r'\b(' + '|'.join(MONTHS) + r')\b', answer, flags=re.I)
        normalized = ' '.join(answer.lower().split())
        clean_november = bool(re.fullmatch(r'(?:november|the first month of the year is november)[.!]?', normalized))
        return {'name': name, 'fixed_gate': target, 'alpha': alpha, 'answer': answer,
                'output_token_ids': generated, 'steps': scores, 'trace': trace, 'vectors': vectors,
                'stop_reason': stop, 'months_mentioned': months,
                'first_month_mentioned': months[0].lower() if months else None,
                'clean_November_answer': clean_november,
                'all_prompt_and_processed_output_positions_covered': target is not None,
                'hooks_remaining': 0}

    try:
        native = run('native')
        assert native['first_month_mentioned'] == 'january', 'Native baseline did not answer January.'
        result['runs'].append(native)
        zero = run('zero_control', target=0., alpha=0., audit=True)
        assert native['output_token_ids'] == zero['output_token_ids'] and native['steps'] == zero['steps']
        result['runs'].append(zero)
        result['runs'].append(run('fixed_0', target=0., audit=True))
        save(OUT / 'results.json', result)
        print('NATIVE', repr(native['answer']), flush=True)
        for k in protocol['fixed_gate_values']:
            row = run(f'fixed_{k}', target=float(k), audit=k in [57])
            result['runs'].append(row)
            save(OUT / 'results.json', result)
            print('GATE', k, 'ANSWER', repr(row['answer']), 'CLEAN_NOVEMBER', row['clean_November_answer'], flush=True)
        successes = [r for r in result['runs'] if r['fixed_gate'] is not None and r['alpha'] == 1.
                     and r['fixed_gate'] >= 2 and r['clean_November_answer']]
        first = min(successes, key=lambda r: r['fixed_gate']) if successes else None
        if first:
            repeated = run('first_clean_November_success_repeat', target=first['fixed_gate'], audit=True)
            assert repeated['output_token_ids'] == first['output_token_ids'] and repeated['steps'] == first['steps']
            result['runs'].append(repeated)
        native_repeat = run('native_repeat')
        assert native_repeat['output_token_ids'] == native['output_token_ids'] and native_repeat['steps'] == native['steps']
        result['runs'].append(native_repeat)
        result.update(status='complete', finished_at_utc=datetime.now(timezone.utc).isoformat(),
                      elapsed_seconds=time.monotonic()-started, all_zero_controls_exact=True,
                      native_repeat_exact=True, successful_repeat_exact=bool(first),
                      lowest_tested_successful_integer_gate=first['fixed_gate'] if first else None,
                      successful_integer_gates=[r['fixed_gate'] for r in successes],
                      hooks_remaining=sum(len(m._forward_hooks)+len(m._forward_pre_hooks) for m in model.modules()),
                      only_edited_feature={'layer': 29, 'transform': 2375})
        save(OUT / 'results.json', result)
        print('COMPLETE', json.dumps({k: result[k] for k in ['lowest_tested_successful_integer_gate',
                                                           'successful_integer_gates', 'elapsed_seconds']}), flush=True)
    except BaseException as exc:
        result.update(status='failed', error_type=type(exc).__name__, error=str(exc))
        save(OUT / 'results.json', result)
        raise
    return result, weights
