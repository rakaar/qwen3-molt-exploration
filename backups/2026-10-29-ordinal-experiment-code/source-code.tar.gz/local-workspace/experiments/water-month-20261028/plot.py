"""Scientific plot of January/November mass at an identical native prefix."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'results/2026-10-28-water-month'


def main():
    data = json.loads((OUT / 'summary.json').read_text())
    rows = [r for r in data if r['fixed_gate'] is not None and r['fixed_gate'] >= 2 and r['alpha'] == 1]
    plt.rcParams.update({'font.family':'DejaVu Sans','svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
    fig, ax = plt.subplots(figsize=(10,5.8))
    for month,color in [('January','#3375b4'),('November','#c16929')]:
        xs = [r['fixed_gate'] for r in rows if r['same_native_prefix_at_month_slot']]
        ys = [100*r[f'p_{month}_at_same_prefix'] for r in rows if r['same_native_prefix_at_month_slot']]
        ax.plot(xs,ys,label=month,color=color,linewidth=2)
    ax.axvline(57,color='#5b646d',linestyle='--',linewidth=1)
    ax.text(58,48,'57: first tested integer\nwith November stated first',fontsize=10,color='#424b53')
    ax.set(xlim=(2,90),ylim=(-2,102),xlabel='Fixed gate value at every processed input/output token',
           ylabel='Conditional next-token mass (%)')
    ax.legend(frameon=False,loc='center left')
    ax.grid(alpha=.16)
    ax.set_title('L29–T2375: January → November at a shared answer prefix',loc='left',pad=15)
    fig.text(.11,.015,'Qwen3-4B · Greedy, thinking off · 28 October 2026\n'
             'Only identical-prefix measurements are plotted. November-first generations have degraded continuations and hit 64 tokens.',fontsize=8.5,color='#555')
    fig.subplots_adjust(bottom=.20,top=.88,right=.97,left=.11)
    for suffix in ['png','svg']:fig.savefig(OUT/f'month-probabilities.{suffix}',dpi=170,facecolor='white')
    plt.close(fig)
    print('Saved month-probabilities.png and .svg')


if __name__ == '__main__':main()
