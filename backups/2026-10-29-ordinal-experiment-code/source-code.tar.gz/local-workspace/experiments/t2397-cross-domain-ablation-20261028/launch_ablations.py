import contextlib
import traceback

with open('/workspace/t2397-cross-domain-ablation-20261028/ablations.log', 'w', buffering=1) as t2397_log:
    with contextlib.redirect_stdout(t2397_log), contextlib.redirect_stderr(t2397_log):
        try:
            t2397_results = t2397_ns['run_ablations'](t2397_engine, t2397_controls)
        except BaseException:
            traceback.print_exc()
            raise
