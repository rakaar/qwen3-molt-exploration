import contextlib
import runpy
import traceback

with open('/workspace/t2397-cross-domain-ablation-20261028/controls.log', 'w', buffering=1) as t2397_log:
    with contextlib.redirect_stdout(t2397_log), contextlib.redirect_stderr(t2397_log):
        try:
            t2397_ns = runpy.run_path('/workspace/t2397-cross-domain-ablation-20261028/run.py')
            t2397_engine, t2397_controls = t2397_ns['run_controls'](model, tokenizer)
        except BaseException:
            traceback.print_exc()
            raise
