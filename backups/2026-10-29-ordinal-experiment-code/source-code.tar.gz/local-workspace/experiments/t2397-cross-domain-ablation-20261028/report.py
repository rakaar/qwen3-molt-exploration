"""Build the private report from hash-checked measurements; no model calls."""
import csv
import hashlib
import io
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
OUT = WORKSPACE / 'results/2026-10-28-t2397-cross-domain-ablation'
OUT.mkdir(exist_ok=True)
sources = {}


def load(relative):
    path = ROOT / relative
    raw = path.read_bytes()
    sources[relative] = hashlib.sha256(raw).hexdigest()
    return json.loads(raw)


protocol = load('protocol.json')
cases = {c['id']:c for c in load('cases.json')}
controls = load('artifacts/controls.json')
results = load('artifacts/results.json')
review = load('eligibility.json')
audit = load('artifacts/audit.json')
runtime = load('artifacts/final-runtime.json')
load('ground-truth.json')
load('weights/manifest.json')
load('baseline-reference.json')
require_passed = audit['status'] == 'passed' and controls['status'] == results['status'] == 'complete'
assert require_passed
by_id = {r['case_id']:r for r in controls['controls']}
decisions = {r['case_id']:r for r in review['cases']}


def first_answer(case, answer):
    found = []
    if case['kind'] == 'number':
        found.extend((m.start(),-len(m.group()),m.group(),m.end()) for m in re.finditer(r'(?<![A-Za-z0-9])[-+]?\d+(?![A-Za-z0-9])',answer))
    for canonical,aliases in case['aliases'].items():
        for alias in aliases:
            pattern = r'(?<![A-Za-z0-9])'+re.escape(alias)+r'(?![A-Za-z0-9])'
            found.extend((m.start(),-len(m.group()),canonical,m.end()) for m in re.finditer(pattern,answer,re.I))
    return min(found) if found else None


def before_answer_events(case, native, observed):
    first = first_answer(case,native['answer'])
    if first is None:
        return [],None
    text = ''
    end_step = None
    for i,step in enumerate(native['steps']):
        text += step['token']
        if len(text) >= first[3]:
            end_step = i
            break
    assert end_step is not None
    n = len(native['prompt_token_ids'])
    events = [t for t in observed['trace'] if t['natural_gate']>0 and t['position'] < n+end_step]
    return events,end_step


rows = []
for cid,case in cases.items():
    for n in protocol['ablation_ordinals']:
        pair = by_id[cid]['ordinals'][str(n)]
        native = pair['native']
        eligible = decisions[cid]['eligible'][str(n)]
        selected = [r for r in results['runs'] if r['case_id']==cid and r['ordinal']==n]
        events,slot = before_answer_events(case,native,pair['zero_strength'])
        record = {'domain':cid,'label':case['label'],'ordinal':n,'expected':case['expected'][str(n)],'next_expected':case['expected'][str(n+1)],
                  'native_initial_answer':decisions[cid]['native_initial_answers'][str(n)],'native_next_initial_answer':decisions[cid]['native_initial_answers'][str(n+1)],
                  'eligible':eligible,'prompt':native['prompt'],'native_answer':native['answer'],
                  'natural_events_before_answer_completion':events,'answer_completion_token_step':slot,
                  'off_initial_answers':{r['scope']:r['assessment']['first_recognized_answer'] for r in selected},
                  'off_full_texts':{r['scope']:r['answer'] for r in selected},
                  'full_text_matches_native':{r['scope']:r['answer']==native['answer'] for r in selected},
                  'full_token_sequences_match_native':{r['scope']:r['output_token_ids']==native['output_token_ids'] for r in selected},
                  'nonzero_edit_positions':{r['scope']:[t for t in r['trace'] if t['actual_delta_norm']>0] for r in selected}}
        if not eligible:
            record['outcome']='excluded_native_capability'
        elif any(v==record['next_expected'] for v in record['off_initial_answers'].values()):
            record['outcome']='initial_n_to_n_plus_one'
        else:
            assert all(v==record['expected'] for v in record['off_initial_answers'].values())
            record['outcome']='active_before_answer_unchanged' if events else 'inactive_before_answer_unchanged'
        rows.append(record)

probability_examples = []
for cid,slot in [('integer',1),('roman',0)]:
    native = by_id[cid]['ordinals']['4']['native']
    next_native = by_id[cid]['ordinals']['5']['native']
    off = next(r for r in results['runs'] if r['case_id']==cid and r['ordinal']==4 and r['scope']=='all_positions')
    assert native['output_token_ids'][:slot] == off['output_token_ids'][:slot] == next_native['output_token_ids'][:slot]
    ids = [native['steps'][slot]['token_id'],next_native['steps'][slot]['token_id']]
    probability_examples.append({'domain':cid,'generation_step':slot,'shared_prefix_token_ids':native['output_token_ids'][:slot],
                                 'tokens':[native['steps'][slot]['token'],next_native['steps'][slot]['token']],
                                 'native_percent':[100*native['steps'][slot]['probe_probabilities'][str(i)] for i in ids],
                                 'all_off_percent':[100*off['steps'][slot]['probe_probabilities'][str(i)] for i in ids],
                                 'metric':'Next-token probabilities at this shared answer prefix; not full-answer probabilities.'})
alpha_native=by_id['alphabet']['ordinals']['4']['native']
alpha_off=next(r for r in results['runs'] if r['case_id']=='alphabet' and r['ordinal']==4 and r['scope']=='last_input_only')
alpha_probs={name:{letter:100*sum(run['steps'][0]['probe_probabilities'][str(i)] for i in ids) for letter,ids in [('D_or_d',[294,422]),('E_or_e',[384,468])]} for name,run in [('native',alpha_native),('off',alpha_off)]}
summary={'experiment':protocol['experiment'],'protocol':protocol,'cases':rows,'native_review':review,
         'completed_planned_runs':audit['counts']['runs'],'audit':audit,'runtime':runtime,
         'probability_examples':probability_examples,'alphabet_leading_space_case_summed_token_mass_percent':alpha_probs,
         'source_sha256':sources,'notes':['Initial answer is the outcome; later raw continuations may self-question, repeat or contain errors.',
                                       'An initial control attempt stopped at a probe-record comparison mismatch. Its partial files are preserved in attempt1 and excluded from completed planned-run counts.',
                                       'No positive gate clamp or increased-activation trials were run after the user clarified gate-off ablation.']}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with (OUT/'cases.csv').open('w',newline='') as stream:
    fields=['domain','ordinal','prompt','expected','next_expected','native_initial_answer','native_next_initial_answer','eligible','outcome','natural_events_before_answer_completion','off_initial_answers','native_answer','off_full_texts']
    writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
    for row in rows:
        writer.writerow({k:json.dumps(row[k],ensure_ascii=False) if isinstance(row[k],(dict,list)) else row[k] for k in fields})
all_runs=[]
for row in controls['controls']:
    for ordinal,pair in row['ordinals'].items():
        all_runs += [('native',pair['native']),('zero_strength',pair['zero_strength'])]
all_runs += [('ablation',r) for r in results['runs']]+[('specificity',r) for r in results['specificity_controls']]+[('repeat',r) for r in results['repeats']]
with (OUT/'responses.csv').open('w',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=['kind','domain','ordinal','name','scope','prompt','answer','stop_reason']);writer.writeheader()
    for kind,run in all_runs:
        writer.writerow({'kind':kind,'domain':run['case_id'],'ordinal':run['ordinal'],'name':run['name'],'scope':run.get('scope'),'prompt':run['prompt'],'answer':run['answer'],'stop_reason':run['stop_reason']})
assert len(all_runs)==187


def table_row(row):
    answers = row['off_initial_answers']
    active = '; '.join(f"{t['token']!r} at position {t['position']}, gate {t['natural_gate']:.6f}" for t in row['natural_events_before_answer_completion']) or 'none before initial answer'
    return f"| {row['label']} | {row['expected']} / {row['next_expected']} | {row['native_initial_answer'] or 'unvalidated'} / {row['native_next_initial_answer'] or 'unvalidated'} | {active} | "+' / '.join(answers.get(k,'excluded') for k in protocol['scopes'])+' |'


primary='\n'.join(table_row(r) for r in rows if r['ordinal']==4)
secondary='\n'.join(f"| {r['label']} | {r['expected']} / {r['next_expected']} | "+('unchanged in all four scopes' if r['eligible'] else 'excluded: native answer incorrect')+' |' for r in rows if r['ordinal']==3)
prob_rows='\n'.join(f"| {p['domain']} | `{token}` | {p['native_percent'][i]:.6f}% | {p['all_off_percent'][i]:.6f}% |" for p in probability_examples for i,token in enumerate(p['tokens']))
readme=f'''# L29–T2397 cross-domain gate-off tests — 28 October 2026

Layer, transform and token indices are zero-based.

**The fourth-letter D→E effect reproduced. No additional initial-answer shift appeared in this expanded test.** We tested the same ten task families used in the earlier T2375 study, using raw completion prefixes, after the user clarified that “updation” meant gate-off ablation. No increased-activation experiment was run.

There were 20 possible third/fourth target queries across ten domains: **15 passed native N/N+1 capability checks**, and five were excluded. The completed study contains **187 model runs**: 80 native/zero controls, 60 ablations, 17 first/fifth specificity controls and 30 deterministic repeats. These are conditions and checks, not independent statistical samples or an unbiased success-rate estimate.

## Fourth-to-fifth results

Gate-off scopes in the final column are **all input and generated positions / input only / final input only / generated positions only**, in that order. “None” in the activation column means no native activation before completion of the initial answer; it does not rule out later activation in the continuation.

| Task | Correct fourth / fifth | Native fourth / fifth | Native activation before initial answer | Gate-off initial answers in four scopes |
| --- | --- | --- | --- | --- |
{primary}

The alphabet changed from **D to E** under all-positions, input-only and final-input-only ablation. Output-only ablation kept D because the letter was already emitted before a generated token could be edited.

The integer answer **4** and square **16** deserve special attention: their final input gates were zero, but T2397 naturally fired on the **first generated space**, before the answer's digit(s), with gates **0.8524925709** and **0.5549637079**. All-position and output-only ablations removed these contributions, yet the initial answers stayed 4 and 16. Roman IV also stayed IV despite its active final ` is` gate of **0.7557848692**. These tests removed nonzero contributions before the initial answer.

Month April, element Beryllium, prime 7 and triangular 10 had no active contribution before their initial answer and remained unchanged. Removing an inactive contribution cannot establish that a feature would be ineffective if active.

The raw US-president prompts were wrong before intervention: the first began “a frenchman,” and third/fourth/fifth began John Adams. Both president target queries were excluded. The explicit-list fourth query initially answered dragon correctly, but the fifth query began “what?” and counted items without reaching a fifth-item answer within 32 tokens. Its fourth-to-fifth test was excluded. These exclusions apply to the exact raw prefixes tested.

## Third-position checks

The secondary third-to-fourth tests address possible before 3 behavior without assuming the feature is exclusive to 4. Seven of ten passed native capability and all seven kept their initial answer in all four scopes. None had a nonzero native contribution before completing its initial answer, although later continuation positions could activate.

| Task | Correct third / fourth | Result |
| --- | --- | --- |
{secondary}

The third-letter prefix initially answered B, and the third-positive-integer prefix initially answered 10. Those queries were excluded; the third-list query was eligible because its third/fourth native answers were candle/dragon.

## Probability changes and exact example

For `the fourth letter of the english alphabet is`, T2397 activated on final ` is`, zero-based input position7, gate **0.7188358306884766**. Leading-space case-summed next-token masses were:

| Tokens | Native | Gate off at final input |
| --- | ---: | ---: |
| ` D` + ` d` | {alpha_probs['native']['D_or_d']:.6f}% | {alpha_probs['off']['D_or_d']:.6f}% |
| ` E` + ` e` | {alpha_probs['native']['E_or_e']:.6f}% | {alpha_probs['off']['E_or_e']:.6f}% |

Other active edits changed probabilities without flipping the answer:

| Task | Next token at shared answer prefix | Native | All-position gate off |
| --- | --- | ---: | ---: |
{prob_rows}

The integer probabilities are measured after the identical generated leading space; the Roman probabilities are the first generated token. These are immediate token probabilities, not whole-answer probabilities. The alphabet masses combine two case variants; the integer/Roman table lists individual tokens.

Native alphabet continuation:

```text
{alpha_native['answer']}
```

Gate-off continuation:

```text
{alpha_off['answer']}
```

The supported effect concerns the **initial letter**. Full raw continuations are not uniformly coherent: they can repeat, self-question, or introduce unrelated/wrong statements. An initial correct native value was sufficient for capability screening; full 32-token factual accuracy was not asserted.

## Exact protocol and causal interpretation

Prompts are the earlier T2375 raw templates, replacing the ordinal with first, third, fourth or fifth. For example: `the fourth element of the periodic table is`, `the fourth positive integer in roman numerals is`, and `the fourth prime number is`. All exact prompts, ground truth, eligibility decisions and raw responses are in [cases.csv](cases.csv), [responses.csv](responses.csv) and [summary.json](summary.json).

The native Qwen3-4B MLP remains in place. At selected positions only, the edit subtracts the naturally thresholded gate multiplied by that position's input-dependent MOLT operator contribution. It targets zero, computes the edit in FP32, and rounds to BF16 once. Each autoregressive step recomputes the operator on that condition's current residual. No other feature was edited.

We used greedy decoding, raw text with no chat template, and a 32-token generation cap. Native N and N+1 answers were manually reviewed and hash-bound before ablation. First/fifth final-input specificity checks were run only where native answers were correct. They were inactive no-ops; there was no active unrelated or norm-matched transform control. Exact native and final-input-off repeats were recorded for every eligible target query.

This extends a previously selected positive, so the experiment is exploratory and prompt-dependent. Natural activation plus a label does not establish a general increment operation. In this set, the feature affects the initial alphabet answer but its active contributions on integers, Roman numerals and squares do not produce a next-ordinal answer.

## Verification and provenance

The CPU audit passed **{audit['counts']['runs']} runs**, **{audit['counts']['vector_files']} vector files** and **{audit['counts']['vector_positions']} sampled positions**, with **{audit['independent_transfer_hashes_checked']} independently recorded remote-file hashes** checked. There are 40 exact native/zero pairs, 30 exact repeat comparisons and 62 exact no-op comparisons. Every sampled residual standardization matched exactly; the maximum encoder absolute error was {audit['errors']['max_encoder_absolute']:.3g}, operator relative L2 error {audit['errors']['max_operator_relative_l2']:.3g}, and saved-probability reconstruction error {audit['errors']['max_probability_reconstruction']:.3g}. Sampled FP32 deltas and the final BF16 rounding matched exactly. Unselected local MLP outputs remained unchanged.

The initial control attempt stopped at a bookkeeping comparison: the expanded recorder contained more probability probes than the earlier reference. Its log, original source and 12 partial vector files remain under `attempt1/`. The corrected comparison checked the exact prior output tokens, core scores, and every shared probability probe. All three earlier month/alphabet/Roman baseline anchors matched exactly across their 24 saved steps. The partial attempt is excluded from the 187 completed planned runs; no nonzero intervention had run in that attempt.

Expected base: `Qwen/Qwen3-4B@{protocol['base_revision']}`; MOLT: `georglange/qwen3-4b-molt@{protocol['molt_revision']}`. The resident model inherits the earlier SHA-verified local load, and the selected T2397 slice matches its pinned manifest. No fresh whole-base file or memory hash was computed. Runtime reports BF16, eval mode, eager unchanged attention and zero hooks remaining. The audit checks saved vectors/positions and recorded invariance, rather than independently reproducing the complete model forward pass on CPU.

Primary measurements: [controls](../../experiments/t2397-cross-domain-ablation-20261028/artifacts/controls.json), [ablations](../../experiments/t2397-cross-domain-ablation-20261028/artifacts/results.json), [manual capability review](../../experiments/t2397-cross-domain-ablation-20261028/eligibility.json), [CPU audit](../../experiments/t2397-cross-domain-ablation-20261028/artifacts/audit.json), [runtime](../../experiments/t2397-cross-domain-ablation-20261028/artifacts/final-runtime.json), and [protocol](../../experiments/t2397-cross-domain-ablation-20261028/protocol.json). The model loading identity and its limits are recorded in [inherited provenance](../../experiments/t2397-cross-domain-ablation-20261028/inherited-base-provenance.json).

Related followup: [separate T1634/T1541/T1051 tests](../2026-10-28-l29-n235-cross-domain-ablation/README.md), using paired native capability checks and the same four scopes.

Results are private local files. No publishing or GPU lifecycle action was performed. The experiment GPU remains running under the existing $5 budget and keep-running instruction; dashboard resources were not modified.
'''
(OUT/'README.md').write_text(readme)
print(json.dumps({'output':str(OUT),'completed_runs':len(all_runs),'eligible_primary':sum(r['eligible'] for r in rows if r['ordinal']==4),'eligible_secondary':sum(r['eligible'] for r in rows if r['ordinal']==3),'new_initial_shifts':[(r['domain'],r['ordinal']) for r in rows if r['outcome']=='initial_n_to_n_plus_one']}))
