import json, torch, transformers
from pathlib import Path
from datetime import datetime, timezone
r=Path('/workspace/t2397-cross-domain-ablation-20261028')
hooks=sum(len(m._forward_hooks)+len(m._forward_pre_hooks) for m in model.modules())
assert hooks==0
assert all(b.self_attn.forward==f for b,f in zip(model.model.layers,t2397_engine.attention))
d={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'hooks_remaining':hooks,'attention_unchanged':True,'model_name_or_path':model.config._name_or_path,'model_config_commit_hash':getattr(model.config,'_commit_hash',None),'model_dtype':str(next(model.parameters()).dtype),'model_training':model.training,'attention_implementation':getattr(model.config,'_attn_implementation',None),'torch':torch.__version__,'transformers':transformers.__version__,'prior_baseline_anchors':t2397_controls['anchor_checks'],'checkpoint_identity_note':'Inherited prior SHA-verified local load; no fresh whole-base weight hash. Three earlier native continuations match exactly for saved tokens and all shared probability probes.'}
(r/'artifacts/final-runtime.json').write_text(json.dumps(d,indent=2)+'\n')
