"""Three tasks, paired native2/3 checks, and strictly input-only edits."""
import hashlib
import json
import runpy
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'artifacts'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path,data):
    temporary=path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    temporary.replace(path)


def phase(case,ordinal):
    c=dict(case)
    c['original_expected']=case['expected'][str(ordinal)]
    c['target_expected']=case['expected'][str(ordinal+1)]
    return c


def run_controls(model,tokenizer):
    OUT.mkdir(exist_ok=True)
    assert not (OUT/'controls.json').exists()
    protocol=json.loads((ROOT/'protocol.json').read_text());f=protocol['features'][0]
    engine=runpy.run_path(str(ROOT/'engine.py'))['Selective'](model,tokenizer,f"L{f['layer']}-T{f['transform']}")
    refs=json.loads((ROOT/'baseline-reference.json').read_text())
    d={'status':'running','protocol':protocol,'started_at_utc':datetime.now(timezone.utc).isoformat(),'controls':[],'anchor_checks':[],
       'source_sha256':{name:sha(ROOT/name) for name in ['protocol.json','cases.json','engine.py','run.py','weights/manifest.json','baseline-reference.json']}}
    for case in engine.cases:
        row={'case_id':case['id'],'feature_key':case['feature_key'],'ordinals':{}}
        for ordinal in [2,3]:
            native=engine.run(phase(case,ordinal),case['prompts'][str(ordinal)],f'ordinal-{ordinal}--native');native['ordinal']=ordinal
            pair={'native':native,'answer_sha256':hashlib.sha256(native['answer'].encode()).hexdigest()}
            if ordinal==2:
                zero=engine.run(phase(case,ordinal),native['prompt'],'ordinal-2--zero',spec={'kind':'input'},target=0.,alpha=0.,audit=True);zero['ordinal']=ordinal
                assert native['steps']==zero['steps'] and native['output_token_ids']==zero['output_token_ids'];pair['zero_strength']=zero
            row['ordinals'][str(ordinal)]=pair
            for ref in refs:
                if ref['case_id']==case['id'] and ref['ordinal']==ordinal:
                    count=len(ref['output_token_ids']);assert native['output_token_ids'][:count]==ref['output_token_ids']
                    for current,previous in zip(native['steps'][:count],ref['steps']):
                        assert {k:v for k,v in current.items() if k!='probe_probabilities'}=={k:v for k,v in previous.items() if k!='probe_probabilities'}
                        assert all(current['probe_probabilities'][token]==p for token,p in previous['probe_probabilities'].items())
                    d['anchor_checks'].append({'case_id':case['id'],'ordinal':ordinal,'matched_steps':count,'source_sha256':ref['source_sha256']})
            print('NATIVE',case['id'],ordinal,repr(native['answer']),flush=True)
        d['controls'].append(row);save(OUT/'controls.json',d)
    assert len(d['anchor_checks'])==len(refs)
    d.update(status='complete',finished_at_utc=datetime.now(timezone.utc).isoformat(),hooks_remaining=engine.hooks())
    save(OUT/'controls.json',d);print('CONTROLS_COMPLETE',flush=True)
    return engine,d


def run_ablations(engine,controls):
    assert controls['status']=='complete' and not (OUT/'results.json').exists()
    review=json.loads((ROOT/'eligibility.json').read_text());assert review['controls_sha256']==sha(OUT/'controls.json')
    decisions={x['case_id']:x for x in review['cases']};byid={x['case_id']:x for x in controls['controls']}
    engine.started=time.monotonic()
    d={'status':'running','eligibility':review,'controls_sha256':sha(OUT/'controls.json'),'source_sha256':sha(ROOT/'run.py'),'runs':[],'repeats':[],'adjacent_controls':[]}
    for case in engine.cases:
        cid=case['id'];decision=decisions[cid]
        for ordinal,pair in byid[cid]['ordinals'].items():assert decision['answer_sha256'][ordinal]==pair['answer_sha256']
        assert decision['eligible']==all(decision['native_correct'].values())
        if not decision['eligible']:continue
        native=byid[cid]['ordinals']['2']['native'];size=len(native['prompt_token_ids']);current={}
        for scope,spec in [('input_only',{'kind':'input'}),('last_input_only',{'kind':'positions','positions':[size-1]})]:
            result=engine.run(phase(case,2),native['prompt'],f'ordinal-2--off-{scope}',spec=spec,target=0.,audit=True);result.update(ordinal=2,scope=scope)
            assert all(not t['selected'] and t['actual_delta_norm']==0 for t in result['trace'] if t['phase']=='output')
            d['runs'].append(result);current[scope]=result;print('OFF',cid,scope,repr(result['answer']),flush=True);save(OUT/'results.json',d)
        for label,baseline in [('native-repeat',native),('input-off-repeat',current['input_only'])]:
            repeat=engine.run(phase(case,2),native['prompt'],label,spec=baseline['spec'],target=baseline['target'],alpha=baseline['alpha'],audit=True);repeat.update(ordinal=2,repeats_name=baseline['name'])
            assert repeat['steps']==baseline['steps'] and repeat['output_token_ids']==baseline['output_token_ids'] and repeat['trace']==baseline['trace'];d['repeats'].append(repeat)
        adjacent=byid[cid]['ordinals']['3']['native']
        result=engine.run(phase(case,3),adjacent['prompt'],'ordinal-3--off-input',spec={'kind':'input'},target=0.,audit=True);result.update(ordinal=3,scope='input_only');d['adjacent_controls'].append(result)
        save(OUT/'results.json',d)
    d.update(status='complete',hooks_remaining=engine.hooks(),finished_at_utc=datetime.now(timezone.utc).isoformat());save(OUT/'results.json',d)
    print('INPUT_ABLATIONS_COMPLETE',len(d['runs']),flush=True)
    return d
