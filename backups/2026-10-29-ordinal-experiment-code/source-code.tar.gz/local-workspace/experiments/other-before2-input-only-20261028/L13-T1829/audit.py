"""CPU audit for the restricted three-task, input-only study."""
import argparse
import hashlib
import json
from pathlib import Path
from audit_support import Audit,load,require,same_completion


class InputAudit(Audit):
    def record(self,run):
        self.run_record(run)
        require(run['spec'] is None or run['spec']['kind'] in ['input','positions'],'Non-input mask')
        require(all(not t['selected'] and t['actual_delta_norm']==0 for t in run['trace'] if t['phase']=='output'),'Generated token edited')

    def main(self):
        self.prepare_weights()
        ctl=load(self.artifacts/'controls.json');require(ctl['status']=='complete' and ctl['hooks_remaining']==0,'Incomplete controls')
        require(ctl['protocol']==self.protocol,'Protocol changed')
        for path,digest in ctl['source_sha256'].items():self.check_hash(path,digest)
        control_hash=self.check_hash('artifacts/controls.json');byid={r['case_id']:r for r in ctl['controls']}
        require(set(byid)==set(self.cases) and len(byid)==3,'Three-task coverage')
        for cid,row in byid.items():
            require(set(row['ordinals'])=={'2','3'},'Native ordinal pair')
            for ordinal,pair in row['ordinals'].items():
                native=pair['native'];require(native['spec'] is None and native['ordinal']==int(ordinal),'Native metadata')
                require(native['prompt']==self.cases[cid]['prompts'][ordinal],'Exact native prompt')
                require(hashlib.sha256(native['answer'].encode()).hexdigest()==pair['answer_sha256'],'Answer hash')
                self.record(native)
                if ordinal=='2':
                    zero=pair['zero_strength'];require(zero['spec']=={'kind':'input'} and zero['alpha']==0 and zero['target']==0,'Observer mask')
                    self.record(zero);same_completion(native,zero,'Exact native/zero');self.report['counts']['native_zero_pairs']+=1
                else:require(set(pair)=={'native','answer_sha256'},'Unexpected adjacent fields')
        anchors=load(self.root/'baseline-reference.json');require(len(anchors)==len(ctl['anchor_checks'])==2,'Native anchor coverage')
        for ref in anchors:
            native=byid[ref['case_id']]['ordinals'][str(ref['ordinal'])]['native'];count=len(ref['output_token_ids'])
            require(native['output_token_ids'][:count]==ref['output_token_ids'],'Prior tokens changed')
            for current,previous in zip(native['steps'][:count],ref['steps']):
                require({k:v for k,v in current.items() if k!='probe_probabilities'}=={k:v for k,v in previous.items() if k!='probe_probabilities'},'Prior scores changed')
                require(all(current['probe_probabilities'][token]==p for token,p in previous['probe_probabilities'].items()),'Prior shared probes changed')
        if self.controls_only:
            self.report.update(status='passed',controls_sha256=control_hash);return self.report
        results=load(self.artifacts/'results.json');review=load(self.root/'eligibility.json')
        self.check_hash('artifacts/results.json');self.check_hash('eligibility.json');self.check_hash('run.py',results['source_sha256'])
        require(results['status']=='complete' and results['hooks_remaining']==0,'Incomplete ablations')
        require(results['eligibility']==review and results['controls_sha256']==review['controls_sha256']==control_hash,'Review hash linkage')
        decisions={r['case_id']:r for r in review['cases']};require(set(decisions)==set(self.cases),'Manual review coverage');eligible=set()
        for cid,decision in decisions.items():
            require(set(decision['native_correct'])==set(decision['answer_sha256'])=={'2','3'},'Review ordinal coverage')
            require(type(decision['eligible']) is bool and decision['eligible']==all(decision['native_correct'].values()),'Invalid eligibility')
            for ordinal,pair in byid[cid]['ordinals'].items():require(decision['answer_sha256'][ordinal]==pair['answer_sha256'],'Unbound native review')
            if decision['eligible']:eligible.add(cid)
        seen=set()
        for run in results['runs']:
            cid=run['case_id'];scope=run['scope'];require(cid in eligible and (cid,scope) not in seen,'Ineligible/duplicate ablation');seen.add((cid,scope))
            native=byid[cid]['ordinals']['2']['native'];spec={'kind':'input'} if scope=='input_only' else {'kind':'positions','positions':[len(native['prompt_token_ids'])-1]}
            require(scope in self.protocol['scopes'] and run['spec']==spec and run['ordinal']==2 and run['alpha']==1 and run['target']==0,'Input ablation metadata')
            require(run['prompt_token_ids']==native['prompt_token_ids'],'Ablation prompt changed');self.record(run)
            if not any(t['actual_delta_norm'] for t in run['trace']):same_completion(native,run,'Input noop');self.report['counts']['exact_noop_comparisons']+=1
        require(seen=={(cid,s) for cid in eligible for s in self.protocol['scopes']},'Missing input scope')
        seen=set()
        for run in results['adjacent_controls']:
            cid=run['case_id'];require(cid in eligible and cid not in seen,'Adjacent control coverage');seen.add(cid)
            native=byid[cid]['ordinals']['3']['native'];require(run['ordinal']==3 and run['spec']=={'kind':'input'} and run['alpha']==1 and run['target']==0,'Adjacent mask')
            require(run['prompt_token_ids']==native['prompt_token_ids'],'Adjacent prompt changed');self.record(run)
            if not any(t['actual_delta_norm'] for t in run['trace']):same_completion(native,run,'Adjacent noop');self.report['counts']['exact_noop_comparisons']+=1
        require(seen==eligible,'Missing adjacent control')
        seen=set()
        for run in results['repeats']:
            cid=run['case_id'];require(cid in eligible and (cid,run['repeats_name']) not in seen,'Repeat coverage');seen.add((cid,run['repeats_name']))
            if run['repeats_name']=='ordinal-2--native':native=byid[cid]['ordinals']['2']['native']
            else:
                require(run['repeats_name']=='ordinal-2--off-input_only','Unknown repeat')
                native=next(r for r in results['runs'] if r['case_id']==cid and r['scope']=='input_only')
            self.record(run);same_completion(native,run,'Exact repeat',traces=True);self.report['counts']['exact_repeats']+=1
        require(len(seen)==2*len(eligible),'Missing repeats')
        self.report['limitations']=[x for x in self.report['limitations'] if not x.startswith('Exact repeats cover')]
        self.report['limitations'].append('Native and all-input ablations have exact repeats; final-input-only ablations do not have separate repeats.')
        self.report.update(status='passed',controls_sha256=control_hash,eligible_cases=len(eligible),generated_token_edits=0)
        return self.report


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);parser.add_argument('--controls-only',action='store_true');parser.add_argument('--expected-hashes',type=Path);args=parser.parse_args()
    audit=InputAudit(args.root,args.controls_only,args.expected_hashes);result=audit.main();(args.root/'artifacts'/('audit-controls.json' if args.controls_only else 'audit.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['status','counts','errors']},indent=2))
