import contextlib
import runpy
import traceback
from pathlib import Path

other2_root=Path('/workspace/other-before2-input-only-20261028')
with (other2_root/'controls.log').open('w',buffering=1) as other2_log:
    with contextlib.redirect_stdout(other2_log),contextlib.redirect_stderr(other2_log):
        try:
            other2_engines,other2_controls,other2_namespaces={},{},{}
            for feature in ['L9-T1981','L13-T1829','L19-T1645']:
                print('FEATURE',feature,flush=True)
                ns=runpy.run_path(str(other2_root/feature/'run.py'))
                engine,controls=ns['run_controls'](model,tokenizer)
                other2_engines[feature]=engine;other2_controls[feature]=controls;other2_namespaces[feature]=ns
            print('ALL_CONTROLS_COMPLETE',flush=True)
        except BaseException:
            traceback.print_exc()
            raise
