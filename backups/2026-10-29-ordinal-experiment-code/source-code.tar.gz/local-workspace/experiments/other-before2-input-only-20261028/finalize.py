import json,torch,transformers
from pathlib import Path
from datetime import datetime,timezone
r=Path('/workspace/other-before2-input-only-20261028');hooks=sum(len(m._forward_hooks)+len(m._forward_pre_hooks) for m in model.modules());assert hooks==0
assert all(block.self_attn.forward==f for engine in other2_engines.values() for block,f in zip(model.model.layers,engine.attention))
count=0;changes=[]
for name,res in other2_results.items():
 assert res['status']=='complete' and res['hooks_remaining']==0
 ctl=other2_controls[name];count+=sum(1+('zero_strength'in pair) for row in ctl['controls'] for pair in row['ordinals'].values())+len(res['runs'])+len(res['repeats'])+len(res['adjacent_controls'])
 for run in res['runs']+res['repeats']+res['adjacent_controls']:
  assert all(not t['selected'] and t['actual_delta_norm']==0 for t in run['trace'] if t['phase']=='output')
  if not run['assessment']['first_matches_expected']:changes.append({'feature':name,'case_id':run['case_id'],'name':run['name'],'answer':run['answer']})
assert count==72
d={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'completed_final_runs':count,'generated_token_edits':0,'hooks_remaining':hooks,'attention_unchanged':True,'model_name_or_path':model.config._name_or_path,'model_config_commit_hash':getattr(model.config,'_commit_hash',None),'model_dtype':str(next(model.parameters()).dtype),'model_training':model.training,'attention_implementation':getattr(model.config,'_attn_implementation',None),'torch':torch.__version__,'transformers':transformers.__version__,'initial_changes':changes,'identity_note':'Inherited earlier SHA-verified local load; no fresh whole-base hash.'}
(r/'final-runtime.json').write_text(json.dumps(d,indent=2)+'\n')
for name in other2_engines:(r/name/'artifacts/final-runtime.json').write_text(json.dumps(d,indent=2)+'\n')
