import contextlib
import traceback

with (other2_root/'ablations.log').open('w',buffering=1) as other2_log:
    with contextlib.redirect_stdout(other2_log),contextlib.redirect_stderr(other2_log):
        try:
            other2_results={}
            for feature in ['L9-T1981','L13-T1829','L19-T1645']:
                print('FEATURE',feature,flush=True)
                other2_results[feature]=other2_namespaces[feature]['run_ablations'](other2_engines[feature],other2_controls[feature])
            print('ALL_INPUT_ABLATIONS_COMPLETE',flush=True)
        except BaseException:
            traceback.print_exc()
            raise
