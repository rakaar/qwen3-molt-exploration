"""Create/read back the private three-task input-only study archive."""
import hashlib
import io
import json
import tarfile
from datetime import datetime, timezone
from pathlib import Path
WORKSPACE=Path(__file__).resolve().parents[2]
ARCHIVE=WORKSPACE/'artifacts/other-before2-input-only-20261028-private-backup.tar.gz'
RECORD=WORKSPACE/'comparisons/2026-10-28-other-before2-input-only/backup-verification.json'
roots=[WORKSPACE/'experiments/other-before2-input-only-20261028',WORKSPACE/'comparisons/2026-10-28-other-before2-input-only',WORKSPACE/'results/2026-10-28-other-before2-input-only',WORKSPACE/'results/2026-10-28-number-gate-discovery']
assert all(p.is_dir() for p in roots), 'Finalize the consolidated report first'
files = [p for root in roots for p in root.rglob('*')
         if p.is_file() and '__pycache__' not in p.parts and p != RECORD]
files += [WORKSPACE / 'experiments/ch-coactivation-20261028' / name
          for name in ['run.py', 'expected-base-verification.json', 'protocol.json']]
files += [WORKSPACE / 'experiments/number-predecessor-pilot-20261028/weights/manifest.json', WORKSPACE / 'comparisons/2026-10-28-number-gate-discovery/examples/build_consolidated_report.py']
files += [WORKSPACE / 'experiments/t2397-cross-domain-ablation-20261028/report.py']
files = sorted(set(files))


def digest(stream):
    return hashlib.file_digest(stream, 'sha256').hexdigest()


manifest = []
for path in files:
    with path.open('rb') as stream:
        manifest.append({'file': str(path.relative_to(WORKSPACE)), 'bytes': path.stat().st_size,
                         'sha256': digest(stream)})
manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
ARCHIVE.parent.mkdir(exist_ok=True)
with tarfile.open(ARCHIVE, 'w:gz', dereference=True) as tar:
    info = tarfile.TarInfo('backup-source-manifest.json')
    info.size = len(manifest_bytes)
    tar.addfile(info, io.BytesIO(manifest_bytes))
    for row in manifest:
        tar.add(WORKSPACE / row['file'], arcname=row['file'], recursive=False)

verified = 0
with tarfile.open(ARCHIVE, 'r:gz') as tar:
    assert tar.extractfile('backup-source-manifest.json').read() == manifest_bytes
    expected = {row['file']: row for row in manifest}
    for member in tar:
        if member.name == 'backup-source-manifest.json':
            continue
        row = expected.pop(member.name)
        assert member.isfile() and member.size == row['bytes']
        assert digest(tar.extractfile(member)) == row['sha256'], member.name
        verified += 1
    assert not expected
with ARCHIVE.open('rb') as stream:
    archive_hash = digest(stream)
record = {'status': 'passed', 'verified_at_utc': datetime.now(timezone.utc).isoformat(),
          'archive': str(ARCHIVE), 'bytes': ARCHIVE.stat().st_size, 'sha256': archive_hash,
          'verified_files': verified, 'source_manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
          'verification': 'Streamed every archived file back and compared bytes/SHA256 with its source manifest; no extraction or deletion.',
          'public_upload': False, 'gpu_cleanup_performed': False}
RECORD.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
