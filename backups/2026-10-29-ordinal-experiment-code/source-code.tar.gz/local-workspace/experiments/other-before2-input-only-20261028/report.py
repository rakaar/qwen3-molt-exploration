"""Private report of exactly three tasks and strictly input-only interventions."""
import csv
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
WORKSPACE=ROOT.parents[1]
OUT=WORKSPACE/'results/2026-10-28-other-before2-input-only'


def cell(value):
    return str(value).replace('|','\\|').replace('\n','\\n')


def main():
    OUT.mkdir(exist_ok=True)
    names=['L9-T1981','L13-T1829','L19-T1645']
    allrows=[];responses=[];audits=[];sources={};totals={};overrides={}
    if (ROOT/'outcome-review.json').exists():
        for row in json.loads((ROOT/'outcome-review.json').read_text())['runs']:overrides[(row['feature'],row['case_id'],row['name'])]=row
    for name in names:
        r=ROOT/name
        def load(path):
            file=r/path;sources[str(file.relative_to(ROOT))]=hashlib.sha256(file.read_bytes()).hexdigest();return json.loads(file.read_text())
        cases={c['id']:c for c in load('cases.json')};ctl=load('artifacts/controls.json');res=load('artifacts/results.json');review=load('eligibility.json');audit=load('artifacts/audit.json');load('protocol.json');load('weights/manifest.json')
        assert ctl['status']==res['status']=='complete' and audit['status']=='passed' and audit['generated_token_edits']==0
        decisions={d['case_id']:d for d in review['cases']}
        for row in ctl['controls']:
            cid=row['case_id'];case=cases[cid];native=row['ordinals']['2']['native'];pair3=row['ordinals']['3']['native'];observed=row['ordinals']['2']['zero_strength']
            runs=[x for x in res['runs'] if x['case_id']==cid];answers={}
            for run in runs:
                override=overrides.get((name,cid,run['name']))
                if override:
                    assert override['answer_sha256']==hashlib.sha256(run['answer'].encode()).hexdigest();answer=override['initial_answer']
                else:answer=run['assessment']['first_recognized_answer']
                answers[run['scope']]=answer
            adjacent=next((x for x in res['adjacent_controls'] if x['case_id']==cid),None)
            allrows.append({'feature':name,'domain':cid,'logical_prompt':case.get('logical_prompts',case['prompts'])['2'],'model_input':native['prompt'],'format':case['model_input_format'],
                            'native2':decisions[cid]['native_initial_answers']['2'],'native3':decisions[cid]['native_initial_answers']['3'],'eligible':decisions[cid]['eligible'],
                            'native_answer':native['answer'],'native_third_answer':pair3['answer'],
                            'active_input_tokens':[t for t in observed['trace'] if t['phase']=='input' and t['natural_gate']>0],
                            'off_initial_answers':answers,'off_full_texts':{x['scope']:x['answer'] for x in runs},
                            'third_input_off_answer':adjacent['answer'] if adjacent else None,'third_input_off_initial':adjacent['assessment']['first_recognized_answer'] if adjacent else None})
            for ordinal,pair in row['ordinals'].items():
                for key in ['native','zero_strength']:
                    if key in pair:
                        run=pair[key];responses.append({'feature':name,'kind':key,'domain':cid,'ordinal':run['ordinal'],'name':run['name'],'scope':run.get('scope'),'logical_prompt':case.get('logical_prompts',case['prompts'])[ordinal],'model_input':run['prompt'],'answer':run['answer'],'stop_reason':run['stop_reason']})
        for key in ['runs','repeats','adjacent_controls']:
            for run in res[key]:
                case=cases[run['case_id']];responses.append({'feature':name,'kind':key,'domain':run['case_id'],'ordinal':run['ordinal'],'name':run['name'],'scope':run.get('scope'),'logical_prompt':case.get('logical_prompts',case['prompts'])[str(run['ordinal'])],'model_input':run['prompt'],'answer':run['answer'],'stop_reason':run['stop_reason']})
        audits.append({'feature':name,'audit':audit})
        for key,value in audit['counts'].items():totals[key]=totals.get(key,0)+value
        totals['per_study_remote_hashes']=totals.get('per_study_remote_hashes',0)+audit['independent_transfer_hashes_checked']
    assert len(responses)==totals['runs']
    ctl9=json.loads((ROOT/'L9-T1981/artifacts/controls.json').read_text());res9=json.loads((ROOT/'L9-T1981/artifacts/results.json').read_text())
    native9=next(x for x in ctl9['controls'] if x['case_id']=='integer')['ordinals']['2']['native'];off9=next(x for x in res9['runs'] if x['case_id']=='integer' and x['scope']=='input_only')
    assert native9['steps'][0]['token']==off9['steps'][0]['token']=='2'
    active_probability={'token':'2','native_percent':100*native9['steps'][0]['selected_probability'],'all_input_off_percent':100*off9['steps'][0]['selected_probability'],'metric':'Immediate next-token probability; not a whole-answer probability.'}
    summary={'scope':'Only month/Roman/integer; only input positions; one feature at a time','cases':allrows,'audits':audits,'totals':totals,'source_sha256':sources,'L9_integer_next_token_probability':active_probability,
             'integer_format_note':'An initial rawQA baseline gave third integer12; final integer uses exact verified Qwen3 no-thinking chat rendering. Month/Roman remain raw completion prefixes. All current pairs passed before ablation.',
             'failed_raw_baseline_calls':27,'failed_raw_baseline_nonzero_edits':0}
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    fields=['feature','domain','format','logical_prompt','model_input','native2','native3','eligible','active_input_tokens','off_initial_answers','off_full_texts','third_input_off_initial','third_input_off_answer']
    with (OUT/'cases.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
        for row in allrows:writer.writerow({k:json.dumps(row[k],ensure_ascii=False) if isinstance(row[k],(list,dict)) else row[k] for k in fields})
    with (OUT/'responses.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=['feature','kind','domain','ordinal','name','scope','logical_prompt','model_input','answer','stop_reason']);writer.writeheader();writer.writerows(responses)
    rows=[]
    for row in allrows:
        active='; '.join(f"`{cell(repr(t['token']))}` at {t['position']} (gate{t['natural_gate']:.6f})" for t in row['active_input_tokens']) or 'none'
        rows.append(f"| {row['feature']} | {row['domain']} | {row['native2']} / {row['native3']} | {active} | {row['off_initial_answers'].get('input_only','excluded')} | {row['off_initial_answers'].get('last_input_only','excluded')} | {row['third_input_off_initial'] or 'unvalidated'} |")
    changed=[row for row in allrows if any(v!=row['native2'] for v in row['off_initial_answers'].values())]
    verdict='No initial-answer changes appeared.' if not changed else 'Changed initial answers are listed below and retained in full in the response CSV.'
    details=[]
    for row in changed:
        details.append(f"### {row['feature']} / {row['domain']}\n\nNative:\n\n```text\n{row['native_answer']}\n```\n")
        for scope,text in row['off_full_texts'].items():details.append(f"{scope}:\n\n```text\n{text}\n```\n")
    auditrows='\n'.join(f"| {x['feature']} | {x['audit']['counts']['runs']} | {x['audit']['counts']['vector_files']} | {x['audit']['counts']['vector_positions']} |" for x in audits)
    evidence='\n'.join(f"- {name}: [controls](../../experiments/other-before2-input-only-20261028/{name}/artifacts/controls.json), [results](../../experiments/other-before2-input-only-20261028/{name}/artifacts/results.json), [manual paired review](../../experiments/other-before2-input-only-20261028/{name}/eligibility.json), [CPU audit](../../experiments/other-before2-input-only-20261028/{name}/artifacts/audit.json)." for name in names)
    readme='''# Other before-2 gates: three tasks, input-only ablation

Study started 28 October 2026 and continued after midnight IST. Layer/transform/token indices are zero-based. Private local results; no publication or GPU lifecycle action.

Tested **L9–T1981, L13–T1829 and L19–T1645 separately**, on only **months, Roman numerals and positive-integer positions**. Each selected input intervention targets gate zero by subtracting its naturally gated MOLT contribution from the native MLP. Generated positions are never edited.

'''+f'**{verdict}**\n\n'+'''## Native capability and input format

Every final native2/3 pair passed manual review before any nonzero edit: February/March, II/III, and2/3. February abbreviated as `feb` was accepted. The month and Roman prompts remain the earlier raw completion prefixes. The integer task uses the normal Qwen3 no-thinking chat rendering of “What is the second/third positive integer? Answer with just the number.”

The initial rawQ/A integer baseline answered the third integer as12. All27 calls in that baseline attempt, including zero observers, are preserved under `raw-qa-baselines/` and excluded from final run counts. No nonzero intervention was run in that attempt. Only the integer input format was changed, based on native capability, before any ablation outcome was observed. Its chat template was rendered with the resident tokenizer after verifying tokenizer file hashes against the pinned base release.

The complete model input, including chat framing and assistant prefix for the integer case, is preserved in [cases.csv](cases.csv), [responses.csv](responses.csv) and [summary.json](summary.json). An all-input edit includes those framing tokens. Final-input-only edits select the last token of that complete model input.

## Results

“Third control” turns the same feature off on input positions for the matched third-ordinal prompt. Active tokens below come from the untouched native second-ordinal observer. An inactive input mask is a no-op and does not establish what the feature would do in an active context.

| Gate | Task | Native second / third | Active input tokens | Second: all-input off | Second: final-input off | Third control: input off |
| --- | --- | --- | --- | --- | --- | --- |
'''+ '\n'.join(rows)+'\n\n'+ '\n'.join(details)+f'''
No generated token was selected for editing in any condition. For a one-token answer, editing that answer token can only affect later predictions; a one-word answer can nevertheless span multiple tokens. This experiment uses input edits only, as requested.

Only L9–T1981 was active in the tested inputs, and only at chat formatting tokens in the integer case. It did not activate on the actual integer-question text. The other eight gate/task input combinations were inactive. All final-input-only masks were inactive. In the active L9 integer case, the next-token probability of `2` changed from {active_probability['native_percent']:.4f}% to {active_probability['all_input_off_percent']:.4f}% under all-input ablation; the answer stayed 2. These are immediate next-token probabilities, not whole-answer probabilities.

## Checks and limits

| Gate | Final completed runs | Saved vector files | Sampled positions |
| --- | ---: | ---: | ---: |
{auditrows}
| Combined | {totals['runs']} | {totals['vector_files']} | {totals['vector_positions']} |

Final run counts include paired native controls, one zero-strength observer per second-ordinal case, two input masks, exact native/all-input-off repeats and adjacent third-ordinal controls. Conditions and deterministic repeats are not independent statistical samples. There is no broad task suite, generated-token ablation or joint feature intervention here.

CPU audits check residual standardization, thresholded gates, input-dependent low-rank operators, sampled FP32 deltas and BF16 rounding, transfer hashes, exact native/zero equality, repeat equality and explicit zero edits at every recorded generated position. Source weights are pinned to `georglange/qwen3-4b-molt@081ce901b090b64aeecf9bc8709b57c10411e32a`; base model identity inherits the earlier SHA-verified Qwen3-4B load. Earlier month/Roman native token/probability anchors match exactly. No fresh whole-base memory or file hash is claimed.

Raw month/Roman continuations can repeat or contain later mistakes. The scored outcome is the initial answer, not full-continuation correctness. The chat integer responses were originally single-number answers; any changed continuations remain in the CSV. Activation on chat framing is distinct from an ordinal-specific input effect. The two raw-prefix tasks and the chat-formatted integer task should not be treated as one shared prompt format.

Primary evidence:

{evidence}
'''
    for a,b in [('started28','started 28'),('native2/3','native 2/3'),('and2/3','and 2/3'),('as12','as 12'),('All27','All 27'),('rawQ/A','raw Q/A'),('(gate','(gate ')]:readme=readme.replace(a,b)
    (OUT/'README.md').write_text(readme)
    print(json.dumps({'output':str(OUT),'cases':len(allrows),'completed_runs':totals['runs'],'initial_changes':[(x['feature'],x['domain']) for x in changed],'totals':totals}))


if __name__=='__main__':main()
