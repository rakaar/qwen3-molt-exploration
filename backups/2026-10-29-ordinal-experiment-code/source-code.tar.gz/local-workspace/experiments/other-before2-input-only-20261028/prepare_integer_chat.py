"""Render the integer questions with the resident tokenizer; no model forward."""
import contextlib
import hashlib
import json
import shutil
import traceback
from pathlib import Path

r=Path('/workspace/other-before2-input-only-20261028')
with (r/'chat-preparation.log').open('w',buffering=1) as log:
    with contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
        try:
            base=Path('/workspace/ch-coactivation-20261028')
            expected=json.loads((base/'expected-base-verification.json').read_text())
            hashes={}
            for row in expected['files']:
                if row['file'] in ['tokenizer.json','tokenizer_config.json']:
                    digest=hashlib.sha256((base/'model'/row['file']).read_bytes()).hexdigest()
                    assert digest==row['sha256']
                    hashes[row['file']]=digest
            questions={str(n):f'What is the {ordinal} positive integer? Answer with just the number.' for n,ordinal in [(2,'second'),(3,'third')]}
            rendered={n:tokenizer.apply_chat_template([{'role':'user','content':q}],tokenize=False,add_generation_prompt=True,enable_thinking=False) for n,q in questions.items()}
            features=['L9-T1981','L13-T1829','L19-T1645']
            failed=r/'raw-qa-baselines'
            assert not failed.exists()
            for feature in features:
                ctl=json.loads((r/feature/'artifacts/controls.json').read_text())
                assert ctl['status']=='complete' and ctl['hooks_remaining']==0
            (r/'integer-chat-prompts.json').write_text(json.dumps({'logical_questions':questions,'rendered_prompts':rendered,'enable_thinking':False,'tokenizer_sha256':hashes},indent=2)+'\n')
            failed.mkdir()
            for feature in features:(r/feature).rename(failed/feature)
            (r/'controls.log').rename(failed/'controls.log')
            for name in ['protocol.json','case-templates.json']:shutil.copy2(r/name,failed/name)
            (r/'chat-preparation.json').write_text(json.dumps({'status':'complete','old_baseline_runs':27,'nonzero_interventions_in_old_attempt':0,'chat_prompts_rendered':True},indent=2)+'\n')
            print('CHAT_PREPARATION_COMPLETE',flush=True)
        except BaseException:
            traceback.print_exc()
            raise
