"""Build a private, reproducible result summary and categorical scientific plot."""
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import ListedColormap
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'results/2026-10-28-water-selective'
SOURCE = ROOT / 'experiments/water-selective-20261028'


def normalize(text):
    return ' '.join(text.replace('**', '').replace('`', '').split()).strip(' .!?').casefold()


def main():
    rows = json.loads((OUT / 'responses.json').read_text())
    summary = json.loads((OUT / 'summary.json').read_text())
    controls = json.loads((OUT / 'controls.json').read_text())
    validation = json.loads((OUT / 'validation.json').read_text())
    search = json.loads((OUT / 'token-search.json').read_text())
    protocol = json.loads((SOURCE / 'protocol.json').read_text())
    plan = json.loads((SOURCE / 'plan.json').read_text())
    grid = protocol['strengths']
    words = [r for r in rows if r['case_id'] == 'roman' and r['stop'] == 'eos'
             and normalize(r['answer']) in {'eleven', 'eleventh', '11'}]
    (OUT / 'eleven-word-format-failures.json').write_text(json.dumps(words, indent=2) + '\n')
    clean = [r for r in rows if r['exact_clean_target']]
    counts = {'primary_and_prefix_conditions': validation['predeclared_steering_comparisons'] + validation['adaptive_prefix_cutoff_comparisons'],
              'adaptive_token_search_conditions_including_component_controls': validation['adaptive_token_search_comparisons_including_component_controls'],
              'final_leave_one_out_conditions': validation['final_leave_one_out_comparisons'],
              'final_reduced_mask_search_conditions': validation['final_reduced_mask_search_comparisons'],
              'exact_clean_target_conditions': sum(r['exact_clean_target'] for r in rows if r['screen'] in ['predeclared_screen', 'adaptive_prefix_cutoff']),
              'eleven_word_wrong_Roman_format_conditions': len(words),
              'query_only_all_three_cases_unchanged': all(r['exact_clean_original'] for r in rows if r['mask'] == 'query_only'),
              'natural_value_replay_answers': {r['case_id']: r['answer'] for r in rows if r['screen'] == 'natural_value_replay'}}
    counts['selected_integer_mask'] = search
    (OUT / 'outcomes.json').write_text(json.dumps(counts, indent=2) + '\n')
    colors = ['#c6dce9', '#249b76', '#bda5d4', '#f0d292', '#dc9992']
    fig, axes = plt.subplots(3, 1, figsize=(13.5, 12), gridspec_kw={'height_ratios': [8, 7, 8]})
    labels = {'integer': 'Positive integers: 1 → 11', 'roman': 'Roman numerals: I → XI', 'month': 'Calendar months: January → November'}
    for ax, cid in zip(axes, ['integer', 'roman', 'month']):
        conditions = [s for s in summary if s['case_id'] == cid]
        array = np.zeros((len(conditions), len(grid)), dtype=int)
        for i, condition in enumerate(conditions):
            for j, value in enumerate(grid):
                r = next(r for r in rows if r['case_id'] == cid and r['mask'] == condition['mask'] and r['screen'] == condition['screen'] and r['gate'] == value)
                array[i, j] = 1 if r['exact_clean_target'] else (0 if r['exact_clean_original'] else (2 if cid == 'roman' and r['stop'] == 'eos' and normalize(r['answer']) in {'eleven', 'eleventh', '11'} else (4 if r['truncated'] else 3)))
        ax.imshow(array, cmap=ListedColormap(colors), vmin=0, vmax=4, aspect='auto', interpolation='nearest')
        for i, condition in enumerate(conditions):
            for j, value in enumerate(grid):
                r = next(r for r in rows if r['case_id'] == cid and r['mask'] == condition['mask'] and r['screen'] == condition['screen'] and r['gate'] == value)
                if r['target_mentioned'] and not r['exact_clean_target']:
                    ax.plot(j, i, 'o', ms=3, color='#432450')
        ax.set_yticks(range(len(conditions)), [s['mask'].replace('_', ' ') + (' *' if s['screen'] == 'adaptive_prefix_cutoff' else '') for s in conditions], fontsize=9)
        ax.set_xticks(range(len(grid)), grid, fontsize=9)
        ax.set_xticks(np.arange(-.5, len(grid)), minor=True)
        ax.set_yticks(np.arange(-.5, len(conditions)), minor=True)
        ax.grid(which='minor', color='white', linewidth=1)
        ax.tick_params(which='minor', length=0)
        ax.set_title(labels[cid], loc='left', fontsize=12, weight='bold')
        ax.set_xlabel('Fixed gate value')
        for spine in ax.spines.values():
            spine.set_visible(False)
    legend = [Patch(color=colors[i], label=label) for i, label in enumerate(['Exact original answer', 'Exact target answer', 'Eleven word; wrong Roman format', 'Other EOS answer', 'Token limit'])]
    legend.append(Line2D([0], [0], marker='o', color='none', markerfacecolor='#432450', label='Target mentioned without clean success', markersize=4))
    fig.suptitle('L29–T2375: selective steering and early cutoffs', x=.02, ha='left', fontsize=16, weight='bold')
    fig.legend(handles=legend, loc='lower center', bbox_to_anchor=(.5, .03), ncol=2, frameon=False, fontsize=9)
    fig.text(.02, .008, '* Adaptive prefix-cutoff follow-up. One deterministic generation per cell; cells are not independent samples.', fontsize=9)
    fig.tight_layout(rect=(.01, .14, 1, .965), h_pad=1.6)
    fig.savefig(OUT / 'outcomes.png', dpi=160)
    fig.savefig(OUT / 'outcomes.svg')
    plt.close(fig)
    export = ROOT / 'comparisons/2026-10-28-water-selective/remote-export/water-selective-20261028'
    final = json.loads((export / 'artifacts/final.json').read_text())
    dense = [r for r in final['runs'] if r['screen'] == 'final_mask_dense_strength']
    # Compare the next-token distributions only on the same actual emitted prefix.
    digit_id = next(t['token_id'] for t in search['selected_tokens'] if t['phase'] == 'output')
    matched = [r for r in dense if r['output_token_ids'][0] == digit_id and len(r['steps']) > 1]
    assert len(matched) == len(dense), 'Inspect divergent prefixes before plotting probabilities'
    strength = [r['target'] for r in matched]
    p_digit = [r['steps'][1]['probe_probabilities'][str(digit_id)] for r in matched]
    p_eos = [sum(v for k, v in r['steps'][1]['probe_probabilities'].items() if k != str(digit_id)) for r in matched]
    fig, axes = plt.subplots(2, 1, figsize=(11, 4.8), sharex=True, gridspec_kw={'height_ratios': [.65, 4]})
    codes = np.array([[1 if r['assessment']['exact_clean_target'] else 0 for r in dense]])
    axes[0].imshow(codes, extent=[.5, 90.5, -.5, .5], aspect='auto', interpolation='nearest', cmap=ListedColormap(colors[:2]), vmin=0, vmax=1)
    axes[0].set_yticks([0], ['Complete answer'])
    for r in dense:
        if r['assessment']['exact_clean_target']:
            axes[0].text(r['target'], 0, '11', ha='center', va='center', fontsize=6, color='white')
    axes[1].plot(strength, p_digit, color='#249b76', label='P(next token is another 1)', lw=1.8)
    axes[1].plot(strength, p_eos, color='#437a9c', label='P(EOS)', lw=1.8)
    axes[1].scatter([88, 89, 90], [p_digit[i-1] for i in [88, 89, 90]], color='#249b76', s=25, zorder=3)
    axes[1].set(xlim=(.5, 90.5), ylim=(-.02, 1.02), xlabel='Fixed gate value at the three selected positions', ylabel='Probability after the first emitted 1')
    axes[1].set_xticks(list(range(0, 81, 10)) + [88, 90])
    axes[1].grid(alpha=.18)
    axes[1].legend(frameon=False, loc='center left')
    for ax in axes:
        for spine in ax.spines.values():
            spine.set_visible(False)
    fig.suptitle('First positive integer: three positions can produce a complete 11', fontsize=13, weight='bold')
    fig.text(.02, .015, 'Actual greedy generations; no forced answer prefix. Successful values: 88 and 90. Value 89 returns 1.', fontsize=9)
    fig.tight_layout(rect=(0, .05, 1, .94), h_pad=.3)
    fig.savefig(OUT / 'three-position-integer.png', dpi=170)
    fig.savefig(OUT / 'three-position-integer.svg')
    plt.close(fig)
    lines = ['# L29–T2375 selective token steering — 28 October 2026', '',
             f"An adaptive cutoff produces exact, EOS-terminated **11** for the first-positive-integer question. Full prompt plus only the first generated token works at tested strengths 87 and 90. A subsequent adaptive search reduces this to **{len(search['selected_positions'])} positions**; exact successful integer strengths are {search['exact_target_values']}. Value 89 returns 1, so this is not a monotonic threshold. No lower integer strength in 1–90 succeeded on that selected mask. No clean XI or stable November-only switch was found. These results are restricted to the selected prompts.", '',
             f"Tested {counts['primary_and_prefix_conditions']} primary/prefix strength-mask conditions, {counts['adaptive_token_search_conditions_including_component_controls']} adaptive token-search conditions including component controls, {counts['final_leave_one_out_conditions']} intermediate leave-one-position-out controls and {counts['final_reduced_mask_search_conditions']} final-mask search conditions, plus fixed-zero checks, native-value replay and three longer continuations. Conditions are deterministic exploratory comparisons, not independent samples.", '',
             '![Three-position integer intervention](three-position-integer.png)', '',
             '![Primary screen and prefix-cutoff outcomes](outcomes.png)', '',
             '## Native capability and position selection', '',
             'All six native answers and the full natural-gate traces were rerun and exactly reproduced the preceding experiment before any new steering. First questions naturally had no active positions for this transform. Gates selected from genuine-eleventh controls were mapped to identical tokens in the native first-question prompt/response, preserving the common prefix before aligning the suffix.', '']
    for c in controls:
        lines += [f"**{c['case_id']}**: `{c['first_prompt']}` → `{c['first_answer']}`; `{c['eleventh_prompt']}` → `{c['eleventh_answer']}`.", '']
        for t in c['aligned_active_tokens']:
            lines.append(f"- Donor {t['phase']} position {t['source_position']}, token {repr(t['token'])}, gate {t['donor_gate']:.6f} → recipient absolute position {t['recipient_position']}.")
        for t in c['unmapped_active_tokens']:
            lines.append(f"- Unmapped donor token {repr(t['token'])} at {t['source_position']}; excluded rather than moving the edit onto a different token.")
        lines.append('')
    lines += ['Output positions mean emitted tokens processed to predict the next token. The final prompt token predicts the first answer token. Selecting an answer token after it has been emitted cannot change that token. Output masks use fixed baseline-aligned offsets; no target tokens are teacher-forced.', '',
              '## Interventions', '',
              'The primary masks are query-only (user content), input-only (including chat template), output-only, donor-active input, donor-active output, their union, and a single answer-predecessor position. Empty masks were excluded and duplicate masks were recorded as aliases. Integer answer-predecessor equals donor-active input; Roman donor-active union equals donor-active input, with no active donor output token.', '',
              'Strength grid: '+', '.join(map(str, grid))+'. Donor natural-value replay uses the actual mapped gate values, around 0.56–2.25, rather than a shared fixed value. Every fixed-zero mask reproduced the native first answer exactly.', '',
              'The adaptive follow-up retained all input edits but stopped after one generated token for integers, one/four for Roman numerals, and eight for months. A query-plus-first-output integer mask was also tested. Three sparse month candidates were rerun with 192 tokens to inspect their complete unsteered continuations. Adaptive choices are reported separately.', '',
              'Only selected layer-29 native MLP outputs receive `(requested_gate - natural_gate) * ((z @ V) @ U) * output_std`. FP32 calculation, one BF16 cast, native MLP remainder retained. Every unselected local output is checked bit-exact against the same forward pass without the local edit. Earlier edits can still affect later computations through the model; this is not a claim that the entire future trajectory remains native.', '',
              '## Results', '',
              '| Case | Mask | Phase | Clean target values | Any target mention values |',
              '|---|---|---|---|---|']
    for s in summary:
        lines.append(f"| {s['case_id']} | {s['mask']} | {s['screen']} | {s['clean_target_values']} | {s['target_mention_values']} |")
    lines += ['', 'Query-only answers were unchanged in all three cases at every tested strength. Replaying the donor’s actual natural gates also retained the original answers.', '',
              f"### Exact integer 11 with {len(search['selected_positions'])} positions", '',
              'The first adaptive cutoff kept the whole prompt and only the first emitted token under intervention. It returned exactly `11` followed by EOS at gates 87 and 90, with exact repeats. The preceding all-token intervention returned `11` followed by repeated nonsense at these strengths.', '',
              'An additional adaptive search tested each individual input position plus the first emitted token at gate 90; none sufficed. A left-to-right greedy deletion pass reduced the mask to four positions. A leave-one-out check removed another position; further deletion passes stopped when no single deletion preserved exact 11 at gate 90. The resulting positions are:', '',
              '| Absolute position | Phase | Token | Native gate in first-question run |',
              '|---:|---|---|---:|']
    for t in search['selected_tokens']:
        lines.append(f"| {t['position']} | {t['phase']} | {repr(t['token'])} | {t['natural_gate']} |")
    lines += ['', f"The resulting mask was tested at every integer gate value 1–90. Exact target values: {search['exact_target_values']}. The lowest successful integer value tested was {search['lowest_successful_integer_strength_tested']}, repeated exactly along with the lower neighboring integer. This is an adaptively selected token set, not a globally minimal set or evidence of an ordinary natural-strength effect. The selected input positions belong to the chat template, so formatting is a material part of the condition.", '',
              'Final single-position deletion controls at gate 90:', '']
    for r in search['final_single_deletion_controls']:
        lines.append(f"- Omit position {r['omitted_position']}: `{r['answer']}`; clean 11: {r['clean_target']}.")
    lines += ['', 'Earlier four-position component and leave-one-position-out checks (retained for provenance):', '']
    for r in search['component_controls']:
        lines.append(f"- `{r['name']}` at {r['gate']}: `{r['answer']}`.")
    for r in search['final_leave_one_out']:
        lines.append(f"- Omit position {r['omitted_position']} at {r['gate']}: `{r['answer']}`; clean 11: {r['assessment']['exact_clean_target']}.")
    lines += ['',
              '### Eleven-related words that fail the Roman-format requirement', '',
              'The predeclared Roman target is XI. Complete answers such as “Eleven.” or “eleventh” can show a language-level eleven-related effect while failing the requested representation. They are listed separately and never silently counted as XI.', '']
    for mask in dict.fromkeys(r['mask'] for r in words):
        subset = [r for r in words if r['mask'] == mask]
        for answer in dict.fromkeys(r['answer'] for r in subset):
            vals = [r['gate'] for r in subset if r['answer'] == answer]
            lines.append(f"- `{mask}`, values {vals}: `{answer}` (EOS).")
    lines += ['', '### Every distinct target-containing response', '',
              'The full condition-level table is in responses.csv. Below are exact distinct candidate texts; repeated identical outputs are grouped.', '']
    candidates = [r for r in rows if r['target_mentioned']]
    for answer in dict.fromkeys(r['answer'] for r in candidates):
        subset = [r for r in candidates if r['answer'] == answer]
        conditions = '; '.join(f"{r['case_id']}/{r['mask']} gate {r['gate']} ({r['screen']}, {r['stop']})" for r in subset)
        lines += [conditions, '', '```text', answer, '```', '']
    lines += ['## Validation and limits', '',
              f"Independent CPU audit reconstructed the encoder, thresholded gate, low-rank operator and BF16 edit for {validation['vector_files']} vector files / {validation['vector_positions']} sampled positions. Coverage checked {validation['processed_positions']} processed positions, including {validation['unselected_positions_checked_unchanged']} unselected local outputs. Native, zero-strength, fixed-zero and selected repeated conditions matched exactly; hooks were removed.", '',
              'The pinned base/MOLT revisions, runtime and raw traces are recorded in protocol.json and the private verified backup. No model weights were trained or edited.', '',
              'A target mention inside self-correction is not a stable answer switch. EOS alone is not a guarantee of coherence. Exact short numeric/Roman targets must finish at EOS; month candidates are also inspected for self-correction and unrelated continuation. A negative result on this grid does not exclude effects at untested values, masks, prompts or layers. A positive selected condition would not establish that this transform exclusively encodes eleven or performs a general eleventh-item operation.', '',
              '[Every response](responses.csv) · [Native controls and selected positions](controls.json) · [Validation](validation.json) · [Outcome counts](outcomes.json)', '']
    (OUT / 'README.md').write_text('\n'.join(lines))
    print(json.dumps(counts, indent=2))


if __name__ == '__main__':
    main()
