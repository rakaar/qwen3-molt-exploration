"""Adaptive integer token search after an exact 11 prefix-cutoff success."""
import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'artifacts'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    tmp.replace(path)


def run_narrow(engine, refinement):
    assert refinement['status'] == 'complete' and not (OUT / 'narrow.json').exists()
    engine.started = time.monotonic()
    case = next(c for c in engine.cases if c['id'] == 'integer')
    n = engine.plan['cases']['integer']['prompt_length']
    reference = next(r for r in refinement['runs'] if r['case_id'] == 'integer' and r['mask_name'] == 'input_plus_first_output' and r['target'] == 90)
    assert reference['assessment']['exact_clean_target']
    result = {'status': 'running', 'started_at_utc': datetime.now(timezone.utc).isoformat(),
              'parent_sha256': sha(OUT / 'refinement.json'), 'source_sha256': sha(ROOT / 'narrow.py'),
              'protocol': 'Test each individual prompt position together with the first emitted-token position at gate 90. If no singleton works, start with all input positions plus first output and greedily remove input positions in increasing index order whenever the answer remains exact 11. Sweep every integer strength 1..90 on the resulting mask. This adaptive search does not establish a globally minimal token set. Repeat the lowest successful tested strength and compare input-only/output-only subsets.',
              'runs': [], 'decisions': [], 'repeats': []}

    def run(positions, target, name, screen):
        r = engine.run(case, case['first_prompt'], name, spec={'kind': 'positions', 'positions': sorted(positions)}, target=target, audit=True)
        r['mask_name'], r['screen'] = name.split('--')[0], screen
        result['runs'].append(r)
        save(OUT / 'narrow.json', result)
        return r

    single = []
    for pos in range(n):
        r = run([pos, n], 90, f'single-input-{pos}--gate-90', 'adaptive_single_input_search')
        if r['assessment']['exact_clean_target']:
            single.append(pos)
        print('SINGLE_INPUT', pos, 'clean', r['assessment']['exact_clean_target'], flush=True)
    if single:
        current = [single[0], n]
        result['selection'] = {'method': 'first successful singleton in index order', 'successful_singletons': single}
    else:
        current = list(range(n + 1))
        for pos in range(n):
            trial = [p for p in current if p != pos]
            r = run(trial, 90, f'greedy-remove-{pos}--gate-90', 'adaptive_greedy_input_pruning')
            removed = r['assessment']['exact_clean_target']
            result['decisions'].append({'tested_removal': pos, 'positions_before': current.copy(), 'trial_positions': trial,
                                        'removed': removed, 'run_name': r['name']})
            if removed:
                current = trial
            save(OUT / 'narrow.json', result)
            print('GREEDY_REMOVE', pos, 'removed', removed, 'remaining', len(current), flush=True)
        result['selection'] = {'method': 'one increasing-index greedy deletion pass; no global minimum claim', 'successful_singletons': []}
    result['selected_positions'] = current
    save(OUT / 'narrow.json', result)
    for target in range(1, 91):
        r = run(current, target, f'selected-mask--gate-{target}', 'adaptive_selected_mask_dense_strength')
        print('NARROW_STRENGTH', target, 'clean', r['assessment']['exact_clean_target'], flush=True)
    successes = [r for r in result['runs'] if r['screen'] == 'adaptive_selected_mask_dense_strength' and r['assessment']['exact_clean_target']]
    assert successes
    best = min(successes, key=lambda r: r['target'])
    result['lowest_successful_integer_strength_tested'] = best['target']
    run([p for p in current if p < n], best['target'], 'selected-input-only', 'selected_mask_component_control')
    run([n], best['target'], 'selected-output-only', 'selected_mask_component_control')
    repeat = engine.run(case, case['first_prompt'], 'selected-mask-repeat', spec=best['spec'], target=best['target'], audit=True)
    assert repeat['steps'] == best['steps'] and repeat['trace'] == best['trace'] and repeat['output_token_ids'] == best['output_token_ids']
    repeat['repeats_name'] = best['name']
    result['repeats'].append(repeat)
    native = engine.run(case, case['first_prompt'], 'narrow-native-repeat')
    assert native['answer'] == '1'
    native['repeats_name'] = 'native_first'
    result['repeats'].append(native)
    result.update(status='complete', finished_at_utc=datetime.now(timezone.utc).isoformat(), hooks_remaining=engine.hooks())
    save(OUT / 'narrow.json', result)
    print('NARROW_COMPLETE', current, 'lowest successful integer tested', best['target'], flush=True)
    return result
