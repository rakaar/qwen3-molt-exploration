"""Choose position masks using earlier native controls, before new outcomes."""
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parents[1]
PREVIOUS = WORK / 'comparisons/2026-10-28-water-ordinal-battery/remote-export/water-ordinal-battery-20261028'


def main():
    source = PREVIOUS / 'artifacts/controls.json'
    controls = json.loads(source.read_text())
    cases = json.loads((PREVIOUS / 'cases.json').read_text())
    ids = ['integer', 'roman', 'month']
    cases = [next(c for c in cases if c['id'] == cid) for cid in ids]
    plan = {'selection_source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
            'alignment': 'Token-ID matching separately for prompt and native answer; preserve the exact common prefix first, then SequenceMatcher on the remaining suffix, autojunk=False. This maps the first donor 1 in 11 to the first recipient 1 rather than the second donor 1. Only exactly matching donor tokens are mapped. Output positions follow the predeclared native-first response offsets even if the steered response diverges; no target text is forced.',
            'cases': {}}
    for case in cases:
        row = next(r for r in controls['controls'] if r['case_id'] == case['id'])
        first, donor = row['zero_first'], row['zero_11th']
        n = len(first['prompt_token_ids'])
        mappings = {}
        for phase, key in [('input', 'prompt_token_ids'), ('output', 'output_token_ids')]:
            prefix = 0
            while prefix < min(len(donor[key]), len(first[key])) and donor[key][prefix] == first[key][prefix]:
                prefix += 1
            matcher = difflib.SequenceMatcher(None, donor[key][prefix:], first[key][prefix:], autojunk=False)
            mappings[phase] = {i: i for i in range(prefix)}
            mappings[phase].update({prefix + i + offset: prefix + j + offset
                                   for i, j, size in matcher.get_matching_blocks() for offset in range(size)})
        selected, unmapped = [], []
        for t in donor['trace']:
            if not t['natural_gate'] > 0:
                continue
            offset = t['position'] if t['phase'] == 'input' else t['position'] - len(donor['prompt_token_ids'])
            mapped = mappings[t['phase']].get(offset)
            record = {'source_position': t['position'], 'phase': t['phase'], 'token': t['token'],
                      'token_id': t['token_id'], 'donor_gate': t['natural_gate']}
            if mapped is None:
                unmapped.append(record)
            else:
                record.update(recipient_position=mapped if t['phase'] == 'input' else n + mapped,
                              recipient_offset=mapped)
                selected.append(record)
        end = next(t['position'] for t in first['trace'] if t['token'] == '<|im_end|>')
        assert ''.join(t['token'] for t in first['trace'][3:end]) == case['first_prompt']
        inp = sorted(t['recipient_position'] for t in selected if t['phase'] == 'input')
        out = sorted(t['recipient_position'] for t in selected if t['phase'] == 'output')
        # The native output answer begins immediately for numbers/Roman numerals;
        # the month name follows the common "The ... is **" prefix at offset 8.
        answer_offset = 8 if case['id'] == 'month' else 0
        predecessor = n + answer_offset - 1
        mask_specs = {
            'query_only': {'kind': 'positions', 'positions': list(range(3, end))},
            'input_only': {'kind': 'input'},
            'output_only': {'kind': 'output'},
            'donor_active_input': {'kind': 'positions', 'positions': inp},
            'donor_active_output': {'kind': 'positions', 'positions': out},
            'donor_active_union': {'kind': 'positions', 'positions': sorted(inp + out)},
            'answer_predecessor_only': {'kind': 'positions', 'positions': [predecessor]},
        }
        canonical, aliases, empty = {}, {}, []
        for name, spec in mask_specs.items():
            positions = spec.get('positions')
            if positions == []:
                empty.append(name)
                continue
            prior = next((k for k, v in canonical.items() if v == spec), None)
            if prior:
                aliases[name] = prior
            else:
                canonical[name] = spec
        plan['cases'][case['id']] = {
            'prompt_length': n, 'source_first_answer': first['answer'], 'source_eleventh_answer': donor['answer'],
            'native_first_active_positions': [t['position'] for t in first['trace'] if t['natural_gate'] > 0],
            'mapped_active_tokens': selected, 'unmapped_active_tokens': unmapped,
            'masks': canonical, 'aliases': aliases, 'empty_masks': empty,
            'native_gate_replay': {str(t['recipient_position']): t['donor_gate'] for t in selected},
            'answer_offset': answer_offset,
        }
    protocol = {
        'experiment': 'L29-T2375 selective token steering',
        'base_repo': 'Qwen/Qwen3-4B', 'base_revision': '1cfa9a7208912126459214e8b04321603b3df60c',
        'molt_repo': 'georglange/qwen3-4b-molt', 'molt_revision': '081ce901b090b64aeecf9bc8709b57c10411e32a',
        'cases': ids, 'strengths': [1, 2, 3, 5, 10, 15, 20, 25, 30, 33, 40, 50, 57, 60, 70, 80, 87, 90],
        'enable_thinking': False, 'decode': 'greedy', 'max_new_tokens': 64, 'max_runtime_minutes': 35,
        'intervention': 'At selected positions only, native layer-29 MLP output += (fixed_gate - current_natural_gate) * ((z @ V) @ U) * output_std; FP32 then one BF16 cast. Unselected local MLP outputs must remain bit-exact. Native remainder retained. Other transform gates unchanged.',
        'phase_definition': 'Input includes the chat template. Query-only is user content, excluding the template. Output refers to already emitted tokens processed to predict the following token. The final prompt position predicts the first answer token.',
        'controls': ['fresh native first and eleventh, each exactly matched to prior native controls', 'zero-strength all-position observer on first and eleventh', 'fixed-zero each unique mask', 'donor natural gate replay on aligned active positions'],
        'success': 'Integer and Roman numeral: EOS-terminated exact short target after formatting normalization. Month: complete correct-format sentence stating November, without self-correction or unrelated continuation; manually review. Target mention and truncation are separate diagnostics.',
        'search': 'All fixed strengths tested for all nonempty unique masks. Duplicates recorded as aliases, not rerun or double-counted. No result-dependent mask selection. Natural gate replay tested once per case.',
        'audit_steps': [0, 1, 2, 8],
    }
    for name, value in [('cases.json', cases), ('plan.json', plan), ('protocol.json', protocol)]:
        (ROOT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')
    (ROOT / 'prior-controls.json').write_bytes(source.read_bytes())
    print(json.dumps({cid: {'active': p['mapped_active_tokens'], 'unmapped': p['unmapped_active_tokens'],
                            'masks': p['masks'], 'aliases': p['aliases'], 'empty': p['empty_masks']}
                      for cid, p in plan['cases'].items()}, indent=2))


if __name__ == '__main__':
    main()
