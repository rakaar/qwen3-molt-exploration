"""Follow up the successful leave-one-out reduction; preserve earlier searches."""
import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'artifacts'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(d):
    temp = OUT / 'final.tmp'
    temp.write_text(json.dumps(d, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    temp.replace(OUT / 'final.json')


def run_final(engine, narrow, confirmation):
    assert confirmation['status'] == 'complete' and not (OUT / 'final.json').exists()
    engine.started = time.monotonic()
    case = next(c for c in engine.cases if c['id'] == 'integer')
    succeeded = [r for r in confirmation['runs'] if r['assessment']['exact_clean_target']]
    assert succeeded
    positions = min((r['spec']['positions'] for r in succeeded), key=lambda x: (len(x), x))
    d = {'status': 'running', 'started_at_utc': datetime.now(timezone.utc).isoformat(),
         'parent_sha256': sha(OUT / 'confirmation.json'), 'source_sha256': sha(ROOT / 'finish.py'),
         'initial_positions': positions.copy(), 'protocol': 'The first final-mask leave-one-out check succeeded after deleting the think token. Start with that reduced mask, greedily remove any further position at gate 90 until one complete pass has no successful deletion. This establishes only single-deletion irreducibility at gate 90. Test every integer strength 1..90 on the resulting mask; repeat the lowest successful strength and its lower neighbor. Retain all intermediate masks.',
         'runs': [], 'decisions': [], 'repeats': []}
    pass_index = 0
    while True:
        changed = False
        for pos in positions.copy():
            trial = [p for p in positions if p != pos]
            name = f'final-pass-{pass_index}-drop-{pos}'
            r = engine.run(case, case['first_prompt'], name, spec={'kind': 'positions', 'positions': trial}, target=90, audit=True)
            r['screen'], r['mask_name'] = 'further_single_deletion', name
            d['runs'].append(r)
            remove = r['assessment']['exact_clean_target']
            d['decisions'].append({'positions_before': positions.copy(), 'removed_position': pos, 'trial_positions': trial, 'removed': remove, 'run_name': name, 'pass': pass_index})
            if remove:
                positions = trial
                changed = True
            save(d)
        pass_index += 1
        if not changed:
            break
    d['selected_positions'] = positions
    for target in range(1, 91):
        r = engine.run(case, case['first_prompt'], f'final-selected-mask--gate-{target}', spec={'kind': 'positions', 'positions': positions}, target=target, audit=True)
        r['screen'], r['mask_name'] = 'final_mask_dense_strength', 'final_selected_mask'
        d['runs'].append(r)
        save(d)
        print('FINAL_STRENGTH', target, 'clean', r['assessment']['exact_clean_target'], flush=True)
    successes = [r for r in d['runs'] if r['screen'] == 'final_mask_dense_strength' and r['assessment']['exact_clean_target']]
    assert successes
    best = min(r['target'] for r in successes)
    d['lowest_successful_integer_strength_tested'] = best
    for target in [best - 1, best]:
        if target < 1:
            continue
        original = next(r for r in d['runs'] if r['screen'] == 'final_mask_dense_strength' and r['target'] == target)
        r = engine.run(case, case['first_prompt'], f'final-repeat--gate-{target}', spec=original['spec'], target=target, audit=True)
        assert r['steps'] == original['steps'] and r['trace'] == original['trace'] and r['output_token_ids'] == original['output_token_ids']
        r['repeats_name'] = original['name']
        d['repeats'].append(r)
    d.update(status='complete', finished_at_utc=datetime.now(timezone.utc).isoformat(), hooks_remaining=engine.hooks())
    save(d)
    print('FINAL_COMPLETE', positions, 'lowest integer tested', best, flush=True)
    return d
