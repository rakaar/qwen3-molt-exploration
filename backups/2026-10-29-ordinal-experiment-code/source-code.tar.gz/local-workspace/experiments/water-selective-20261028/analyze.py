"""Independently audit selected-position coverage, masks, and sampled vectors."""
import csv
import hashlib
import json
import math
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
EXPORT = ROOT / 'comparisons/2026-10-28-water-selective/remote-export/water-selective-20261028'
OUT = ROOT / 'results/2026-10-28-water-selective'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bf16_round(x):
    bits = np.ascontiguousarray(x, dtype=np.float32).view(np.uint32)
    bits = bits + np.uint32(0x7FFF) + ((bits >> 16) & 1)
    return (bits & np.uint32(0xFFFF0000)).view(np.float32)


def main():
    OUT.mkdir(exist_ok=True)
    d = json.loads((EXPORT / 'artifacts/results.json').read_text())
    refinement = json.loads((EXPORT / 'artifacts/refinement.json').read_text())
    narrow = json.loads((EXPORT / 'artifacts/narrow.json').read_text())
    confirmation = json.loads((EXPORT / 'artifacts/confirmation.json').read_text())
    final = json.loads((EXPORT / 'artifacts/final.json').read_text())
    plan = json.loads((EXPORT / 'plan.json').read_text())
    cases = json.loads((EXPORT / 'cases.json').read_text())
    old = json.loads((EXPORT / 'prior-controls.json').read_text())
    assert d['status'] == 'complete' and d['hooks_remaining'] == 0
    assert refinement['status'] == 'complete' and refinement['hooks_remaining'] == 0
    assert sha(EXPORT / 'artifacts/results.json') == refinement['parent_sha256']
    assert sha(EXPORT / 'refine.py') == refinement['source_sha256']
    assert narrow['status'] == 'complete' and narrow['hooks_remaining'] == 0
    assert sha(EXPORT / 'artifacts/refinement.json') == narrow['parent_sha256']
    assert sha(EXPORT / 'narrow.py') == narrow['source_sha256']
    assert confirmation['status'] == 'complete' and confirmation['hooks_remaining'] == 0
    assert sha(EXPORT / 'artifacts/narrow.json') == confirmation['parent_sha256']
    assert sha(EXPORT / 'confirm.py') == confirmation['source_sha256']
    assert final['status'] == 'complete' and final['hooks_remaining'] == 0
    assert sha(EXPORT / 'artifacts/confirmation.json') == final['parent_sha256']
    assert sha(EXPORT / 'finish.py') == final['source_sha256']
    assert d['plan'] == plan
    for name, expected in d['source_sha256'].items():
        assert sha(EXPORT / name) == expected
    assert sha(EXPORT / 'prior-controls.json') == plan['selection_source_sha256']
    f = d['feature']
    assert (f['layer'], f['transform']) == (29, 2375)
    assert sha(EXPORT / 'weights' / f['file']) == f['sha256']
    with np.load(EXPORT / 'weights' / f['file'], allow_pickle=False) as a:
        w = {k: a[k].astype(np.float64) for k in a.files}
    counts = {'runs_audited': 0, 'processed_positions': 0, 'selected_positions': 0,
              'unselected_positions_checked_unchanged': 0, 'vector_files': 0, 'vector_positions': 0}
    errors = {'max_gate_score_absolute_error': 0., 'max_operator_relative_l2_error': 0.,
              'max_probability_reconstruction_error': 0.}

    def audit(r):
        counts['runs_audited'] += 1
        assert r['hooks_remaining'] == 0
        n = len(r['prompt_token_ids'])
        if r['spec'] is not None:
            assert len(r['trace']) == n + len(r['output_token_ids']) - 1
            spec = r['spec']
            for i, t in enumerate(r['trace']):
                expected_selected = spec['kind'] == 'all' or spec['kind'] == ('input' if i < n else 'output') or (spec['kind'] == 'positions' and i in spec['positions'])
                assert t['position'] == i and t['selected'] == expected_selected
                assert t['token_id'] == (r['prompt_token_ids'][i] if i < n else r['output_token_ids'][i-n])
                fixed = r['replay'].get(str(i), r['target']) if r['replay'] else r['target']
                assert t['requested_gate'] == fixed and t['alpha'] == r['alpha']
                if not expected_selected:
                    assert t['unselected_unchanged'] and t['intended_delta_norm'] == t['actual_delta_norm'] == 0.
                    counts['unselected_positions_checked_unchanged'] += 1
                else:
                    counts['selected_positions'] += 1
                counts['processed_positions'] += 1
        for s in r['steps']:
            e = abs(math.exp(s['selected_logit'] - s['logsumexp']) - s['selected_probability'])
            errors['max_probability_reconstruction_error'] = max(errors['max_probability_reconstruction_error'], e)
            assert e < 8e-6
        for v in r['vectors']:
            path = EXPORT / 'artifacts' / v['file']
            assert sha(path) == v['sha256']
            with np.load(path, allow_pickle=False) as a:
                x = {k: a[k] for k in a.files}
            for j, p in enumerate(x['positions']):
                t = r['trace'][int(p)]
                assert x['selected'][0, j] == t['selected'] and x['fixed'][0, j] == t['requested_gate']
            raw = x['z'].astype(np.float64) @ w['e'] + w['bias'][0]
            e = float(np.max(np.abs(raw - x['raw'])))
            errors['max_gate_score_absolute_error'] = max(errors['max_gate_score_absolute_error'], e)
            assert np.allclose(raw, x['raw'], atol=3e-5, rtol=3e-5)
            gate = np.where((raw > w['theta'][0]) & (raw > 0), raw, 0.)
            assert np.allclose(gate, x['gate'], atol=3e-5, rtol=3e-5)
            operator = (x['z'].astype(np.float64) @ w['V'] @ w['U']) * w['output_std']
            e = float(np.linalg.norm(operator - x['operator']) / max(np.linalg.norm(operator), 1e-12))
            errors['max_operator_relative_l2_error'] = max(errors['max_operator_relative_l2_error'], e)
            assert e < 1e-4
            delta = np.where(x['selected'][..., None], np.float32(v['alpha']) * (x['fixed'] - x['gate'])[..., None] * x['operator'], 0.)
            assert np.array_equal(delta, x['intended_delta'])
            assert np.array_equal(bf16_round(x['native_mlp'] + delta), x['edited_mlp'])
            assert np.array_equal(x['edited_mlp'] - x['native_mlp'], x['actual_delta'])
            assert np.array_equal(x['edited_mlp'][~x['selected']], x['native_mlp'][~x['selected']])
            counts['vector_files'] += 1
            counts['vector_positions'] += x['gate'].size

    native = {}
    control_rows = []
    for row in d['controls']:
        cid = row['case_id']
        native[cid] = row['first']
        prior = next(o for o in old['controls'] if o['case_id'] == cid)
        for phase, prior_key in [('first', 'first'), ('eleventh', 'eleventh')]:
            a, b = row[phase], row[f'zero_{phase}']
            audit(a); audit(b)
            assert a['steps'] == b['steps'] and a['output_token_ids'] == b['output_token_ids'] == prior[prior_key]['output_token_ids']
            assert [[s[k] for k in ['selected_probability', 'selected_logit', 'logsumexp']] for s in a['steps']] == [[s[k] for k in ['selected_probability', 'selected_logit', 'logsumexp']] for s in prior[prior_key]['steps']]
        control_rows.append({'case_id': cid, 'first_prompt': row['first']['prompt'], 'first_answer': row['first']['answer'],
                             'eleventh_prompt': row['eleventh']['prompt'], 'eleventh_answer': row['eleventh']['answer'],
                             'aligned_active_tokens': plan['cases'][cid]['mapped_active_tokens'],
                             'unmapped_active_tokens': plan['cases'][cid]['unmapped_active_tokens']})
    rows = []
    all_conditions = d['runs'] + refinement['runs'] + refinement['long_continuations'] + narrow['runs'] + confirmation['runs'] + final['runs']
    for r in all_conditions:
        audit(r)
        if r['screen'] in ['predeclared_screen', 'zero_gate_control']:
            assert r['spec'] == plan['cases'][r['case_id']]['masks'][r['mask_name']]
        if r['screen'] == 'zero_gate_control':
            assert r['output_token_ids'] == native[r['case_id']]['output_token_ids'] and r['steps'] == native[r['case_id']]['steps']
        if r['spec']['kind'] == 'output':
            assert r['steps'][0] == native[r['case_id']]['steps'][0]
        rows.append({'case_id': r['case_id'], 'mask': r['mask_name'], 'screen': r['screen'], 'gate': r['target'],
                     'selected_position_count': sum(t['selected'] for t in r['trace']),
                     'output_tokens': len(r['output_token_ids']), 'answer': r['answer'], 'stop': r['stop_reason'], **r['assessment']})
    for r in d['repeats'] + refinement['repeats'] + narrow['repeats'] + final['repeats']:
        audit(r)
        original = native[r['case_id']] if r['repeats_name'] == 'native_first' else next(x for x in all_conditions if x['case_id'] == r['case_id'] and x['name'] == r['repeats_name'])
        assert r['steps'] == original['steps'] and r['output_token_ids'] == original['output_token_ids'] and r['trace'] == original['trace']
    summary = []
    for case in cases:
        p = plan['cases'][case['id']]
        for name in p['masks']:
            selected = [r for r in rows if r['case_id'] == case['id'] and r['mask'] == name and r['screen'] == 'predeclared_screen']
            assert [r['gate'] for r in selected] == d['protocol']['strengths']
            summary.append({'case_id': case['id'], 'mask': name, 'conditions': len(selected),
                            'screen': 'predeclared_screen',
                            'clean_target_values': [r['gate'] for r in selected if r['exact_clean_target']],
                            'target_mention_values': [r['gate'] for r in selected if r['target_mentioned']],
                            'clean_original_values': [r['gate'] for r in selected if r['exact_clean_original']],
                            'truncated_values': [r['gate'] for r in selected if r['truncated']]})
        for name, kind, count in refinement['specifications'][case['id']]:
            selected = [r for r in rows if r['case_id'] == case['id'] and r['mask'] == name and r['screen'] == 'adaptive_prefix_cutoff']
            assert [r['gate'] for r in selected] == refinement['strengths']
            n = p['prompt_length']
            positions = list(range(n)) if kind == 'input' else p['masks']['query_only']['positions']
            for r in refinement['runs']:
                if r['case_id'] == case['id'] and r['mask_name'] == name:
                    assert r['spec'] == {'kind': 'positions', 'positions': positions + list(range(n, n + count))}
            summary.append({'case_id': case['id'], 'mask': name, 'screen': 'adaptive_prefix_cutoff',
                            'conditions': len(selected), 'clean_target_values': [r['gate'] for r in selected if r['exact_clean_target']],
                            'target_mention_values': [r['gate'] for r in selected if r['target_mentioned']],
                            'clean_original_values': [r['gate'] for r in selected if r['exact_clean_original']],
                            'truncated_values': [r['gate'] for r in selected if r['truncated']]})
    for r in refinement['long_continuations']:
        original = next(x for x in d['runs'] if x['case_id'] == r['case_id'] and x['mask_name'] == r['mask_name'] and x['target'] == r['target'])
        assert r['output_token_ids'][:len(original['output_token_ids'])] == original['output_token_ids']
    n = plan['cases']['integer']['prompt_length']
    singles = [r for r in narrow['runs'] if r['screen'] == 'adaptive_single_input_search']
    assert len(singles) == n
    for i, r in enumerate(singles):
        assert r['spec'] == {'kind': 'positions', 'positions': [i, n]} and r['target'] == 90
    successful_singletons = [i for i, r in enumerate(singles) if r['assessment']['exact_clean_target']]
    assert successful_singletons == narrow['selection']['successful_singletons']
    if successful_singletons:
        selected_positions = [successful_singletons[0], n]
        assert not narrow['decisions']
    else:
        selected_positions = list(range(n + 1))
        assert len(narrow['decisions']) == n
        for pos, decision in enumerate(narrow['decisions']):
            assert decision['tested_removal'] == pos and decision['positions_before'] == selected_positions
            trial = [p for p in selected_positions if p != pos]
            assert decision['trial_positions'] == trial
            r = next(x for x in narrow['runs'] if x['name'] == decision['run_name'])
            assert r['spec'] == {'kind': 'positions', 'positions': trial} and r['target'] == 90
            assert decision['removed'] == r['assessment']['exact_clean_target']
            if decision['removed']:
                selected_positions = trial
    assert selected_positions == narrow['selected_positions']
    assert confirmation['selected_positions'] == selected_positions
    assert [r['omitted_position'] for r in confirmation['runs']] == selected_positions
    for r in confirmation['runs']:
        assert r['spec'] == {'kind': 'positions', 'positions': [p for p in selected_positions if p != r['omitted_position']]}
        assert r['target'] == confirmation['gate'] == narrow['lowest_successful_integer_strength_tested']
    dense = [r for r in narrow['runs'] if r['screen'] == 'adaptive_selected_mask_dense_strength']
    assert [r['target'] for r in dense] == list(range(1, 91))
    assert all(r['spec'] == {'kind': 'positions', 'positions': selected_positions} for r in dense)
    successes = [r for r in dense if r['assessment']['exact_clean_target']]
    assert min(r['target'] for r in successes) == narrow['lowest_successful_integer_strength_tested']
    first_trace = next(r for r in d['controls'] if r['case_id'] == 'integer')['zero_first']['trace']
    search_summary = {'selection': narrow['selection'], 'selected_positions': selected_positions,
                      'selected_tokens': [{k: first_trace[p][k] for k in ['position', 'phase', 'token', 'token_id', 'natural_gate']} for p in selected_positions],
                      'lowest_successful_integer_strength_tested': narrow['lowest_successful_integer_strength_tested'],
                      'exact_target_values': [r['target'] for r in successes],
                      'component_controls': [{'name': r['name'], 'gate': r['target'], 'answer': r['answer'], 'assessment': r['assessment']} for r in narrow['runs'] if r['screen'] == 'selected_mask_component_control'],
                      'search_runs': len(narrow['runs']), 'single_input_tests': len(singles), 'greedy_pruning_tests': len(narrow['decisions']),
                      'dense_strength_tests': len(dense), 'global_minimal_token_set_claim': False}
    search_summary['final_leave_one_out'] = [{'omitted_position': r['omitted_position'], 'answer': r['answer'],
                                             'gate': r['target'], 'assessment': r['assessment']} for r in confirmation['runs']]
    search_summary['initial_greedy_mask'] = {k: search_summary[k] for k in ['selected_positions', 'selected_tokens', 'lowest_successful_integer_strength_tested', 'exact_target_values']}
    final_positions = min((r['spec']['positions'] for r in confirmation['runs'] if r['assessment']['exact_clean_target']), key=lambda x: (len(x), x))
    assert final['initial_positions'] == final_positions
    for decision in final['decisions']:
        assert decision['positions_before'] == final_positions
        trial = [p for p in final_positions if p != decision['removed_position']]
        assert decision['trial_positions'] == trial
        r = next(x for x in final['runs'] if x['name'] == decision['run_name'])
        assert r['spec'] == {'kind': 'positions', 'positions': trial} and r['target'] == 90
        assert decision['removed'] == r['assessment']['exact_clean_target']
        if decision['removed']:
            final_positions = trial
    assert final_positions == final['selected_positions']
    last_pass = max(x['pass'] for x in final['decisions'])
    last_deletions = [x for x in final['decisions'] if x['pass'] == last_pass]
    assert [x['removed_position'] for x in last_deletions] == final_positions and all(not x['removed'] for x in last_deletions)
    dense_final = [r for r in final['runs'] if r['screen'] == 'final_mask_dense_strength']
    assert [r['target'] for r in dense_final] == list(range(1, 91))
    assert all(r['spec'] == {'kind': 'positions', 'positions': final_positions} for r in dense_final)
    final_successes = [r for r in dense_final if r['assessment']['exact_clean_target']]
    best = min(r['target'] for r in final_successes)
    assert best == final['lowest_successful_integer_strength_tested']
    search_summary.update(selected_positions=final_positions,
                          selected_tokens=[{k: first_trace[p][k] for k in ['position', 'phase', 'token', 'token_id', 'natural_gate']} for p in final_positions],
                          exact_target_values=[r['target'] for r in final_successes], lowest_successful_integer_strength_tested=best,
                          final_search_runs=len(final['runs']), final_selection_method=final['protocol'],
                          final_single_deletion_controls=[{'omitted_position': x['removed_position'], 'answer': next(r['answer'] for r in final['runs'] if r['name'] == x['run_name']), 'clean_target': x['removed']} for x in last_deletions])
    validation = {'status': 'passed', 'unique_nonempty_primary_masks': sum(s['screen'] == 'predeclared_screen' for s in summary),
                  'predeclared_steering_comparisons': sum(s['conditions'] for s in summary if s['screen'] == 'predeclared_screen'),
                  'adaptive_prefix_cutoff_comparisons': len(refinement['runs']), 'longer_continuations': len(refinement['long_continuations']),
                  'adaptive_token_search_comparisons_including_component_controls': len(narrow['runs']),
                  'final_leave_one_out_comparisons': len(confirmation['runs']),
                  'final_reduced_mask_search_comparisons': len(final['runs']),
                  'zero_gate_controls': sum(r['screen'] == 'zero_gate_control' for r in rows),
                  'natural_value_replays': sum(r['screen'] == 'natural_value_replay' for r in rows),
                  'fresh_native_control_pairs': len(cases), 'native_and_zero_controls_exact': True,
                  'fresh_native_matches_previous_controls_exactly': True, 'all_repeats_exact': True,
                  'sampled_BF16_edits_exact': True, 'unselected_local_MLP_outputs_bit_exact': True,
                  'hooks_remaining': 0, **counts, **errors}
    for name, data in [('validation.json', validation), ('summary.json', summary), ('responses.json', rows), ('controls.json', control_rows), ('token-search.json', search_summary)]:
        (OUT / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')
    with (OUT / 'responses.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]), lineterminator='\n')
        writer.writeheader(); writer.writerows(rows)
    candidates = [r for r in rows if r['target_mentioned']]
    # Full candidate texts are retained for manual coherence review.
    (OUT / 'candidate-review.json').write_text(json.dumps(candidates, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps({'validation': validation, 'summary': summary}, indent=2))


if __name__ == '__main__':
    main()
