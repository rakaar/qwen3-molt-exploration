import contextlib
import runpy
import traceback

with open('/workspace/water-selective-20261028/narrow.log', 'w', buffering=1) as selective_narrow_log:
    with contextlib.redirect_stdout(selective_narrow_log), contextlib.redirect_stderr(selective_narrow_log):
        try:
            selective_narrow_ns = runpy.run_path('/workspace/water-selective-20261028/narrow.py')
            selective_narrow = selective_narrow_ns['run_narrow'](selective_engine, selective_refinement)
        except BaseException:
            traceback.print_exc()
            raise
