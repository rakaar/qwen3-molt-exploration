"""Adaptive prefix-cutoff tests after sparse masks failed to give clean targets."""
import json
import hashlib
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    temp.replace(path)


def run_refinement(engine, parent):
    assert parent['status'] == 'complete'
    out = ROOT / 'artifacts'
    assert not (out / 'refinement.json').exists()
    engine.started = time.monotonic()
    specifications = {'integer': [('input_plus_first_output', 'input', 1), ('query_plus_first_output', 'query', 1)],
                      'roman': [('input_plus_first_output', 'input', 1), ('input_plus_first_four_output', 'input', 4)],
                      'month': [('input_plus_first_eight_output', 'input', 8)]}
    result = {'status': 'running', 'started_at_utc': datetime.now(timezone.utc).isoformat(),
              'parent_sha256': sha(out / 'results.json'), 'source_sha256': sha(ROOT / 'refine.py'),
              'reason': 'Adaptive follow-up after all sparse masks produced zero clean targets: keep the original all-input intervention but stop early in generation, plus a query-and-first-output variant for integers. Test the same complete strength grid. Separately allow three sparse November continuations to finish at 192 tokens.',
              'specifications': specifications, 'strengths': engine.protocol['strengths'],
              'runs': [], 'long_continuations': [], 'repeats': []}
    for target in result['strengths']:
        for case in engine.cases:
            plan = engine.plan['cases'][case['id']]
            n = plan['prompt_length']
            for name, kind, count in specifications[case['id']]:
                positions = list(range(n)) if kind == 'input' else plan['masks']['query_only']['positions']
                spec = {'kind': 'positions', 'positions': positions + list(range(n, n + count))}
                run = engine.run(case, case['first_prompt'], f'{name}--gate-{target}', spec=spec, target=target, audit=True)
                run['mask_name'], run['screen'] = name, 'adaptive_prefix_cutoff'
                result['runs'].append(run)
                if run['assessment']['target_mentioned']:
                    print('PREFIX_CANDIDATE', case['id'], name, target, 'clean', run['assessment']['exact_clean_target'], 'stop', run['stop_reason'], flush=True)
            save(out / 'refinement.json', result)
        print('PREFIX_GATE_COMPLETE', target, flush=True)
    month = next(c for c in engine.cases if c['id'] == 'month')
    old_budget = engine.protocol['max_new_tokens']
    try:
        engine.protocol['max_new_tokens'] = 192
        for name, target in [('donor_active_union', 57), ('donor_active_output', 60), ('answer_predecessor_only', 80)]:
            original = next(r for r in parent['runs'] if r['case_id'] == 'month' and r['mask_name'] == name and r['target'] == target)
            run = engine.run(month, month['first_prompt'], f'long-{name}--gate-{target}', spec=original['spec'], target=target, audit=True)
            assert run['output_token_ids'][:len(original['output_token_ids'])] == original['output_token_ids']
            run['mask_name'], run['screen'] = name, '192_token_continuation'
            result['long_continuations'].append(run)
            save(out / 'refinement.json', result)
            print('LONG_CONTINUATION', name, target, run['stop_reason'], len(run['output_token_ids']), flush=True)
    finally:
        engine.protocol['max_new_tokens'] = old_budget
    for case in engine.cases:
        candidates = [r for r in result['runs'] if r['case_id'] == case['id'] and r['assessment']['exact_clean_target']]
        selected = candidates[:2] or [next(r for r in result['runs'] if r['case_id'] == case['id'] and r['target'] == 90)]
        for i, original in enumerate(selected):
            repeat = engine.run(case, case['first_prompt'], f'prefix-repeat-{i}', spec=original['spec'], target=original['target'], audit=True)
            assert repeat['steps'] == original['steps'] and repeat['trace'] == original['trace'] and repeat['output_token_ids'] == original['output_token_ids']
            repeat['repeats_name'] = original['name']
            result['repeats'].append(repeat)
    result.update(status='complete', finished_at_utc=datetime.now(timezone.utc).isoformat(), hooks_remaining=engine.hooks())
    save(out / 'refinement.json', result)
    print('PREFIX_COMPLETE', len(result['runs']), 'conditions', flush=True)
    return result
