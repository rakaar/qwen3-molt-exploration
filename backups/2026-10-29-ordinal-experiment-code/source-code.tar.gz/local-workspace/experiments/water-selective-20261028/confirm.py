"""Leave-one-position-out checks on the adaptively selected integer mask."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'artifacts'


def run_confirmation(engine, narrow):
    assert narrow['status'] == 'complete' and not (OUT / 'confirmation.json').exists()
    case = next(c for c in engine.cases if c['id'] == 'integer')
    positions = narrow['selected_positions']
    target = narrow['lowest_successful_integer_strength_tested']
    d = {'status': 'running', 'selected_positions': positions, 'gate': target,
         'parent_sha256': hashlib.sha256((OUT / 'narrow.json').read_bytes()).hexdigest(),
         'source_sha256': hashlib.sha256((ROOT / 'confirm.py').read_bytes()).hexdigest(), 'runs': []}
    for pos in positions:
        r = engine.run(case, case['first_prompt'], f'final-drop-{pos}',
                       spec={'kind': 'positions', 'positions': [p for p in positions if p != pos]}, target=target, audit=True)
        r['mask_name'], r['screen'], r['omitted_position'] = r['name'], 'final_mask_leave_one_out', pos
        d['runs'].append(r)
        print('FINAL_DROP', pos, 'clean', r['assessment']['exact_clean_target'], 'answer', json.dumps(r['answer']), flush=True)
    d.update(status='complete', finished_at_utc=datetime.now(timezone.utc).isoformat(), hooks_remaining=engine.hooks())
    (OUT / 'confirmation.json').write_text(json.dumps(d, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    return d
