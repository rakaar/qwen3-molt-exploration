"""Execute inside the persistent Python REPL that owns the loaded model."""
import contextlib
import runpy
import traceback

with open('/workspace/water-selective-20261028/run.log', 'w', buffering=1) as selective_log:
    with contextlib.redirect_stdout(selective_log), contextlib.redirect_stderr(selective_log):
        try:
            selective_ns = runpy.run_path('/workspace/water-selective-20261028/run.py')
            selective_engine, selective_results = selective_ns['run_experiment'](model, tokenizer)
        except BaseException:
            traceback.print_exc()
            raise
