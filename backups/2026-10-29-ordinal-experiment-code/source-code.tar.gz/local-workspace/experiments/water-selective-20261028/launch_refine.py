import contextlib
import runpy
import traceback

with open('/workspace/water-selective-20261028/refine.log', 'w', buffering=1) as selective_refine_log:
    with contextlib.redirect_stdout(selective_refine_log), contextlib.redirect_stderr(selective_refine_log):
        try:
            selective_refine_ns = runpy.run_path('/workspace/water-selective-20261028/refine.py')
            selective_refinement = selective_refine_ns['run_refinement'](selective_engine, selective_results)
        except BaseException:
            traceback.print_exc()
            raise
