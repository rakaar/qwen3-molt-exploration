import contextlib
import traceback

with (n235_list_root / 'ablations.log').open('w', buffering=1) as n235_list_log:
    with contextlib.redirect_stdout(n235_list_log), contextlib.redirect_stderr(n235_list_log):
        try:
            n235_list_results = {}
            for feature in ['T1634', 'T1541', 'T1051']:
                print('FEATURE_ABLATIONS_BEGIN', feature, flush=True)
                n235_list_results[feature] = n235_list_namespaces[feature]['run_ablations'](n235_list_engines[feature], n235_list_controls[feature])
                assert n235_list_engines[feature].hooks() == 0
            print('ALL_FEATURE_ABLATIONS_COMPLETE', flush=True)
        except BaseException:
            traceback.print_exc()
            raise
