import contextlib
import runpy
import traceback
from pathlib import Path

n235_list_root = Path('/workspace/l29-n235-cross-domain-ablation-20261028/active-list-controls')
with (n235_list_root / 'controls.log').open('w', buffering=1) as n235_list_log:
    with contextlib.redirect_stdout(n235_list_log), contextlib.redirect_stderr(n235_list_log):
        try:
            n235_list_namespaces, n235_list_engines, n235_list_controls = {}, {}, {}
            for feature in ['T1634', 'T1541', 'T1051']:
                print('FEATURE_CONTROLS_BEGIN', feature, flush=True)
                namespace = runpy.run_path(str(n235_list_root / feature / 'run.py'))
                engine, controls = namespace['run_controls'](model, tokenizer)
                n235_list_namespaces[feature] = namespace
                n235_list_engines[feature] = engine
                n235_list_controls[feature] = controls
                assert engine.hooks() == 0
            print('ALL_FEATURE_CONTROLS_COMPLETE', flush=True)
        except BaseException:
            traceback.print_exc()
            raise
