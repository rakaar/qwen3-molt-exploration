import json,torch,transformers
from datetime import datetime,timezone
from pathlib import Path
r=Path('/workspace/l29-n235-cross-domain-ablation-20261028')
engines=list(n235_engines.values())+list(n235_list_engines.values())
hooks=sum(len(m._forward_hooks)+len(m._forward_pre_hooks) for m in model.modules())
assert hooks==0
assert all(b.self_attn.forward==f for engine in engines for b,f in zip(model.model.layers,engine.attention))
records={}
count=0
for group,controls,results in [('',n235_controls,n235_results),('active-list-controls/',n235_list_controls,n235_list_results)]:
 for feature,ctl in controls.items():
  res=results[feature]
  assert ctl['status']==res['status']=='complete' and ctl['hooks_remaining']==res['hooks_remaining']==0
  runs=sum(len(pair) > 0 and 2 for row in ctl['controls'] for pair in row['ordinals'].values())+len(res['runs'])+len(res['specificity_controls'])+len(res['repeats'])
  count+=runs
  records[group+feature]={'runs':runs,'native_anchor_checks':ctl['anchor_checks'],'initial_changes':[{'case_id':x['case_id'],'scope':x['scope'],'answer':x['answer']} for x in res['runs'] if not x['assessment']['first_matches_expected']]}
assert count==390
d={'saved_at_utc':datetime.now(timezone.utc).isoformat(),'hooks_remaining':hooks,'attention_unchanged':True,'model_name_or_path':model.config._name_or_path,'model_config_commit_hash':getattr(model.config,'_commit_hash',None),'model_dtype':str(next(model.parameters()).dtype),'model_training':model.training,'attention_implementation':getattr(model.config,'_attn_implementation',None),'torch':torch.__version__,'transformers':transformers.__version__,'completed_runs':count,'studies':records,'isolation':'Only one feature hooked at a time; no joint edits.','base_identity_note':'Inherited earlier SHA-verified local loading; no new whole-base hash. Saved native anchors match tokens/core scores/shared probabilities exactly.'}
(r/'final-runtime.json').write_text(json.dumps(d,indent=2)+'\n')
for rel in records:(r/rel/'artifacts/final-runtime.json').write_text(json.dumps(d,indent=2)+'\n')
