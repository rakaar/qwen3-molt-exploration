import contextlib
import runpy
import traceback
from pathlib import Path

n235_root = Path('/workspace/l29-n235-cross-domain-ablation-20261028')
with (n235_root / 'controls.log').open('w', buffering=1) as n235_log:
    with contextlib.redirect_stdout(n235_log), contextlib.redirect_stderr(n235_log):
        try:
            n235_namespaces, n235_engines, n235_controls = {}, {}, {}
            for feature in ['T1634', 'T1541', 'T1051']:
                print('FEATURE_CONTROLS_BEGIN', feature, flush=True)
                namespace = runpy.run_path(str(n235_root / feature / 'run.py'))
                engine, controls = namespace['run_controls'](model, tokenizer)
                n235_namespaces[feature] = namespace
                n235_engines[feature] = engine
                n235_controls[feature] = controls
                assert engine.hooks() == 0
            print('ALL_FEATURE_CONTROLS_COMPLETE', flush=True)
        except BaseException:
            traceback.print_exc()
            raise
