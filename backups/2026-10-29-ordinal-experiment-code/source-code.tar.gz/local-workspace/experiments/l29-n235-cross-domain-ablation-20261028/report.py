"""Read completed isolated studies and produce a private combined report."""
import csv
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
OUT = WORKSPACE / 'results/2026-10-28-l29-n235-cross-domain-ablation'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def first_match(case, answer):
    found=[]
    if case['kind']=='number':
        found += [(m.start(),-len(m.group()),m.group(),m.end()) for m in re.finditer(r'(?<![A-Za-z0-9])[-+]?\d+(?![A-Za-z0-9])',answer)]
    for canonical,aliases in case['aliases'].items():
        for alias in aliases:
            pattern=r'(?<![A-Za-z0-9])'+re.escape(alias)+r'(?![A-Za-z0-9])'
            found += [(m.start(),-len(m.group()),canonical,m.end()) for m in re.finditer(pattern,answer,re.I)]
    return min(found) if found else None


def events_before_answer(case, native, observed):
    match=first_match(case,native['answer'])
    if match is None:
        return [],None
    text=''
    for index,step in enumerate(native['steps']):
        text += step['token']
        if len(text)>=match[3]:
            size=len(native['prompt_token_ids'])
            return [t for t in observed['trace'] if t['natural_gate']>0 and t['position']<size+index],index
    raise AssertionError('Answer character/token alignment failed')


def main():
    OUT.mkdir(exist_ok=True)
    study=json.loads((ROOT/'study.json').read_text())
    summaries=[]
    case_rows=[]
    response_rows=[]
    source_hashes={}
    totals={}
    for feat in study['features']:
        name=feat['directory']; r=ROOT/name; n=feat['target_ordinal']
        def load(rel):
            p=r/rel;source_hashes[str(p.relative_to(ROOT))]=digest(p);return json.loads(p.read_text())
        protocol=load('protocol.json');cases={c['id']:c for c in load('cases.json')}
        controls=load('artifacts/controls.json');results=load('artifacts/results.json');review=load('eligibility.json');audit=load('artifacts/audit.json')
        load('ground-truth.json');load('weights/manifest.json');load('baseline-reference.json')
        assert controls['status']==results['status']=='complete' and audit['status']=='passed'
        by_id={row['case_id']:row for row in controls['controls']};decisions={row['case_id']:row for row in review['cases']}
        rows=[]
        overrides=load('scoring-review.json') if (r/'scoring-review.json').exists() else {'runs':[]}
        override_by_name={(x['case_id'],x['name']):x for x in overrides['runs']}
        for cid,case in cases.items():
            pair=by_id[cid]['ordinals'][str(n)];native=pair['native'];valid=decisions[cid]['eligible'][str(n)]
            off=[x for x in results['runs'] if x['case_id']==cid]
            events,answer_step=events_before_answer(case,native,pair['zero_strength']) if decisions[cid]['native_initial_answers'][str(n)] is not None else ([],None)
            answers={}
            for x in off:
                if (cid,x['name']) in override_by_name:
                    choice=override_by_name[(cid,x['name'])];assert choice['answer_sha256']==hashlib.sha256(x['answer'].encode()).hexdigest();answers[x['scope']]=choice['initial_answer']
                else:answers[x['scope']]=x['assessment']['first_recognized_answer']
            if not valid:outcome='excluded_native_capability'
            elif any(a==case['expected'][str(n+1)] for a in answers.values()):outcome='initial_next_ordinal_shift'
            elif any(a!=case['expected'][str(n)] for a in answers.values()):outcome='other_initial_change'
            else:outcome='active_before_answer_unchanged' if events else 'inactive_before_answer_unchanged'
            row={'feature':name,'layer':29,'transform':feat['transform'],'domain':cid,'label':case['label'],'target_ordinal':n,
                 'expected':case['expected'][str(n)],'next_expected':case['expected'][str(n+1)],'prompt':native['prompt'],
                 'eligible':valid,'native_initial_answer':decisions[cid]['native_initial_answers'][str(n)],
                 'native_next_initial_answer':decisions[cid]['native_initial_answers'][str(n+1)],'native_answer':native['answer'],
                 'native_next_answer':by_id[cid]['ordinals'][str(n+1)]['native']['answer'],
                 'native_events_before_answer':events,'answer_completion_token_step':answer_step,'off_initial_answers':answers,
                 'off_full_texts':{x['scope']:x['answer'] for x in off},'full_text_matches_native':{x['scope']:x['answer']==native['answer'] for x in off},
                 'nonzero_edits':{x['scope']:[t for t in x['trace'] if t['actual_delta_norm']>0] for x in off},'outcome':outcome,
                 'native_review_note':decisions[cid]['review_note']}
            rows.append(row);case_rows.append(row)
        for row in controls['controls']:
            for ordinal,pair in row['ordinals'].items():
                for kind,key in [('native','native'),('zero_strength','zero_strength')]:
                    run=pair[key];response_rows.append({'feature':name,'kind':kind,'domain':run['case_id'],'ordinal':run['ordinal'],'scope':run.get('scope'),'name':run['name'],'prompt':run['prompt'],'answer':run['answer'],'stop_reason':run['stop_reason']})
        for key,kind in [('runs','ablation'),('specificity_controls','specificity'),('repeats','repeat')]:
            for run in results[key]:response_rows.append({'feature':name,'kind':kind,'domain':run['case_id'],'ordinal':run['ordinal'],'scope':run.get('scope'),'name':run['name'],'prompt':run['prompt'],'answer':run['answer'],'stop_reason':run['stop_reason']})
        outcome_counts={k:sum(row['outcome']==k for row in rows) for k in sorted(set(row['outcome'] for row in rows))}
        summary={'feature':name,'target_ordinal':n,'next_ordinal':n+1,'protocol':protocol,'cases':rows,'audit':audit,'outcome_counts':outcome_counts,'native_review':review}
        summaries.append(summary)
        for key,value in audit['counts'].items():totals[key]=totals.get(key,0)+value
        totals['verified_remote_hashes']=totals.get('verified_remote_hashes',0)+audit['independent_transfer_hashes_checked']
    main_counts=dict(totals)
    list_summaries=[]
    for feat in study['features']:
        name=feat['directory'];r=ROOT/'active-list-controls'/name;n=feat['target_ordinal']
        def load_extra(rel):
            p=r/rel;source_hashes[str(p.relative_to(ROOT))]=digest(p);return json.loads(p.read_text())
        cases_extra=load_extra('cases.json');case=cases_extra[0]
        ctl=load_extra('artifacts/controls.json');res=load_extra('artifacts/results.json');rev=load_extra('eligibility.json');aud=load_extra('artifacts/audit.json')
        load_extra('protocol.json');load_extra('weights/manifest.json');load_extra('ground-truth.json');load_extra('baseline-reference.json')
        assert aud['status']=='passed' and ctl['status']==res['status']=='complete'
        pair=ctl['controls'][0]['ordinals'][str(n)];decision=rev['cases'][0];native=pair['native']
        events,slot=events_before_answer(case,native,pair['zero_strength'])
        answers={x['scope']:x['assessment']['first_recognized_answer'] for x in res['runs']}
        outcome='initial_next_ordinal_shift' if any(a==str(n+1) for a in answers.values()) else ('other_initial_change' if any(a!=str(n) for a in answers.values()) else 'active_before_answer_unchanged')
        row={'feature':name,'layer':29,'transform':feat['transform'],'domain':'numbered-list','label':case['label'],'target_ordinal':n,'expected':str(n),'next_expected':str(n+1),'prompt':native['prompt'],
             'eligible':decision['eligible'][str(n)],'native_initial_answer':decision['native_initial_answers'][str(n)],'native_next_initial_answer':decision['native_initial_answers'][str(n+1)],
             'native_answer':native['answer'],'native_next_answer':ctl['controls'][0]['ordinals'][str(n+1)]['native']['answer'],'native_events_before_answer':events,'answer_completion_token_step':slot,
             'off_initial_answers':answers,'off_full_texts':{x['scope']:x['answer'] for x in res['runs']},'outcome':outcome,'native_review_note':decision['review_note']}
        case_rows.append(row);list_summaries.append({'feature':name,'case':row,'audit':aud})
        for ordinal,p in ctl['controls'][0]['ordinals'].items():
            for kind,key in [('native','native'),('zero_strength','zero_strength')]:
                run=p[key];response_rows.append({'feature':name,'kind':kind,'domain':run['case_id'],'ordinal':run['ordinal'],'scope':run.get('scope'),'name':run['name'],'prompt':run['prompt'],'answer':run['answer'],'stop_reason':run['stop_reason']})
        for key,kind in [('runs','ablation'),('specificity_controls','specificity'),('repeats','repeat')]:
            for run in res[key]:response_rows.append({'feature':name,'kind':kind,'domain':run['case_id'],'ordinal':run['ordinal'],'scope':run.get('scope'),'name':run['name'],'prompt':run['prompt'],'answer':run['answer'],'stop_reason':run['stop_reason']})
        for key,value in aud['counts'].items():totals[key]=totals.get(key,0)+value
        totals['verified_remote_hashes']+=aud['independent_transfer_hashes_checked']
    assert len(response_rows)==totals['runs']
    probability_examples=json.loads((ROOT/'token-probability-comparisons.json').read_text())
    source_hashes['token-probability-comparisons.json']=digest(ROOT/'token-probability-comparisons.json')
    overlap=json.loads((ROOT/'native-overlap-check.json').read_text())
    source_hashes['native-overlap-check.json']=digest(ROOT/'native-overlap-check.json')
    summary={'study':study,'features':summaries,'active_numbered_list_controls':list_summaries,'question_prefix_audit_counts':main_counts,'combined_audit_counts':totals,'source_sha256':source_hashes,'token_probability_examples':probability_examples,'native_overlap_check':overlap,
             'notes':['All three transforms are tested separately; no joint ablation.', 'Initial completions are the scored outcome. Longer raw continuations may contain errors.', 'Native N and N+1 both must be initially correct, manually reviewed before ablation.', 'Trials include deterministic controls/repeats; do not interpret the run count as independent statistical samples.']}
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    with (OUT/'cases.csv').open('w',newline='') as stream:
        fields=['feature','domain','target_ordinal','expected','next_expected','eligible','native_initial_answer','native_next_initial_answer','prompt','outcome','native_events_before_answer','off_initial_answers','native_answer','native_next_answer','off_full_texts','native_review_note']
        writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
        for row in case_rows:writer.writerow({k:json.dumps(row[k],ensure_ascii=False) if isinstance(row[k],(dict,list)) else row[k] for k in fields})
    with (OUT/'responses.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=['feature','kind','domain','ordinal','scope','name','prompt','answer','stop_reason']);writer.writeheader();writer.writerows(response_rows)
    overview=[];sections=[]
    for feat in summaries:
        name=feat['feature'];n=feat['target_ordinal'];rows=feat['cases'];eligible=sum(x['eligible'] for x in rows)
        shifts=[x['label'] for x in rows if x['outcome']=='initial_next_ordinal_shift'];other=[x['label'] for x in rows if x['outcome']=='other_initial_change']
        overview.append(f"| L29–{name} | {n} / {n+1} | {eligible}/10 | {', '.join(shifts) or 'none'} | {', '.join(other) or 'none'} |")
        lines=[]
        for row in rows:
            active='; '.join(f"{t['token']!r} at {t['position']} ({t['natural_gate']:.6f})" for t in row['native_events_before_answer']) or 'none before answer'
            native=f"{row['native_initial_answer'] or 'unvalidated'} / {row['native_next_initial_answer'] or 'unvalidated'}"
            answers=' / '.join(str(row['off_initial_answers'].get(scope,'excluded')) for scope in feat['protocol']['scopes'])
            lines.append(f"| {row['label']} | {row['expected']} / {row['next_expected']} | {native} | {active} | {answers} |")
        changed=[]
        for row in rows:
            if row['outcome'] in ['initial_next_ordinal_shift','other_initial_change']:
                changed += [f"### {row['label']}: changed initial answer\n\nExact raw prefix: `{row['prompt']}`\n\nNative:\n\n```text\n{row['native_answer']}\n```\n"]
                for scope,text in row['off_full_texts'].items():changed.append(f"{scope}:\n\n```text\n{text}\n```\n")
        exclusions='\n'.join(f"- {x['label']}: native initial answers {x['native_initial_answer'] or 'unvalidated'} / {x['native_next_initial_answer'] or 'unvalidated'}, versus required {x['expected']} / {x['next_expected']}. The paired capability criterion fails; the full continuations and review notes are retained in the CSV/JSON." for x in rows if not x['eligible']) or 'None.'
        rlink=f'../../experiments/l29-n235-cross-domain-ablation-20261028/{name}'
        sections.append(f"## L29–{name}: ordinal {n} → {n+1}\n\n| Task | Correct N / N+1 | Native N / N+1 | Native gates before answer completion | Off: all / input / final input / output |\n| --- | --- | --- | --- | --- |\n"+'\n'.join(lines)+f"\n\nExcluded comparisons:\n\n{exclusions}\n\n"+'\n'.join(changed)+f"\nSources: [controls]({rlink}/artifacts/controls.json), [results]({rlink}/artifacts/results.json), [eligibility]({rlink}/eligibility.json), [CPU audit]({rlink}/artifacts/audit.json), [protocol]({rlink}/protocol.json).\n")
    overview='\n'.join(overview)
    count_rows='\n'.join(f"| {f['feature']} | {f['audit']['counts']['runs']} | {f['audit']['counts']['vector_files']} | {f['audit']['counts']['vector_positions']} | {f['audit']['independent_transfer_hashes_checked']} |" for f in summaries)
    count_rows+='\n'+'\n'.join(f"| {f['feature']} numbered-list control | {f['audit']['counts']['runs']} | {f['audit']['counts']['vector_files']} | {f['audit']['counts']['vector_positions']} | {f['audit']['independent_transfer_hashes_checked']} |" for f in list_summaries)
    list_rows=[]
    for item in list_summaries:
        row=item['case'];n=row['target_ordinal'];active='; '.join(f"{t['token']!r} at {t['position']}: {t['natural_gate']:.6f}" for t in row['native_events_before_answer']) or 'none'
        answers=' / '.join(str(row['off_initial_answers'][s]) for s in ['all_positions','input_only','last_input_only','output_only'])
        list_rows.append(f"| {item['feature']} | {row['native_initial_answer']} / {row['native_next_initial_answer']} | {active} | {answers} |")
    active_lists='\n'.join(list_rows)
    probability_rows='\n'.join(f"| {p['domain']} | `{p['shared_native_prefix_text']!r}` | `{token}` | {p['native_percent'][i]:.4f}% | {p['all_off_percent'][i]:.4f}% |" for p in probability_examples['T1051'] if p['domain']!='month' for i,token in enumerate(p['tokens']))
    readme=f'''# Separate cross-domain gate-off tests: L29–T1634, T1541, T1051

28 October 2026. Layer, transform and token positions are zero-based. Private local results; no publication or GPU lifecycle action was performed.

Each gate was tested **separately** on the same ten raw-prefix task families as T2397: months, US presidents, English letters, elements, positive integers, Roman numerals, primes, squares, triangular numbers and an explicit ordered list. Native answers for **both N and N+1** were manually checked and hash-bound before ablation. Incorrect or unvalidated native pairs were excluded.

| Gate | Native ordinal pair required | Eligible task families | Initial next-ordinal shifts | Other initial changes |
| --- | --- | ---: | --- | --- |
{overview}

There are {totals['runs']} completed runs: {main_counts['runs']} in the question-prefix suite and {totals['runs']-main_counts['runs']} in the three numbered-list controls below. Runs include native/zero controls, four ablation scopes, first/next-ordinal specificity controls and exact repeats. These conditions and repeats are not independent statistical samples. Full prompts, native capability decisions and raw continuations are preserved in [cases.csv](cases.csv), [responses.csv](responses.csv) and [summary.json](summary.json).

## Scope and scoring

The four gate-off scopes are **all input and generated positions**, **input only**, **only the final input token**, and **generated positions only**. A gate can fire on an early generated space or word fragment before the complete answer, so an inactive final input token is not enough to dismiss the all/output conditions as no-ops. The tables show native activations before completion of the initial answer; a feature can also activate later in the continuation.

The native Qwen3-4B MLP is retained. The selected feature's naturally thresholded gate times its input-dependent low-rank contribution is subtracted at selected positions. Edits use FP32 followed by one BF16 rounding. Exactly one feature is hooked per run, all hooks are removed afterward, and native attention is unchanged. No joint or increased-activation intervention was run.

We use the same raw templates, greedy decoding and 32-token cap as the expanded T2397 study. Scoring concerns the initial answer; later continuations can contain repetition, self-questioning or factual errors. Ground truth and screening distinguish second president John Adams from sixth president John Quincy Adams. A later alias mention or an unfinished count does not count as a validated native initial answer.

'''+ '\n'.join(sections)+f'''
## Active numbered-list controls

One additional numbered fruit-list continuation was tested per gate, using the exact prompt that activated it in the earlier pilot. This format was chosen from prior activation evidence before observing the current ablation outcomes. The paired native prefixes initially produce N and N+1, and the scored outcome is the initial item numeral; fruit-content quality is not scored. These controls are separate from the explicit ordered-word-list question in the ten-family suite.

| Gate | Native N / N+1 | Native gates before answer | Off: all / input / final input / output |
| --- | --- | --- | --- |
{active_lists}

Control measurements and separate CPU audits are under `experiments/l29-n235-cross-domain-ablation-20261028/active-list-controls/`; all raw responses and prompts also appear in the combined CSV/JSON above. The natural activity in these controls helps distinguish a true removal of a nonzero contribution from an inactive no-op.

## Probability effects and later text

T1051 changed answer-token probabilities without flipping the initial greedy answer. The following compares the native target-5 prompt against all-position gate-off, at the first differing token in the native-5/native-6 answer branches. The generated prefix is identical between native and ablated target-5 runs at the measured position. Values are individual next-token probabilities, not full-answer probabilities; for example ` bor` is a word fragment and a digit can begin multiple numbers.

| Task | Shared generated prefix | Token | Native | T1051 off at all positions |
| --- | --- | --- | ---: | ---: |
{probability_rows}

For Roman numerals, the lowercase ` v` token fell from 44.82% to 37.44%, while ` vi` rose from 0.44% to 0.94%; V remained the initial answer. Combining leading-space uppercase/lowercase single-token variants, V/v mass changed from **65.99% to 60.15%**, and VI/vi from **0.46% to 0.97%**. These sums exclude quoted and other formats and remain next-token masses. The element prefix ` bor` fell from 86.22% to 80.17%, while the integer-5 token fell from 86.91% to 84.24%.

One T1051 Roman output-only continuation changed after its initial V. Native continued “the fifth positive integer in base 10 is 5”; output-only ablation continued “the fifth positive integer in the sequence of prime numbers is 11.” The all-position condition retained the native greedy continuation. The initial answer stayed V while the later explanation changed. Full continuations are retained in the response CSV.

## Verification and limits

| Study | Completed runs | Vector files | Sampled vector positions | Remote file hashes verified |
| --- | ---: | ---: | ---: | ---: |
{count_rows}
| Combined | {totals['runs']} | {totals['vector_files']} | {totals['vector_positions']} | {totals['verified_remote_hashes']} |

CPU audits check exact native/zero matches, exact native and final-input-off repeats, selection masks, sampled residual standardization, thresholded gates, input-dependent operators, edit deltas, BF16 rounding, probabilities, no-op equality and independent transfer hashes. Inactive contribution removals are distinguished from active removals that leave the initial answer unchanged. First/next-ordinal specificity edits are reported separately in the raw data; they are not active unrelated or norm-matched feature controls.

Thirty overlapping unmodified native checks across feature studies matched exactly in output tokens, probabilities and text. The three gates are never edited together. The numbered-list controls were selected from earlier activation evidence, independently of their current ablation outcomes; the ten-family question suite and those controls are reported separately.

Base revision: `Qwen/Qwen3-4B@1cfa9a7208912126459214e8b04321603b3df60c`. MOLT revision: `georglange/qwen3-4b-molt@081ce901b090b64aeecf9bc8709b57c10411e32a`. Weight slices match pinned manifests. Base identity inherits the earlier SHA-verified local model load; no new whole-model file/memory hash is claimed. Earlier month/Roman native continuations also match their saved token and probability anchors exactly. The audit samples vectors rather than independently reproducing every full model forward pass on CPU.

The feature choices and templates were predetermined by the user's request and preceding experiments. These results describe the exact raw prefixes and interventions tested; they do not establish universal number-specific mechanisms or absence of effects under other prompt formats.
'''
    (OUT/'README.md').write_text(readme)
    print(json.dumps({'output':str(OUT),'completed_runs':totals['runs'],'feature_outcomes':{f['feature']:f['outcome_counts'] for f in summaries},'audit_counts':totals}))


if __name__=='__main__':
    main()
