"""Native capability and zero controls precede hash-reviewed gate-off experiments."""
import hashlib
import json
import runpy
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'artifacts'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    temp.replace(path)


def phase_case(case, ordinal):
    c = dict(case)
    c['original_expected'] = case['expected'][str(ordinal)]
    c['target_expected'] = case['expected'][str(ordinal + 1)]
    return c


def run_controls(model, tokenizer):
    OUT.mkdir(exist_ok=True)
    assert not (OUT / 'controls.json').exists()
    protocol = json.loads((ROOT / 'protocol.json').read_text())
    feature = protocol['features'][0]
    feature_key = f"L{feature['layer']}-T{feature['transform']}"
    engine = runpy.run_path(str(ROOT / 'engine.py'))['Selective'](model, tokenizer, feature_key)
    d = {'status': 'running', 'started_at_utc': datetime.now(timezone.utc).isoformat(),
         'protocol': engine.protocol, 'source_sha256': {n: sha(ROOT / n) for n in ['run.py', 'engine.py', 'protocol.json', 'cases.json', 'ground-truth.json', 'baseline-reference.json', 'weights/manifest.json']},
         'controls': [], 'anchor_checks': []}
    references = json.loads((ROOT / 'baseline-reference.json').read_text())
    for case in engine.cases:
        row = {'case_id': case['id'], 'feature_key': case['feature_key'], 'ordinals': {}}
        for ordinal in engine.protocol['native_ordinals']:
            c = phase_case(case, ordinal)
            prompt = case['prompts'][str(ordinal)]
            native = engine.run(c, prompt, f'ordinal-{ordinal}--native')
            zero = engine.run(c, prompt, f'ordinal-{ordinal}--zero', spec={'kind': 'all'}, target=0., alpha=0., audit=True)
            native['ordinal'] = zero['ordinal'] = ordinal
            assert native['steps'] == zero['steps'] and native['output_token_ids'] == zero['output_token_ids']
            row['ordinals'][str(ordinal)] = {'native': native, 'zero_strength': zero, 'answer_sha256': hashlib.sha256(native['answer'].encode()).hexdigest()}
            for ref in references:
                if ref['case_id'] == case['id'] and ref['ordinal'] == ordinal:
                    size = len(ref['output_token_ids'])
                    assert native['output_token_ids'][:size] == ref['output_token_ids']
                    for current_step, saved_step in zip(native['steps'][:size], ref['steps']):
                        assert {k:v for k,v in current_step.items() if k != 'probe_probabilities'} == {k:v for k,v in saved_step.items() if k != 'probe_probabilities'}
                        assert all(current_step['probe_probabilities'][token] == probability for token, probability in saved_step['probe_probabilities'].items())
                    d['anchor_checks'].append({'case_id': case['id'], 'ordinal': ordinal, 'source_sha256': ref['source_sha256'], 'exact_saved_token_and_probability_match': True, 'matched_steps': size})
            last = zero['trace'][len(native['prompt_token_ids']) - 1]
            print('NATIVE', case['id'], ordinal, 'expected', c['original_expected'], 'last_gate', last['natural_gate'], 'prefix', json.dumps(native['answer'][:180]), flush=True)
        d['controls'].append(row)
        save(OUT / 'controls.json', d)
    assert len(d['anchor_checks']) == len(references)
    d.update(status='complete', finished_at_utc=datetime.now(timezone.utc).isoformat(), hooks_remaining=engine.hooks())
    save(OUT / 'controls.json', d)
    print('CONTROLS_COMPLETE: manual native capability review is required before ablation.', flush=True)
    return engine, d


def run_ablations(engine, controls):
    assert controls['status'] == 'complete' and not (OUT / 'results.json').exists()
    review = json.loads((ROOT / 'eligibility.json').read_text())
    assert review['controls_sha256'] == sha(OUT / 'controls.json')
    by_id = {row['case_id']: row for row in controls['controls']}
    reviewed = {row['case_id']: row for row in review['cases']}
    engine.started = time.monotonic()
    d = {'status': 'running', 'started_at_utc': datetime.now(timezone.utc).isoformat(),
         'eligibility': review, 'controls_sha256': sha(OUT / 'controls.json'), 'source_sha256': sha(ROOT / 'run.py'),
         'runs': [], 'specificity_controls': [], 'repeats': []}
    for case in engine.cases:
        cid, decision = case['id'], reviewed[case['id']]
        for ordinal, pair in by_id[cid]['ordinals'].items():
            assert decision['answer_sha256'][ordinal] == pair['answer_sha256']
        for ordinal in engine.protocol['ablation_ordinals']:
            eligible = decision['eligible'][str(ordinal)]
            assert eligible == (decision['native_correct'][str(ordinal)] and decision['native_correct'][str(ordinal+1)])
            if not eligible:
                continue
            c = phase_case(case, ordinal)
            native = by_id[cid]['ordinals'][str(ordinal)]['native']
            size = len(native['prompt_token_ids'])
            specs = {'all_positions': {'kind': 'all'}, 'input_only': {'kind': 'input'},
                     'last_input_only': {'kind': 'positions', 'positions': [size-1]}, 'output_only': {'kind': 'output'}}
            current = {}
            for scope, spec in specs.items():
                result = engine.run(c, native['prompt'], f'ordinal-{ordinal}--off-{scope}', spec=spec, target=0., audit=True)
                result.update(scope=scope, ordinal=ordinal)
                d['runs'].append(result)
                current[scope] = result
                if scope == 'output_only':
                    assert result['steps'][0] == native['steps'][0], 'Output-only edit affected first prediction'
                print('OFF', cid, ordinal, scope, 'prefix', json.dumps(result['answer'][:180]), flush=True)
                save(OUT / 'results.json', d)
            for name, baseline in [('native-repeat', native), ('off-last-repeat', current['last_input_only'])]:
                repeated = engine.run(c, native['prompt'], f'ordinal-{ordinal}--{name}', spec=baseline['spec'], target=baseline['target'], alpha=baseline['alpha'], audit=True)
                repeated.update(ordinal=ordinal, repeats_name=baseline['name'])
                assert repeated['steps'] == baseline['steps'] and repeated['trace'] == baseline['trace'] and repeated['output_token_ids'] == baseline['output_token_ids']
                d['repeats'].append(repeated)
            save(OUT / 'results.json', d)
        if any(decision['eligible'].values()):
            for ordinal in engine.protocol['specificity_ordinals']:
                if not decision['native_correct'][str(ordinal)]:
                    continue
                native = by_id[cid]['ordinals'][str(ordinal)]['native']
                result = engine.run(phase_case(case, ordinal), native['prompt'], f'ordinal-{ordinal}--specificity-off-last', spec={'kind': 'positions', 'positions': [len(native['prompt_token_ids'])-1]}, target=0., audit=True)
                result.update(ordinal=ordinal, scope='last_input_only')
                d['specificity_controls'].append(result)
            save(OUT / 'results.json', d)
    d.update(status='complete', finished_at_utc=datetime.now(timezone.utc).isoformat(), hooks_remaining=engine.hooks())
    save(OUT / 'results.json', d)
    print('ABLATIONS_COMPLETE', len(d['runs']), 'gate-off runs', flush=True)
    return d
