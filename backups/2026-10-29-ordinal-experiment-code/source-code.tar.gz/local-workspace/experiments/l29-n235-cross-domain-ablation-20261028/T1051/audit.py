"""CPU-only validation of the complete cross-domain gate-off experiment."""
import argparse
import hashlib
import json
from pathlib import Path

from audit_support import Audit, load, require, same_completion


class CrossDomainAudit(Audit):
    def main(self):
        self.prepare_weights()
        controls = load(self.artifacts / 'controls.json')
        require(controls['status'] == 'complete' and controls['hooks_remaining'] == 0, 'Incomplete controls')
        require(controls['protocol'] == self.protocol, 'Protocol changed after controls')
        for relative, digest in controls['source_sha256'].items():
            self.check_hash(relative, digest)
        controls_hash = self.check_hash('artifacts/controls.json')
        by_id = {r['case_id']: r for r in controls['controls']}
        require(set(by_id) == set(self.cases) and len(by_id) == len(controls['controls']), 'Control coverage')
        ordinals = {str(n) for n in self.protocol['native_ordinals']}
        for cid, row in by_id.items():
            require(set(row['ordinals']) == ordinals, f'{cid}: missing native ordinal')
            for ordinal, pair in row['ordinals'].items():
                native, zero = pair['native'], pair['zero_strength']
                require(native['prompt'] == self.cases[cid]['prompts'][ordinal], f'{cid}/{ordinal}: exact prompt')
                require(native['ordinal'] == zero['ordinal'] == int(ordinal), f'{cid}: ordinal metadata')
                require(native['spec'] is None, f'{cid}: hooked native')
                require(zero['spec'] == {'kind': 'all'} and zero['alpha'] == 0 and zero['target'] == 0, f'{cid}: zero control')
                require(hashlib.sha256(native['answer'].encode()).hexdigest() == pair['answer_sha256'], f'{cid}: answer hash')
                self.run_record(native)
                self.run_record(zero)
                same_completion(native, zero, f'{cid}/{ordinal}: native zero')
                self.report['counts']['native_zero_pairs'] += 1
        anchors = load(self.root / 'baseline-reference.json')
        require(len(anchors) == len(controls['anchor_checks']) and len(anchors)>0, 'Prior baseline anchor coverage')
        for anchor in anchors:
            native = by_id[anchor['case_id']]['ordinals'][str(anchor['ordinal'])]['native']
            size = len(anchor['output_token_ids'])
            require(native['output_token_ids'][:size] == anchor['output_token_ids'], 'Prior baseline tokens changed')
            for current, previous in zip(native['steps'][:size], anchor['steps']):
                require({k:v for k,v in current.items() if k != 'probe_probabilities'} == {k:v for k,v in previous.items() if k != 'probe_probabilities'}, 'Prior baseline scores changed')
                require(all(current['probe_probabilities'][token] == value for token,value in previous['probe_probabilities'].items()), 'Prior baseline shared probes changed')
        self.report['prior_anchor_checks'] = len(anchors)
        if self.controls_only:
            self.report.update(status='passed', controls_sha256=controls_hash)
            return self.report

        results = load(self.artifacts / 'results.json')
        review = load(self.root / 'eligibility.json')
        self.check_hash('artifacts/results.json')
        self.check_hash('eligibility.json')
        self.check_hash('run.py', results['source_sha256'])
        require(results['status'] == 'complete' and results['hooks_remaining'] == 0, 'Incomplete ablations')
        require(results['eligibility'] == review, 'Eligibility file changed')
        require(results['controls_sha256'] == review['controls_sha256'] == controls_hash, 'Control hash linkage')
        decisions = {r['case_id']: r for r in review['cases']}
        require(set(decisions) == set(self.cases), 'Missing manual capability review')
        eligible = set()
        specificity = set()
        for cid, case in self.cases.items():
            decision = decisions[cid]
            require(set(decision['native_correct']) == ordinals, f'{cid}: review ordinal coverage')
            require(set(decision['answer_sha256']) == ordinals, f'{cid}: reviewed answer coverage')
            for ordinal, pair in by_id[cid]['ordinals'].items():
                require(type(decision['native_correct'][ordinal]) is bool, 'Nonboolean capability')
                require(decision['answer_sha256'][ordinal] == pair['answer_sha256'], 'Unbound capability review')
            for n in self.protocol['ablation_ordinals']:
                valid = decision['native_correct'][str(n)] and decision['native_correct'][str(n+1)]
                require(type(decision['eligible'][str(n)]) is bool and decision['eligible'][str(n)] == valid, 'Incorrect eligibility')
                if valid:
                    eligible.add((cid, n))
            if any(decision['eligible'].values()):
                specificity |= {(cid, n) for n in self.protocol['specificity_ordinals'] if decision['native_correct'][str(n)]}

        seen = set()
        for run in results['runs']:
            cid, n, scope = run['case_id'], run['ordinal'], run['scope']
            require((cid,n) in eligible, 'Ablation on ineligible native query')
            marker = (cid,n,scope)
            require(marker not in seen and scope in self.protocol['scopes'], 'Duplicate/unplanned ablation')
            seen.add(marker)
            native = by_id[cid]['ordinals'][str(n)]['native']
            specs = {'all_positions': {'kind':'all'}, 'input_only': {'kind':'input'},
                     'last_input_only': {'kind':'positions','positions':[len(native['prompt_token_ids'])-1]}, 'output_only': {'kind':'output'}}
            require(run['spec'] == specs[scope] and run['target'] == 0 and run['alpha'] == 1, 'Incorrect ablation')
            require(run['prompt'] == native['prompt'] and run['prompt_token_ids'] == native['prompt_token_ids'], 'Prompt changed')
            self.run_record(run)
            if scope == 'output_only':
                require(run['steps'][0] == native['steps'][0], 'Output-only changed first prediction')
            if not any(t['actual_delta_norm'] for t in run['trace']):
                same_completion(run,native,'All-zero local edit')
                self.report['counts']['exact_noop_comparisons'] += 1
        require(seen == {(cid,n,s) for cid,n in eligible for s in self.protocol['scopes']}, 'Ablation scope coverage')

        seen = set()
        for run in results['specificity_controls']:
            marker = (run['case_id'],run['ordinal'])
            require(marker in specificity and marker not in seen, 'Unexpected specificity control')
            seen.add(marker)
            native = by_id[marker[0]]['ordinals'][str(marker[1])]['native']
            require(run['spec'] == {'kind':'positions','positions':[len(native['prompt_token_ids'])-1]} and run['target']==0 and run['alpha']==1, 'Specificity mask')
            require(run['prompt_token_ids'] == native['prompt_token_ids'], 'Specificity prompt changed')
            self.run_record(run)
            if not any(t['actual_delta_norm'] for t in run['trace']):
                same_completion(run,native,'Specificity noop')
                self.report['counts']['exact_noop_comparisons'] += 1
        require(seen == specificity, 'Missing specificity controls')

        seen = set()
        for run in results['repeats']:
            cid,n = run['case_id'],run['ordinal']
            require((cid,n) in eligible, 'Unexpected repeat')
            native_name = f'ordinal-{n}--native'
            last_name = f'ordinal-{n}--off-last_input_only'
            require(run['repeats_name'] in [native_name,last_name], 'Unknown repeated condition')
            marker = (cid,n,run['repeats_name'])
            require(marker not in seen, 'Duplicate repeat')
            seen.add(marker)
            original = by_id[cid]['ordinals'][str(n)]['native'] if run['repeats_name']==native_name else next(r for r in results['runs'] if r['case_id']==cid and r['ordinal']==n and r['scope']=='last_input_only')
            self.run_record(run)
            same_completion(run,original,'Exact deterministic repeat',traces=True)
            self.report['counts']['exact_repeats'] += 1
        require(len(seen) == 2*len(eligible), 'Missing repeats')
        self.report.update(status='passed',controls_sha256=controls_hash,eligible_queries=len(eligible),excluded_queries=len(self.protocol['ablation_ordinals'])*len(self.cases)-len(eligible),specificity_controls=len(specificity))
        return self.report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--controls-only',action='store_true')
    parser.add_argument('--expected-hashes',type=Path)
    args = parser.parse_args()
    audit = CrossDomainAudit(args.root,args.controls_only,args.expected_hashes)
    report = audit.main()
    output = args.root / 'artifacts' / ('audit-controls.json' if args.controls_only else 'audit.json')
    output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ['status','counts','errors']},indent=2))
