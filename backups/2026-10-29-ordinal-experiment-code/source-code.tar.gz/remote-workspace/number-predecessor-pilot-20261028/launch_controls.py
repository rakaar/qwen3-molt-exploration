import contextlib
import runpy
import traceback

with open('/workspace/number-predecessor-pilot-20261028/controls.log', 'w', buffering=1) as number_log:
    with contextlib.redirect_stdout(number_log), contextlib.redirect_stderr(number_log):
        try:
            number_ns = runpy.run_path('/workspace/number-predecessor-pilot-20261028/run.py')
            number_engines, number_controls = number_ns['run_controls'](model, tokenizer)
        except BaseException:
            traceback.print_exc()
            raise
