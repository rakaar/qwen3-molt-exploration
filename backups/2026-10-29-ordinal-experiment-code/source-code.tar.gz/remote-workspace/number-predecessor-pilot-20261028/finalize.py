import json, hashlib, torch, transformers
from pathlib import Path
from datetime import datetime, timezone
r = Path('/workspace/number-predecessor-pilot-20261028')
hooks = sum(len(m._forward_hooks) + len(m._forward_pre_hooks) for m in model.modules())
assert hooks == 0
assert all(b.self_attn.forward == f for eng in list(number_engines.values()) + list(number_follow_engines.values()) for b,f in zip(model.model.layers,eng.attention))
pin = json.loads((r/'protocol.json').read_text())['base_revision']
commit = getattr(model.config, '_commit_hash', None)
assert commit is None or commit == pin
data = {'saved_at_utc':datetime.now(timezone.utc).isoformat(), 'hooks_remaining':hooks, 'attention_unchanged':True, 'model_name_or_path':model.config._name_or_path, 'model_config_commit_hash':commit, 'expected_base_commit':pin, 'model_dtype':str(next(model.parameters()).dtype), 'model_training':model.training, 'attention_implementation':getattr(model.config, '_attn_implementation', None), 'torch':torch.__version__, 'transformers':transformers.__version__, 'checkpoint_evidence_limit':'Runtime config identity and previously verified loading provenance; no independent whole-base-weights hash in this pilot.'}
(r/'artifacts/final-runtime.json').write_text(json.dumps(data,indent=2)+'\n')
