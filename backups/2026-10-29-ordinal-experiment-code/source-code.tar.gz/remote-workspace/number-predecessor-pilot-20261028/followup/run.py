"""Bounded native-capability phase, then hash-bound reviewed single-feature ablations."""
import hashlib
import json
import runpy
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'artifacts'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save(p, data):
    temp = p.with_suffix('.tmp')
    temp.write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    temp.replace(p)


def phase_case(case, ordinal):
    c = dict(case)
    c['original_expected'] = c['expected'][str(ordinal)]
    c['target_expected'] = c['expected'][str(case['n'] + 1)]
    return c


def run_controls(model, tokenizer):
    OUT.mkdir(exist_ok=True)
    assert not (OUT / 'controls.json').exists()
    ns = runpy.run_path(str(ROOT / 'engine.py'))
    protocol = json.loads((ROOT / 'protocol.json').read_text())
    engines = {}
    d = {'status': 'running', 'started_at_utc': datetime.now(timezone.utc).isoformat(),
         'protocol': protocol, 'source_sha256': {n: sha(ROOT / n) for n in ['run.py', 'engine.py', 'protocol.json', 'cases.json', 'weights/manifest.json']},
         'controls': []}
    for feature in protocol['features']:
        key = f"L{feature['layer']}-T{feature['transform']}"
        engine = ns['Selective'](model, tokenizer, key)
        engines[key] = engine
        for case in engine.cases:
            row = {'case_id': case['id'], 'feature_key': key, 'ordinals': {}}
            for ordinal in [case['n'], case['n'] + 1]:
                c = phase_case(case, ordinal)
                prompt = c['prompts'][str(ordinal)]
                native = engine.run(c, prompt, f'n-{ordinal}--native')
                row['ordinals'][str(ordinal)] = {'native': native, 'answer_sha256': hashlib.sha256(native['answer'].encode()).hexdigest()}
                if ordinal == case['n']:
                    observed = engine.run(c, prompt, f'n-{ordinal}--zero', spec={'kind': 'all'}, target=0., alpha=0., audit=True)
                    assert native['steps'] == observed['steps'] and native['output_token_ids'] == observed['output_token_ids']
                    row['ordinals'][str(ordinal)]['zero_strength'] = observed
                print('NATIVE', case['id'], ordinal, 'expected', c['original_expected'], 'prefix', json.dumps(native['answer'][:160]), flush=True)
            d['controls'].append(row)
            save(OUT / 'controls.json', d)
    d.update(status='complete', finished_at_utc=datetime.now(timezone.utc).isoformat(), hooks_remaining=0)
    save(OUT / 'controls.json', d)
    print('CONTROLS_COMPLETE: inspect native answers and hash-bind eligibility before ablation.', flush=True)
    return engines, d


def run_ablations(engines, controls):
    assert controls['status'] == 'complete' and not (OUT / 'results.json').exists()
    review = json.loads((ROOT / 'eligibility.json').read_text())
    assert review['controls_sha256'] == sha(OUT / 'controls.json')
    by_id = {r['case_id']: r for r in controls['controls']}
    reviewed = {r['case_id']: r for r in review['cases']}
    d = {'status': 'running', 'started_at_utc': datetime.now(timezone.utc).isoformat(),
         'eligibility': review, 'controls_sha256': sha(OUT / 'controls.json'),
         'source_sha256': sha(ROOT / 'run.py'), 'runs': [], 'specificity_controls': [], 'repeats': []}
    for engine in engines.values():
        engine.started = time.monotonic()
        for case in engine.cases:
            cid, n = case['id'], case['n']
            r = reviewed[cid]
            assert r['eligible'] == all(r['correct'].values())
            for k, val in by_id[cid]['ordinals'].items():
                assert r['answer_sha256'][k] == val['answer_sha256']
            if not r['eligible']:
                continue
            c = phase_case(case, n)
            original = by_id[cid]['ordinals'][str(n)]['native']
            size = len(original['prompt_token_ids'])
            specs = {'input_only': {'kind': 'input'}, 'last_input_only': {'kind': 'positions', 'positions': [size - 1]}}
            for scope, spec in specs.items():
                result = engine.run(c, original['prompt'], f'n-{n}--off-{scope}', spec=spec, target=0., audit=True)
                result.update(scope=scope, ordinal=n)
                d['runs'].append(result)
                print('OFF', cid, scope, 'prefix', json.dumps(result['answer'][:160]), flush=True)
                save(OUT / 'results.json', d)
            next_c = phase_case(case, n + 1)
            next_native = by_id[cid]['ordinals'][str(n + 1)]['native']
            specific = engine.run(next_c, next_native['prompt'], f'n-{n+1}--off-last', spec={'kind': 'positions', 'positions': [len(next_native['prompt_token_ids'])-1]}, target=0., audit=True)
            specific.update(scope='last_input_only', ordinal=n+1)
            d['specificity_controls'].append(specific)
            # Exact repeats preserve every answer, probability and trace, including negatives.
            for name, baseline in [('native-repeat', original), ('off-last-repeat', d['runs'][-1])]:
                repeated = engine.run(c, original['prompt'], name, spec=baseline['spec'], target=baseline['target'], alpha=baseline['alpha'], audit=True)
                assert repeated['steps'] == baseline['steps'] and repeated['trace'] == baseline['trace'] and repeated['output_token_ids'] == baseline['output_token_ids']
                repeated['repeats_name'] = baseline['name']
                d['repeats'].append(repeated)
            save(OUT / 'results.json', d)
    d.update(status='complete', finished_at_utc=datetime.now(timezone.utc).isoformat(), hooks_remaining=0)
    save(OUT / 'results.json', d)
    print('ABLATIONS_COMPLETE', len(d['runs']), 'eligible-case ablations', flush=True)
    return d
