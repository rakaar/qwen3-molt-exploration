import contextlib
import runpy
import traceback

with open('/workspace/number-predecessor-pilot-20261028/followup/controls.log', 'w', buffering=1) as number_log:
    with contextlib.redirect_stdout(number_log), contextlib.redirect_stderr(number_log):
        try:
            number_follow_ns = runpy.run_path('/workspace/number-predecessor-pilot-20261028/followup/run.py')
            number_follow_engines, number_follow_controls = number_follow_ns['run_controls'](model, tokenizer)
        except BaseException:
            traceback.print_exc()
            raise
