"""Independent CPU audit of downloaded number-predecessor pilot artifacts.

Never imports the GPU runner, loads the language model, or calls CUDA. NumPy
FP32 reconstructs each saved gate/operator. If installed, torch is used only
on CPU for the final BF16 cast; an integer round-to-nearest-even fallback is
available. The saved standardized residual z is the reconstruction starting
point: the original pre-normalization residual was not saved by the runner.

Usage: python3 audit.py [--root EXPORTED_PILOT] [--controls-only]
An optional --expected-hashes JSON maps root-relative filenames to independently
recorded remote SHA256 values. Internal control/review/result hash links and
every saved tensor file hash are checked even without that transfer manifest.
"""
import argparse
import hashlib
import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

try:
    import torch
except ImportError:
    torch = None


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def bf16(value):
    value = np.ascontiguousarray(value, dtype=np.float32)
    if torch is not None:
        return torch.from_numpy(value).to(dtype=torch.bfloat16, device='cpu').float().numpy()
    bits = value.view(np.uint32)
    rounded = bits + np.uint32(0x7fff) + ((bits >> 16) & 1)
    return (rounded & np.uint32(0xffff0000)).view(np.float32)


def same_completion(left, right, context, traces=False):
    fields = ['prompt', 'chat', 'prompt_token_ids', 'output_token_ids', 'answer', 'stop_reason', 'steps', 'assessment']
    if traces:
        fields += ['spec', 'target', 'alpha', 'replay', 'trace']
    for field in fields:
        require(left[field] == right[field], f'{context}: unequal {field}')


def selected(spec, position, prompt_size):
    phase = 'input' if position < prompt_size else 'output'
    return (spec['kind'] == 'all' or spec['kind'] == phase
            or (spec['kind'] == 'positions' and position in spec['positions']))


class Audit:
    def __init__(self, root, controls_only=False, expected_hashes=None):
        self.root = root.resolve()
        self.artifacts = self.root / 'artifacts'
        self.controls_only = controls_only
        self.protocol = load(self.root / 'protocol.json')
        self.cases = {row['id']: row for row in load(self.root / 'cases.json')}
        self.manifest = load(self.root / 'weights/manifest.json')
        self.weights = {}
        self.report = {
            'status': 'running', 'audited_at_utc': datetime.now(timezone.utc).isoformat(),
            'root': str(self.root), 'controls_only': controls_only, 'device': 'CPU',
            'bf16_rounding': 'torch CPU' if torch is not None else 'NumPy uint32 round-to-nearest-even',
            'limitations': [
                'Gate/operator reconstruction starts from saved FP32 standardized residual z; original residual x was not saved.',
                'The runner inherits an already-loaded base model; these artifacts do not independently prove its checkpoint identity.',
                'Vector files sample selected positions/steps; full-position invariance is additionally asserted by runner and checked in traces.',
                'Exact repeats cover native and last-input ablation; input-only ablations have no separate repeat.',
            ],
            'file_sha256': {}, 'independent_transfer_hashes_checked': 0,
            'counts': {'runs': 0, 'processed_positions': 0, 'unselected_positions': 0,
                       'vector_files': 0, 'vector_positions': 0, 'native_zero_pairs': 0,
                       'exact_repeats': 0, 'exact_noop_comparisons': 0},
            'errors': {'max_encoder_absolute': 0., 'max_operator_relative_l2': 0.,
                       'max_probability_reconstruction': 0.},
            'case_summary': [], 'automated_capability_disagreements': [],
        }
        self.seen_vector_files = set()
        if expected_hashes:
            expected = load(expected_hashes)
            require(isinstance(expected, dict), 'Expected transfer hashes must be a filename-to-sha256 mapping')
            for name, digest in expected.items():
                self.check_hash(name, digest)
                self.report['independent_transfer_hashes_checked'] += 1

    def check_hash(self, relative, expected=None):
        path = (self.root / relative).resolve()
        require(path.is_relative_to(self.root), f'File outside exported pilot: {relative}')
        actual = sha(path)
        if expected is not None:
            require(actual == expected, f'SHA256 mismatch: {relative}')
        self.report['file_sha256'][str(path.relative_to(self.root))] = actual
        return actual

    def prepare_weights(self):
        require(self.manifest['status'] == 'complete', 'Incomplete weight manifest')
        require(self.manifest['repo'] == self.protocol['molt_repo'], 'MOLT repository mismatch')
        require(self.manifest['revision'] == self.protocol['molt_revision'], 'MOLT revision mismatch')
        planned = {(f['layer'], f['transform']): f for f in self.protocol['features']}
        require(len(planned) == len(self.manifest['features']), 'Feature count mismatch')
        for feature in self.manifest['features']:
            pair = feature['layer'], feature['transform']
            require(pair in planned, f'Unplanned feature {pair}')
            require(feature['rank'] == planned[pair]['rank'], f'Rank mismatch {pair}')
            require(feature['target_number'] == planned[pair]['target_number'], f'Number mismatch {pair}')
            relative = 'weights/' + feature['file']
            self.check_hash(relative, feature['sha256'])
            require((self.root / relative).stat().st_size == feature['bytes'], f'Weight size mismatch {pair}')
            with np.load(self.root / relative, allow_pickle=False) as archive:
                weights = {key: archive[key].copy() for key in archive.files}
            shapes = {'e': (2560,), 'bias': (1,), 'theta': (1,), 'input_mean': (2560,),
                      'input_std': (2560,), 'output_std': (2560,),
                      'U': (feature['rank'], 2560), 'V': (2560, feature['rank'])}
            require(set(weights) == set(shapes), f'Weight keys mismatch {pair}')
            for key, shape in shapes.items():
                require(weights[key].dtype == np.float32 and weights[key].shape == shape,
                        f'Weight shape/dtype mismatch {pair}/{key}')
                require(np.isfinite(weights[key]).all(), f'Nonfinite weight {pair}/{key}')
            require(np.all(weights['input_std'] > 0) and np.all(weights['output_std'] > 0), f'Invalid scales {pair}')
            self.weights[f'L{pair[0]}-T{pair[1]}'] = weights

    def run_record(self, run):
        context = run['case_id'] + '/' + run['name']
        require(run['case_id'] in self.cases, f'{context}: unknown case')
        case = self.cases[run['case_id']]
        require(run['feature_key'] == case['feature_key'], f'{context}: feature mismatch')
        require(run['hooks_remaining'] == 0, f'{context}: leaked hooks')
        require(run['chat'] == run['prompt'], f'{context}: expected raw prompt')
        require(run['prompt'] in case['prompts'].values(), f'{context}: unplanned prompt')
        require(run['replay'] is None, f'{context}: unplanned replay')
        n, emitted = len(run['prompt_token_ids']), len(run['output_token_ids'])
        require(n > 0 and 0 < emitted <= self.protocol['max_new_tokens'], f'{context}: token count')
        require(run['stop_reason'] in ['eos', 'token_limit'], f'{context}: unexpected stop')
        if run['stop_reason'] == 'token_limit':
            require(emitted == self.protocol['max_new_tokens'], f'{context}: premature token limit')
        require(len(run['steps']) == emitted, f'{context}: score count')
        for index, step in enumerate(run['steps']):
            require(step['position'] == index and step['token_id'] == run['output_token_ids'][index], f'{context}: score alignment')
            probability = math.exp(step['selected_logit'] - step['logsumexp'])
            error = abs(probability - step['selected_probability'])
            self.report['errors']['max_probability_reconstruction'] = max(self.report['errors']['max_probability_reconstruction'], error)
            require(error < 8e-6, f'{context}: logit probability reconstruction')
            values = [step['selected_probability']] + list(step['probe_probabilities'].values()) + [t['probability'] for t in step['top_tokens']]
            require(all(math.isfinite(p) and 0 <= p <= 1 for p in values), f'{context}: invalid probabilities')
        spec = run['spec']
        if spec is None:
            require(run['target'] is None and run['trace'] == [] and run['vectors'] == [], f'{context}: native run has edit data')
        else:
            require(spec['kind'] in ['all', 'input', 'output', 'positions'], f'{context}: unknown mask')
            require(run['target'] == 0 and run['alpha'] in [0., 1.], f'{context}: unplanned intervention')
            require(len(run['trace']) == n + emitted - 1, f'{context}: missing processed positions')
            theta = self.weights[run['feature_key']]['theta'][0]
            for position, trace in enumerate(run['trace']):
                chosen = selected(spec, position, n)
                require(trace['position'] == position and trace['selected'] == chosen, f'{context}: incorrect selection at {position}')
                require(trace['phase'] == ('input' if position < n else 'output'), f'{context}: incorrect phase')
                token = run['prompt_token_ids'][position] if position < n else run['output_token_ids'][position-n]
                require(trace['token_id'] == token, f'{context}: trace/token alignment at {position}')
                raw = np.float32(trace['raw'])
                gate = float(raw) if raw > theta and raw > 0 else 0.
                require(trace['natural_gate'] == gate, f'{context}: gate threshold at {position}')
                require(trace['requested_gate'] == 0. and trace['alpha'] == run['alpha'], f'{context}: trace edit values')
                norms = [trace[k] for k in ['operator_norm', 'intended_delta_norm', 'actual_delta_norm']]
                require(all(math.isfinite(value) and value >= 0 for value in norms), f'{context}: invalid norms')
                require(trace['unselected_unchanged'] == (not chosen), f'{context}: incorrect unchanged flag')
                if not chosen or run['alpha'] == 0 or gate == 0:
                    require(trace['intended_delta_norm'] == trace['actual_delta_norm'] == 0., f'{context}: expected local no-op at {position}')
                self.report['counts']['processed_positions'] += 1
                if not chosen:
                    self.report['counts']['unselected_positions'] += 1
            expected_steps = {step for step in self.protocol['audit_steps'] if step < emitted}
            seen_steps = set()
            for vector in run['vectors']:
                match = re.fullmatch(re.escape(run['case_id'] + '--' + run['name']) + r'--step-(\d+)\.npz', vector['file'])
                require(match is not None, f'{context}: unexpected vector filename')
                step = int(match[1])
                require(step in expected_steps and step not in seen_steps, f'{context}: unexpected/duplicate vector step')
                require(vector['file'] not in self.seen_vector_files, f'{context}: reused vector file')
                seen_steps.add(step)
                self.seen_vector_files.add(vector['file'])
                self.vector_record(run, vector, step)
            require(seen_steps == expected_steps, f'{context}: missing vector samples')
        self.report['counts']['runs'] += 1

    def vector_record(self, run, vector, step):
        context = run['case_id'] + '/' + vector['file']
        self.check_hash('artifacts/' + vector['file'], vector['sha256'])
        require(vector['alpha'] == run['alpha'], f'{context}: vector alpha')
        with np.load(self.artifacts / vector['file'], allow_pickle=False) as archive:
            x = {key: archive[key] for key in archive.files}
        keys = {'positions', 'selected', 'fixed', 'z', 'raw', 'gate', 'operator', 'native_mlp', 'edited_mlp', 'intended_delta', 'actual_delta'}
        require(set(x) == keys, f'{context}: vector keys')
        n = len(run['prompt_token_ids'])
        positions = list(range(n)) if step == 0 else [n + step - 1]
        chosen = [selected(run['spec'], position, n) for position in positions]
        js = sorted(set([0, len(positions)-1] + [index for index, flag in enumerate(chosen) if flag][-3:]))
        require(x['positions'].tolist() == [positions[index] for index in js], f'{context}: vector positions')
        m = len(js)
        require(x['selected'].shape == (1, m) and x['selected'].dtype == np.bool_, f'{context}: selection shape/dtype')
        require(x['selected'].tolist() == [[chosen[index] for index in js]], f'{context}: vector mask')
        for key in keys - {'positions', 'selected'}:
            shape = (1, m, 2560) if key in ['z', 'operator', 'native_mlp', 'edited_mlp', 'intended_delta', 'actual_delta'] else (1, m)
            require(x[key].shape == shape and x[key].dtype == np.float32, f'{context}: {key} shape/dtype')
            require(np.isfinite(x[key]).all(), f'{context}: nonfinite {key}')
        require(np.all(x['fixed'] == 0), f'{context}: nonzero requested gate')
        weights = self.weights[run['feature_key']]
        raw = x['z'] @ weights['e'] + weights['bias'][0]
        error = float(np.max(np.abs(raw - x['raw'])))
        self.report['errors']['max_encoder_absolute'] = max(self.report['errors']['max_encoder_absolute'], error)
        require(np.allclose(raw, x['raw'], atol=3e-5, rtol=3e-5), f'{context}: FP32 encoder reconstruction')
        # Exact comparison to saved raw verifies the discontinuous gate branch;
        # the independently reconstructed encoder is checked just above.
        gate = np.where((x['raw'] > weights['theta'][0]) & (x['raw'] > 0), x['raw'], np.float32(0))
        require(np.array_equal(gate, x['gate']), f'{context}: thresholded gate reconstruction')
        independent_gate = np.where((raw > weights['theta'][0]) & (raw > 0), raw, np.float32(0))
        require(np.allclose(independent_gate, x['gate'], atol=3e-5, rtol=3e-5), f'{context}: independently reconstructed gate')
        operator = ((x['z'] @ weights['V']) @ weights['U']) * weights['output_std']
        error = float(np.linalg.norm(operator - x['operator']) / max(float(np.linalg.norm(operator)), 1e-12))
        self.report['errors']['max_operator_relative_l2'] = max(self.report['errors']['max_operator_relative_l2'], error)
        require(error < 1e-4, f'{context}: FP32 operator reconstruction')
        intended = np.where(x['selected'][..., None], np.float32(run['alpha']) * (x['fixed'] - x['gate'])[..., None] * x['operator'], np.float32(0))
        require(np.array_equal(intended, x['intended_delta']), f'{context}: exact FP32 intervention delta')
        require(np.array_equal(bf16(x['native_mlp']), x['native_mlp']), f'{context}: native output is not BF16 representable')
        require(np.array_equal(bf16(x['native_mlp'] + intended), x['edited_mlp']), f'{context}: single final BF16 rounding')
        require(np.array_equal(x['edited_mlp'] - x['native_mlp'], x['actual_delta']), f'{context}: actual delta')
        require(np.array_equal(x['native_mlp'][~x['selected']], x['edited_mlp'][~x['selected']]), f'{context}: unselected output changed')
        for index, position in enumerate(x['positions']):
            trace = run['trace'][int(position)]
            require(float(x['raw'][0,index]) == trace['raw'] and float(x['gate'][0,index]) == trace['natural_gate'], f'{context}: trace/vector gate mismatch')
            for array, norm_key in [('operator', 'operator_norm'), ('intended_delta', 'intended_delta_norm'), ('actual_delta', 'actual_delta_norm')]:
                require(math.isclose(float(np.linalg.norm(x[array][0,index])), trace[norm_key], rel_tol=3e-6, abs_tol=3e-6), f'{context}: trace/vector {norm_key}')
        self.report['counts']['vector_files'] += 1
        self.report['counts']['vector_positions'] += m

    def main(self):
        self.prepare_weights()
        controls = load(self.artifacts / 'controls.json')
        require(controls['status'] == 'complete' and controls['hooks_remaining'] == 0, 'Controls incomplete or hooks remain')
        require(controls['protocol'] == self.protocol, 'Saved/current protocol mismatch')
        for relative, digest in controls['source_sha256'].items():
            self.check_hash(relative, digest)
        controls_sha = self.check_hash('artifacts/controls.json')
        by_id = {row['case_id']: row for row in controls['controls']}
        require(len(by_id) == len(controls['controls']) == len(self.cases) and set(by_id) == set(self.cases), 'Control case coverage')
        for cid, row in by_id.items():
            case, n = self.cases[cid], self.cases[cid]['n']
            require(row['feature_key'] == case['feature_key'], f'{cid}: control feature')
            require(set(row['ordinals']) == {str(n), str(n+1)}, f'{cid}: capability ordinal coverage')
            for ordinal, pair in row['ordinals'].items():
                native = pair['native']
                require(native['prompt'] == case['prompts'][ordinal] and native['spec'] is None, f'{cid}: native capability prompt')
                require(hashlib.sha256(native['answer'].encode()).hexdigest() == pair['answer_sha256'], f'{cid}: answer hash')
                self.run_record(native)
                if int(ordinal) == n:
                    zero = pair['zero_strength']
                    require(zero['spec'] == {'kind': 'all'} and zero['target'] == 0 and zero['alpha'] == 0, f'{cid}: zero-strength control')
                    self.run_record(zero)
                    same_completion(native, zero, f'{cid}: native/zero')
                    self.report['counts']['native_zero_pairs'] += 1
                else:
                    require(set(pair) == {'native', 'answer_sha256'}, f'{cid}: unexpected next-ordinal fields')
        if self.controls_only:
            self.report.update(status='passed', controls_sha256=controls_sha, control_cases=len(by_id))
            return self.report
        results = load(self.artifacts / 'results.json')
        require(results['status'] == 'complete' and results['hooks_remaining'] == 0, 'Results incomplete or hooks remain')
        self.check_hash('artifacts/results.json')
        self.check_hash('run.py', results['source_sha256'])
        review = load(self.root / 'eligibility.json')
        self.check_hash('eligibility.json')
        require(results['eligibility'] == review, 'Saved/current eligibility mismatch')
        require(review['controls_sha256'] == results['controls_sha256'] == controls_sha, 'Eligibility/control hash linkage')
        reviewed = {row['case_id']: row for row in review['cases']}
        require(len(reviewed) == len(review['cases']) and set(reviewed) == set(self.cases), 'Review case coverage')
        eligible_ids = set()
        for cid, row in by_id.items():
            case, decision = self.cases[cid], reviewed[cid]
            ordinals = set(row['ordinals'])
            require(set(decision['correct']) == set(decision['answer_sha256']) == ordinals, f'{cid}: review ordinal coverage')
            require(all(type(value) is bool for value in decision['correct'].values()), f'{cid}: review correctness types')
            require(type(decision['eligible']) is bool and decision['eligible'] == all(decision['correct'].values()), f'{cid}: inconsistent review decision')
            for ordinal, pair in row['ordinals'].items():
                require(decision['answer_sha256'][ordinal] == pair['answer_sha256'], f'{cid}: review answer linkage')
                detected = pair['native']['assessment']['first_recognized_answer']
                if decision['correct'][ordinal] != (detected == case['expected'][ordinal]):
                    self.report['automated_capability_disagreements'].append({'case_id': cid, 'ordinal': ordinal, 'detected': detected, 'expected': case['expected'][ordinal], 'human_correct': decision['correct'][ordinal], 'review_reason': decision.get('review_reason')})
            if decision['eligible']:
                eligible_ids.add(cid)
            rows = [run for run in results['runs'] if run['case_id'] == cid]
            require(len(rows) == (2 if decision['eligible'] else 0), f'{cid}: ablation coverage or excluded-case ablation')
            if rows:
                require({run['scope'] for run in rows} == {'input_only', 'last_input_only'}, f'{cid}: scope coverage')
            self.report['case_summary'].append({'case_id': cid, 'eligible': decision['eligible'], 'native_answers': {ordinal: pair['native']['answer'] for ordinal, pair in row['ordinals'].items()}, 'last_input_gate': row['ordinals'][str(case['n'])]['zero_strength']['trace'][len(row['ordinals'][str(case['n'])]['native']['prompt_token_ids'])-1]['natural_gate'], 'ablation_first_answers': {run['scope']: run['assessment']['first_recognized_answer'] for run in rows}})
        require(len(results['runs']) == 2*len(eligible_ids), 'Unexpected ablation rows')
        require(len(results['specificity_controls']) == len(eligible_ids), 'Specificity control count')
        require(len(results['repeats']) == 2*len(eligible_ids), 'Repeat count')
        for kind, runs in [('ablation', results['runs']), ('specificity', results['specificity_controls'])]:
            seen = set()
            for run in runs:
                cid, case = run['case_id'], self.cases[run['case_id']]
                require(cid in eligible_ids, f'{cid}: intervention on ineligible case')
                require((cid, run['scope']) not in seen, f'{cid}: duplicate {kind} scope')
                seen.add((cid, run['scope']))
                expected_ordinal = case['n'] + (kind == 'specificity')
                require(run['ordinal'] == expected_ordinal and run['alpha'] == 1 and run['target'] == 0, f'{cid}: ablation metadata')
                native = by_id[cid]['ordinals'][str(expected_ordinal)]['native']
                require(run['prompt'] == native['prompt'] and run['prompt_token_ids'] == native['prompt_token_ids'], f'{cid}: intervention prompt/tokenization')
                if kind == 'specificity':
                    require(run['scope'] == 'last_input_only', f'{cid}: specificity scope')
                expected_spec = {'kind': 'input'} if run['scope'] == 'input_only' else {'kind': 'positions', 'positions': [len(native['prompt_token_ids'])-1]}
                require(run['spec'] == expected_spec, f'{cid}: incorrect intended mask')
                self.run_record(run)
                if not any(trace['actual_delta_norm'] for trace in run['trace']):
                    same_completion(run, native, f'{cid}: all-zero local edit')
                    self.report['counts']['exact_noop_comparisons'] += 1
        seen_repeats = set()
        for run in results['repeats']:
            cid = run['case_id']
            require(cid in eligible_ids, f'{cid}: repeat on ineligible case')
            marker = (cid, run['repeats_name'])
            require(marker not in seen_repeats, f'{cid}: duplicate repeat')
            seen_repeats.add(marker)
            n = self.cases[cid]['n']
            if run['repeats_name'] == f'n-{n}--native':
                original = by_id[cid]['ordinals'][str(n)]['native']
            else:
                originals = [row for row in results['runs'] if row['case_id'] == cid and row['name'] == run['repeats_name'] and row['scope'] == 'last_input_only']
                require(len(originals) == 1, f'{cid}: unknown repeat source')
                original = originals[0]
            self.run_record(run)
            same_completion(run, original, f'{cid}: exact repeat', traces=True)
            self.report['counts']['exact_repeats'] += 1
        self.report.update(status='passed', controls_sha256=controls_sha, control_cases=len(by_id), eligible_cases=len(eligible_ids), excluded_cases=len(by_id)-len(eligible_ids), all_native_zero_controls_exact=True, all_repeats_exact=True, all_saved_vector_hashes_verified=True, all_sampled_BF16_edits_exact=True, hooks_remaining=0)
        return self.report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--controls-only', action='store_true')
    parser.add_argument('--expected-hashes', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    audit = Audit(args.root, args.controls_only, args.expected_hashes)
    output = args.output or audit.artifacts / ('audit-controls.json' if args.controls_only else 'audit.json')
    try:
        report = audit.main()
    except Exception as error:
        report = audit.report
        report.update(status='failed', failure=f'{type(error).__name__}: {error}')
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
        print(json.dumps({'status': 'failed', 'failure': report['failure'], 'report': str(output)}))
        raise
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    print(json.dumps({'status': report['status'], 'counts': report['counts'], 'errors': report['errors'], 'report': str(output)}))


if __name__ == '__main__':
    main()
