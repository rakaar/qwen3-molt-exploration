import contextlib
import traceback

with open('/workspace/number-predecessor-pilot-20261028/followup/ablations.log', 'w', buffering=1) as number_log:
    with contextlib.redirect_stdout(number_log), contextlib.redirect_stderr(number_log):
        try:
            number_follow_results = number_follow_ns['run_ablations'](number_follow_engines, number_follow_controls)
        except BaseException:
            traceback.print_exc()
            raise
