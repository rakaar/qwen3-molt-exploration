#!/bin/bash
set -euo pipefail
cd /workspace/ch-coactivation-20261028
for attempt in $(seq 1 240); do
  if grep -q '^Installation and public model download complete.$' setup.log; then
    tmux new-session -d -s ch-coactivation -c /workspace/ch-coactivation-20261028
    tmux pipe-pane -o -t ch-coactivation 'cat >> /workspace/ch-coactivation-20261028/session.log'
    tmux send-keys -l -t ch-coactivation 'export HF_HUB_OFFLINE=1 TOKENIZERS_PARALLELISM=false OMP_NUM_THREADS=4; .venv/bin/python -i run.py'
    tmux send-keys -t ch-coactivation Enter
    echo 'Experiment launched in persistent Python session.'
    exit 0
  fi
  sleep 5
done
echo 'Setup did not complete within 20-minute launch window.'
exit 1
