#!/bin/bash
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends gcc g++ libc6-dev
gcc --version
.venv/bin/python -m pip freeze > environment.freeze.txt
tmux send-keys -l -t ch-coactivation 'import gc, sys; sys.last_traceback = None; sys.last_value = None; sys.last_exc = None; gc.collect(); torch.cuda.empty_cache(); model, tokenizer, features, results = main()'
tmux send-keys -t ch-coactivation Enter
echo 'Compiler installed; unchanged experiment retried.'
