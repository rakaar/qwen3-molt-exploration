import json,time,subprocess
from pathlib import Path
r=Path('/workspace/water-president-20261028')
for attempt in range(900):
 p=r/'artifacts/results.json'
 if p.exists():
  d=json.loads(p.read_text())
  if d['status']=='failed':raise RuntimeError('Primary sweep failed: '+str(d.get('error')))
  if d['status']=='complete':
   subprocess.run(['tmux','pipe-pane','-t','ch-coactivation'],check=True)
   subprocess.run(['tmux','pipe-pane','-o','-t','ch-coactivation','cat >> /workspace/water-president-20261028/name-only/session.log'],check=True)
   cmd="president_short_ns = runpy.run_path('/workspace/water-president-20261028/name-only/run.py'); president_short_results, president_short_weights = president_short_ns['run_experiment'](model, tokenizer)"
   subprocess.run(['tmux','send-keys','-l','-t','ch-coactivation',cmd],check=True)
   subprocess.run(['tmux','send-keys','-t','ch-coactivation','Enter'],check=True)
   print('Name-only follow-up launched after primary completion.',flush=True)
   break
 time.sleep(2)
else:raise TimeoutError('Primary sweep not complete within 30 minutes.')
